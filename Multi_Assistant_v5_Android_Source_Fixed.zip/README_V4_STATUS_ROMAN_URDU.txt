MULTI-ASSISTANT v4 ADVANCED PREVIEW — BUILD KIT
Date: 27 October 2026

YE KYA HAI?
Ye 3 platforms ka SOURCE + GitHub build setup hai. Ready exe/APK nahi.
Purani chats aur Google Drive ka record format jaan-bujh kar change nahi kiya.

ABHI IMPLEMENTED / SOURCE-LEVEL (new + preserved):
Windows + compatible Chromebook Linux:
- USB portable mode; separate Data folder and encrypted portable credential vault
- Gemini, Groq, OpenRouter Free, Cerebras Free, Cloudflare Free preserved
- OPTIONAL OpenAI Paid API provider; separate key/billing required; not ChatGPT Plus/Go
- Cross-chat keyword-ranked historical retrieval with original chat+message IDs;
  use Archive Context setting to control whether excerpts are sent to external AI
- Imported ChatGPT history, approval-only permanent memories, Drive event sync preserved
- PDF/DOCX/XLSX/text import up to 8 MB but only bounded text excerpts sent to AI
- PC text-to-speech Play button and optional Auto Voice (requires OS TTS engine)
- Per-provider LOCAL request success/error and APPROXIMATE input/output token estimates
- Read-only project-folder preview for AI code review (with consent, no auto edits)
- Named-code project ZIP export, existing file export, PC monitor

Android:
- Existing Drive sync/SQLite, Gemini/Groq/free providers preserved
- Optional OpenAI Paid API provider (requires paid OpenAI API credits)
- Voice dictation, Play/Stop AI answers, Auto Voice preserved
- Basic cross-chat keyword retrieval, original source title/chat ID
- Estimated local per-provider usage (NOT exact provider quota)
- Accept text/code source up to 8 MB, send first 24,000 characters only
- Android package ID preserved; version 4 advanced preview

NOT YET BUILT / IMPORTANT LIMITATIONS:
- No REAL Android APK, Windows EXE or Chromebook executable in this ZIP.
- No full GPT-6 parity; no model-clone or OpenAI internal services.
- No true AI image editing/generation UI (provider model APIs, terms and billing required).
- No fully automatic coding agent that edits ORION + runs tests. Project review is read-only.
- No built-in live web search, scheduled cloud monitoring, app connectors, video tools,
  complete semantic/vector memories or Android DOCX/PDF/ZIP parsing.
- Windows/Chromebook archive memory uses keyword ranking; not guaranteed exact recall.
- 8 MB FILE size limit does not mean entire file is sent to AI; only excerpt.
- No GitHub Actions build has been run for this v4 revision.
- No live API, real Drive compatibility or device smoke tests run on the v4 source.

ANDROID SAFE UPGRADE: IMPORTANT!
Do NOT uninstall working Android app or delete its data to force an upgrade.
A different debug APK signature cannot install over old signed APK. Uninstall can
DELETE your local chats and API keys. First independently verify all chat backups,
then reuse the SAME signing certificate as installed APK. Android OAuth SHA1 must
match the real signing key. Random CI debug signatures ARE NOT stable.
If the old signing key is unavailable, keep the installed app as-is until migration
is planned and data/export backup is confirmed.

GITHUB BUILD:
1. Upload these files to root of YOUR GitHub repository:
   - Multi_Assistant_Advanced_v4_Windows_Chromebook_Source.zip
   - Multi_Assistant_Advanced_v4_Android_Source.zip
2. Put BUILD_MULTI_ASSISTANT_V4.yml in .github/workflows/build-v4.yml
3. GitHub Actions -> Build Multi-Assistant v4 Three Platforms -> Run workflow
4. Download Windows, Chromebook Linux x86_64 and Android test build artifacts.
5. Never install Android APK before checking previous signing certificate.
6. Test Drive bidirectional sync and API keys on copies before migrating.

Windows and Chromebook Linux cannot share the same .exe binary. Chromebook Linux
package targets x86_64 only; ARM Chromebook may require separate build.

STATUS:
80 Windows offline tests passed.
Android JavaScript syntax check passed.
No Android Gradle/APK build or real device smoke test available in this runtime.
