package com.multiassistant.mobile;

import org.bouncycastle.crypto.generators.SCrypt;
import java.security.SecureRandom;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.GCMParameterSpec;

/** Byte-for-byte compatible with PC sync.py encrypt_events/decrypt_events:
 * MAS1 || salt(16) || nonce(12) || AES-GCM ciphertext-and-tag.
 * Scrypt(N=16384,r=8,p=1,dkLen=32), UTF-8 passphrase.
 */
public final class DriveCrypto {
    private DriveCrypto(){}
    private static final SecureRandom random=new SecureRandom();
    public static byte[] encrypt(byte[] plain,String password)throws Exception{
        if(password.length()<12)throw new IllegalArgumentException("At least 12 characters for sync password");
        byte[] salt=new byte[16],nonce=new byte[12];random.nextBytes(salt);random.nextBytes(nonce);
        byte[] key=SCrypt.generate(password.getBytes(StandardCharsets.UTF_8),salt,16384,8,1,32);
        try{
            Cipher aes=Cipher.getInstance("AES/GCM/NoPadding");
            aes.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));
            byte[] encrypted=aes.doFinal(plain);byte[] result=new byte[32+encrypted.length];
            System.arraycopy("MAS1".getBytes(StandardCharsets.US_ASCII),0,result,0,4);
            System.arraycopy(salt,0,result,4,16);System.arraycopy(nonce,0,result,20,12);
            System.arraycopy(encrypted,0,result,32,encrypted.length);return result;
        }finally{Arrays.fill(key,(byte)0);}
    }
    public static byte[] decrypt(byte[] blob,String password)throws Exception{
        if(blob.length<49||blob[0]!='M'||blob[1]!='A'||blob[2]!='S'||blob[3]!='1')
            throw new IllegalArgumentException("Unknown Google Drive history format");
        byte[] salt=Arrays.copyOfRange(blob,4,20),nonce=Arrays.copyOfRange(blob,20,32);
        byte[] key=SCrypt.generate(password.getBytes(StandardCharsets.UTF_8),salt,16384,8,1,32);
        try{
            Cipher aes=Cipher.getInstance("AES/GCM/NoPadding");
            aes.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));
            return aes.doFinal(blob,32,blob.length-32);
        }finally{Arrays.fill(key,(byte)0);}
    }
}
