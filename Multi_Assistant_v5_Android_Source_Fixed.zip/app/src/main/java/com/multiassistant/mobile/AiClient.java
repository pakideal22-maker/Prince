package com.multiassistant.mobile;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Small HTTPS-only API adapters. No hidden local model or untrusted URL execution. */
public final class AiClient {
    public interface Progress { void onText(String fullResponse); }
    public static final String[] PROVIDERS={"Gemini","Groq","OpenRouter Free","Cerebras Free","Cloudflare Free","OpenAI (Paid API)"};
    public static String defaultModel(String p){
        switch(p){
            case "Gemini":return "gemini-3.5-flash-lite";
            case "Groq":return "openai/gpt-oss-20b";
            case "OpenAI (Paid API)":return "gpt-4.1-mini";
            case "OpenRouter Free":return "openrouter/free";
            case "Cerebras Free":return "gpt-oss-120b";
            case "Cloudflare Free":return "@cf/meta/llama-3.1-8b-instruct-fp8";
            default:return "";
        }
    }
    public static void validateModel(String p,String model){
        if(!Arrays.asList(PROVIDERS).contains(p))throw new IllegalArgumentException("Unsupported AI provider");
        if(model==null||model.isEmpty())throw new IllegalArgumentException("Select an AI model");
        if("OpenAI (Paid API)".equals(p)){
            if(!model.matches("(gpt-[a-zA-Z0-9.-]+|o[134][a-zA-Z0-9.-]*)"))
                throw new IllegalArgumentException("OpenAI model name invalid; this API is paid.");
            return;
        }
        if("OpenRouter Free".equals(p)){
            if(!model.equals("openrouter/free")&&!model.endsWith(":free"))throw new IllegalArgumentException("OpenRouter must use openrouter/free or a :free model.");
        } else {
            Set<String> allowed=new HashSet<>();
            switch(p){
                case "Gemini": allowed.addAll(Arrays.asList("gemini-3.5-flash-lite","gemini-3.1-flash-lite","gemini-2.5-flash-lite","gemini-2.5-flash")); break;
                case "Groq":allowed.addAll(Arrays.asList("openai/gpt-oss-20b","openai/gpt-oss-120b"));break;
                case "Cerebras Free":allowed.addAll(Arrays.asList("gpt-oss-120b"));break;
                case "Cloudflare Free":allowed.addAll(Arrays.asList("@cf/meta/llama-3.1-8b-instruct-fp8","@cf/meta/llama-3.1-8b-instruct-fp8-fast"));break;
            }
            if(!allowed.contains(model))throw new IllegalArgumentException("Model is not on the free-tier allowlist. Check your provider's current free limits.");
        }
    }
    private static String read(InputStream in) throws Exception {
        if(in==null)return "";StringBuilder b=new StringBuilder();
        try(BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String s;while((s=br.readLine())!=null&&b.length()<200000)b.append(s);}
        return b.toString();
    }
    private static HttpURLConnection post(String address,String bearer,String headerName,JSONObject body) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();
        c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(120000);c.setDoOutput(true);
        c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json, text/event-stream");
        if(bearer!=null)c.setRequestProperty(headerName,bearer);
        byte[] payload=body.toString().getBytes(StandardCharsets.UTF_8);
        if(payload.length>160000)throw new IllegalArgumentException("Chat context too long; start a new chat or use a smaller file.");
        try(OutputStream out=c.getOutputStream()){out.write(payload);}
        return c;
    }
    private static JSONArray openAiMessages(JSONArray recent,String instruction) throws Exception {
        JSONArray a=new JSONArray();a.put(new JSONObject().put("role","system").put("content",instruction));
        for(int i=0;i<recent.length();i++){
            JSONObject x=recent.getJSONObject(i);
            String role=x.optString("role");if(!role.equals("user")&&!role.equals("assistant"))continue;
            String content=x.optString("content");int cap=(i==recent.length()-1)?49000:8000;
            if(content.length()>cap)content=content.substring(0,cap);
            a.put(new JSONObject().put("role",role).put("content",content));
        }
        return a;
    }
    private static String parseDelta(String provider, JSONObject packet){
        if("Gemini".equals(provider)){
            JSONArray candidates=packet.optJSONArray("candidates");if(candidates==null)return "";
            StringBuilder b=new StringBuilder();
            for(int i=0;i<candidates.length();i++){
                JSONArray parts=candidates.optJSONObject(i).optJSONObject("content")==null?null:
                    candidates.optJSONObject(i).optJSONObject("content").optJSONArray("parts");
                if(parts==null)continue;
                for(int j=0;j<parts.length();j++){
                    JSONObject part=parts.optJSONObject(j);
                    if(part!=null&&!part.optBoolean("thought",false))b.append(part.optString("text",""));
                }
            }
            return b.toString();
        }
        JSONArray choices=packet.optJSONArray("choices");if(choices==null)return "";
        StringBuilder b=new StringBuilder();
        for(int i=0;i<choices.length();i++){
            JSONObject ch=choices.optJSONObject(i);if(ch==null)continue;
            JSONObject delta=ch.optJSONObject("delta");if(delta!=null)b.append(delta.optString("content",""));
            else if(ch.optJSONObject("message")!=null)b.append(ch.optJSONObject("message").optString("content",""));
        }
        return b.toString();
    }
    private static String streaming(HttpURLConnection c,String provider,Progress cb) throws Exception{
        int code=c.getResponseCode();
        if(code>=400){String err=read(c.getErrorStream());throw new Exception("HTTP "+code+": "+err.substring(0,Math.min(350,err.length())));}
        StringBuilder answer=new StringBuilder();
        try(BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8))){
            String line;StringBuilder data=new StringBuilder();long last=0;
            while((line=br.readLine())!=null){
                if(line.startsWith("data:")){
                    if(data.length()>0)data.append('\n');data.append(line.substring(5).trim());
                }else if(line.trim().isEmpty()&&data.length()>0){
                    String json=data.toString();data.setLength(0);
                    if(json.equals("[DONE]"))break;
                    try{
                        JSONObject p=new JSONObject(json);
                        if(p.has("error"))throw new IllegalStateException(p.optString("error"));
                        String next=parseDelta(provider,p);
                        if(!next.isEmpty()){
                            answer.append(next);
                            if(answer.length()>140000)throw new IllegalStateException("Response size limit reached.");
                            long now=System.currentTimeMillis();if(now-last>110){cb.onText(answer.toString());last=now;}
                        }
                    }catch(org.json.JSONException ignored) { }
                }
            }
        }
        cb.onText(answer.toString());
        if(answer.length()==0)throw new IllegalStateException("AI returned no text; check model and provider quota.");
        return answer.toString();
    }
    public static String answer(String provider, String model,String key,String account,
                                JSONArray recent,String instructions, Progress cb) throws Exception {
        validateModel(provider,model);
        if(key==null||key.isEmpty())throw new IllegalStateException("API key missing for "+provider);
        if("Gemini".equals(provider))return gemini(model,key,recent,instructions,cb);
        if("Cloudflare Free".equals(provider))return cloudflare(model,key,account,recent,instructions,cb);
        String url;
        switch(provider){
            case "Groq":url="https://api.groq.com/openai/v1/chat/completions";break;
            case "OpenAI (Paid API)":url="https://api.openai.com/v1/chat/completions";break;
            case "OpenRouter Free":url="https://openrouter.ai/api/v1/chat/completions";break;
            case "Cerebras Free":url="https://api.cerebras.ai/v1/chat/completions";break;
            default:throw new IllegalArgumentException("Unsupported provider");
        }
        JSONObject body=new JSONObject().put("model",model).put("messages",openAiMessages(recent,instructions)).put("stream",true);
        HttpURLConnection c=post(url,"Bearer "+key,"Authorization",body);
        try{return streaming(c,provider,cb);}finally{c.disconnect();}
    }
    private static String gemini(String model,String key,JSONArray recent,String instructions,Progress cb) throws Exception{
        JSONArray contents=new JSONArray();
        for(int i=0;i<recent.length();i++){
            JSONObject r=recent.optJSONObject(i);if(r==null)continue;
            String role=r.optString("role").equals("assistant")?"model":"user";
            String text=r.optString("content");int cap=(i==recent.length()-1)?49000:8000;
            if(text.length()>cap)text=text.substring(0,cap);
            if(contents.length()>0&&contents.getJSONObject(contents.length()-1).getString("role").equals(role)){
                contents.getJSONObject(contents.length()-1).getJSONArray("parts").put(new JSONObject().put("text",text));
            }else contents.put(new JSONObject().put("role",role).put("parts",new JSONArray().put(new JSONObject().put("text",text))));
        }
        JSONObject body=new JSONObject().put("contents",contents).put("systemInstruction",new JSONObject()
            .put("parts",new JSONArray().put(new JSONObject().put("text",instructions))))
            .put("generationConfig",new JSONObject().put("maxOutputTokens",4096));
        String url="https://generativelanguage.googleapis.com/v1beta/models/"+
            java.net.URLEncoder.encode(model,"UTF-8")+":streamGenerateContent?alt=sse";
        HttpURLConnection c=post(url,key,"x-goog-api-key",body);
        try{return streaming(c,"Gemini",cb);}finally{c.disconnect();}
    }
    private static String cloudflare(String model,String key,String account,JSONArray recent,String instructions,Progress cb) throws Exception{
        if(account==null||!account.matches("[A-Za-z0-9_-]{8,100}"))throw new IllegalArgumentException("Cloudflare Account ID missing or invalid");
        JSONArray msgs=openAiMessages(recent,instructions);
        JSONObject body=new JSONObject().put("messages",msgs);
        HttpURLConnection c=post("https://api.cloudflare.com/client/v4/accounts/"+account+"/ai/run/"+model,
            "Bearer "+key,"Authorization",body);
        try{
            int code=c.getResponseCode();
            if(code>=400){String err=read(c.getErrorStream());throw new Exception("Cloudflare HTTP "+code+": "+err.substring(0,Math.min(350,err.length())));}
            JSONObject obj=new JSONObject(read(c.getInputStream()));
            if(!obj.optBoolean("success",false))throw new Exception("Cloudflare request unsuccessful.");
            JSONObject result=obj.optJSONObject("result");String answer=result==null?"":result.optString("response","");
            if(answer.isEmpty())throw new Exception("Cloudflare returned no text.");cb.onText(answer);return answer;
        }finally{c.disconnect();}
    }
}
