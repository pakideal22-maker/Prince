package com.multiassistant.mobile;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import java.util.HashSet;

/** Version 2: same event protocol as the Windows Python SQLite projection.
 *  Every local change creates a durable device event. Remote replay is idempotent.
 *  Migration keeps v1 local messages and memories; it never drops user data.
 */
public final class ChatStore extends SQLiteOpenHelper {
    private static final DateTimeFormatter ISO=DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'+00:00'").withZone(ZoneOffset.UTC);
    private final String deviceId;
    public ChatStore(Context c){
        super(c,"multi_assistant_android.db",null,2);
        deviceId=c.getSharedPreferences("sync_identity",Context.MODE_PRIVATE)
          .getString("device_id","").isEmpty()?createId(c):c.getSharedPreferences("sync_identity",Context.MODE_PRIVATE).getString("device_id","");
        // Open/migrate immediately so metadata and history are ready for sync.
        getWritableDatabase();
    }
    /** Persistent FTS4 local index for approved long-term archive retrieval.
     *  Sync events and underlying message rows remain unchanged.
     */
    @Override public void onOpen(SQLiteDatabase d){
        super.onOpen(d);
        try{
            d.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS message_fts USING fts4(content, tokenize=unicode61)");
            d.execSQL("CREATE TRIGGER IF NOT EXISTS fts_msg_insert AFTER INSERT ON messages BEGIN INSERT INTO message_fts(docid,content) VALUES(new.rowid,new.content); END");
            d.execSQL("CREATE TRIGGER IF NOT EXISTS fts_msg_delete AFTER DELETE ON messages BEGIN DELETE FROM message_fts WHERE docid=old.rowid; END");
            try(Cursor a=d.rawQuery("SELECT COUNT(*) FROM message_fts",null)){
                if(a.moveToFirst()&&a.getInt(0)==0)
                    d.execSQL("INSERT INTO message_fts(docid,content) SELECT rowid,content FROM messages");
            }
        }catch(Exception ignored){/* Older Android devices use scan fallback. */}
    }
    public synchronized String historicalContext(String question,String currentChatId){
        if(question==null||question.trim().isEmpty())return "";
        java.util.LinkedHashSet<String> terms=new java.util.LinkedHashSet<>();
        String[] words=question.toLowerCase(java.util.Locale.ROOT).split("[^\\p{L}\\p{N}]+");
        java.util.Set<String> ignore=new java.util.HashSet<>(java.util.Arrays.asList(
            "what","when","where","could","should","about","please","this","that",
            "kya","hai","hain","mein","mujhe","mera","mere","aur","ke","ki","ko","se","ka"));
        for(String w:words){if(w.length()>=4&&!ignore.contains(w))terms.add(w);if(terms.size()==10)break;}
        if(terms.isEmpty())return "";
        java.util.ArrayList<String[]> scored=new java.util.ArrayList<>();
        String sql="SELECT c.title,m.content,c.id,m.id FROM message_fts "+
          "JOIN messages m ON m.rowid=message_fts.docid JOIN chats c ON c.id=m.chat_id "+
          "WHERE c.deleted=0 AND m.chat_id<>? AND message_fts MATCH ? LIMIT 120";
        StringBuilder q=new StringBuilder();for(String term:terms){if(q.length()>0)q.append(" OR ");q.append('"').append(term.replace("\"", "")).append('"');}
        try(Cursor c=getReadableDatabase().rawQuery(sql,new String[]{currentChatId==null?"":currentChatId,q.toString()})){
            while(c.moveToNext())scoreResult(c,terms,scored);
        }catch(Exception e){
            // FTS4 unavailable? Bounded scan preserves older devices' functionality.
            try(Cursor c=getReadableDatabase().rawQuery(
              "SELECT c.title,m.content,c.id,m.id FROM messages m JOIN chats c ON c.id=m.chat_id "+
              "WHERE c.deleted=0 AND m.chat_id<>? ORDER BY m.created DESC LIMIT 2000",
               new String[]{currentChatId==null?"":currentChatId})){
                while(c.moveToNext())scoreResult(c,terms,scored);
            }catch(Exception ignored){return "";}
        }
        scored.sort((a,b)->Integer.compare(Integer.parseInt(b[0]),Integer.parseInt(a[0])));
        StringBuilder out=new StringBuilder();
        for(int i=0;i<Math.min(5,scored.size());i++){
            String[] r=scored.get(i);
            out.append("\nSource: ").append(r[1]).append(" [chat: ").append(r[2])
               .append("; msg: ").append(r[3]).append("]\n").append(r[4]).append("\n");
        }
        return out.toString();
    }
    private static void scoreResult(Cursor c,java.util.Set<String> terms,java.util.List<String[]> scored){
        String content=c.getString(1);if(content==null)return;
        String low=content.toLowerCase(java.util.Locale.ROOT),title=c.getString(0);
        int score=0;for(String t:terms){if(low.contains(t))score+=3;if(title.toLowerCase(java.util.Locale.ROOT).contains(t))score+=2;}
        if(score>0)scored.add(new String[]{String.valueOf(score),title,c.getString(2),c.getString(3),
          content.substring(0,Math.min(content.length(),950))});
    }
    private static String createId(Context c){
        String v=UUID.randomUUID().toString();
        c.getSharedPreferences("sync_identity",Context.MODE_PRIVATE).edit().putString("device_id",v).commit();
        return v;
    }
    public String deviceId(){return deviceId;}
    private static String utc(long millis){return ISO.format(Instant.ofEpochMilli(millis));}
    private static String utcNow(){return utc(System.currentTimeMillis());}
    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE chats(id TEXT PRIMARY KEY,title TEXT NOT NULL,created INTEGER NOT NULL,updated INTEGER NOT NULL,pinned INTEGER DEFAULT 0,archived INTEGER DEFAULT 0,deleted INTEGER DEFAULT 0)");
        d.execSQL("CREATE TABLE messages(id TEXT PRIMARY KEY,chat_id TEXT NOT NULL,role TEXT NOT NULL,content TEXT NOT NULL,provider TEXT,created INTEGER NOT NULL)");
        d.execSQL("CREATE INDEX idx_messages_chat ON messages(chat_id,created)");
        d.execSQL("CREATE TABLE memories(id TEXT PRIMARY KEY,text TEXT NOT NULL,state TEXT NOT NULL,created INTEGER NOT NULL)");
        createEvents(d);
    }
    private static void createEvents(SQLiteDatabase d){
        d.execSQL("CREATE TABLE IF NOT EXISTS sync_events(event_id TEXT PRIMARY KEY,device_id TEXT NOT NULL,created_at TEXT NOT NULL,event_type TEXT NOT NULL,payload TEXT NOT NULL)");
        d.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_events ON sync_events(created_at,event_id)");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int oldVersion,int newVersion){
        if(oldVersion>=2)return;
        createEvents(d);
        // Adopt old local rows as events without deleting the original database projection.
        // This is performed inside SQLiteOpenHelper's upgrade transaction.
        try(Cursor c=d.rawQuery("SELECT * FROM chats ORDER BY created,id",null)){
            while(c.moveToNext()){
                String id=c.getString(c.getColumnIndexOrThrow("id"));
                long created=c.getLong(c.getColumnIndexOrThrow("created"));
                JSONObject p=new JSONObject().put("id",id).put("title",c.getString(c.getColumnIndexOrThrow("title")));
                insertEvent(d,makeEvent("chat_create",p,created));
                if(c.getInt(c.getColumnIndexOrThrow("pinned"))!=0)
                    insertEvent(d,makeEvent("chat_pin",new JSONObject().put("id",id).put("value",true),created+1));
                if(c.getInt(c.getColumnIndexOrThrow("archived"))!=0)
                    insertEvent(d,makeEvent("chat_archive",new JSONObject().put("id",id).put("value",true),created+2));
                if(c.getInt(c.getColumnIndexOrThrow("deleted"))!=0)
                    insertEvent(d,makeEvent("chat_delete",new JSONObject().put("id",id),System.currentTimeMillis()));
            }
        }catch(Exception e){throw new IllegalStateException("History migration failed",e);}
        try(Cursor c=d.rawQuery("SELECT * FROM messages ORDER BY created,id",null)){
            while(c.moveToNext()){
                JSONObject p=new JSONObject().put("id",c.getString(c.getColumnIndexOrThrow("id")))
                     .put("chat_id",c.getString(c.getColumnIndexOrThrow("chat_id")))
                     .put("role",c.getString(c.getColumnIndexOrThrow("role")))
                     .put("content",c.getString(c.getColumnIndexOrThrow("content")))
                     .put("provider",c.getString(c.getColumnIndexOrThrow("provider")));
                insertEvent(d,makeEvent("message",p,c.getLong(c.getColumnIndexOrThrow("created"))));
            }
        }catch(Exception e){throw new IllegalStateException("Message migration failed",e);}
        try(Cursor c=d.rawQuery("SELECT * FROM memories ORDER BY created,id",null)){
            while(c.moveToNext()){
                String id=c.getString(c.getColumnIndexOrThrow("id"));
                String state=c.getString(c.getColumnIndexOrThrow("state"));
                long when=c.getLong(c.getColumnIndexOrThrow("created"));
                insertEvent(d,makeEvent("memory_suggest",new JSONObject().put("id",id).put("text",c.getString(c.getColumnIndexOrThrow("text"))),when));
                if(!"pending".equals(state)){
                    String type="deleted".equals(state)?"memory_delete":"memory_decision";
                    JSONObject p=new JSONObject().put("id",id);
                    if(!"deleted".equals(state))p.put("state",state);
                    insertEvent(d,makeEvent(type,p,when+2));
                }
            }
        }catch(Exception e){throw new IllegalStateException("Memory migration failed",e);}
    }
    private JSONObject makeEvent(String type, JSONObject p,long time)throws Exception {
        return new JSONObject().put("event_id",UUID.randomUUID().toString()).put("device_id",deviceId)
             .put("created_at",utc(time)).put("event_type",type).put("payload",p);
    }
    private static void insertEvent(SQLiteDatabase d,JSONObject event)throws Exception{
        ContentValues v=new ContentValues();
        v.put("event_id",event.getString("event_id"));v.put("device_id",event.getString("device_id"));
        v.put("created_at",event.getString("created_at"));v.put("event_type",event.getString("event_type"));
        v.put("payload",event.getJSONObject("payload").toString());
        d.insertWithOnConflict("sync_events",null,v,SQLiteDatabase.CONFLICT_IGNORE);
    }
    private static JSONObject toJson(Cursor c)throws Exception{
        JSONObject j=new JSONObject();
        for(int i=0;i<c.getColumnCount();i++){
            if(c.getType(i)==Cursor.FIELD_TYPE_INTEGER)j.put(c.getColumnName(i),c.getLong(i));
            else j.put(c.getColumnName(i),c.isNull(i)?JSONObject.NULL:c.getString(i));
        }return j;
    }
    private JSONArray select(String sql,String... args){
        JSONArray a=new JSONArray();
        try(Cursor c=getReadableDatabase().rawQuery(sql,args)){while(c.moveToNext())a.put(toJson(c));}
        catch(Exception e){throw new IllegalStateException(e);}return a;
    }
    public synchronized JSONArray eventsForDevice(){
        JSONArray a=select("SELECT * FROM sync_events WHERE device_id=? ORDER BY created_at,event_id",deviceId);
        JSONArray out=new JSONArray();
        for(int i=0;i<a.length();i++)try{
            JSONObject e=a.getJSONObject(i);e.put("payload",new JSONObject(e.getString("payload")));out.put(e);
        }catch(Exception ignored){}
        return out;
    }
    private synchronized void emit(String type,JSONObject p){
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
        try{
            JSONObject e=makeEvent(type,p,System.currentTimeMillis());
            insertEvent(d,e);apply(d,e);d.setTransactionSuccessful();
        }catch(Exception e){throw new IllegalStateException(e);}finally{d.endTransaction();}
    }
    private static void apply(SQLiteDatabase d,JSONObject e)throws Exception{
        String type=e.getString("event_type");JSONObject p=e.getJSONObject("payload");
        String id=p.getString("id");long ms=Instant.parse(e.getString("created_at").replace("+00:00","Z")).toEpochMilli();
        ContentValues v=new ContentValues();
        switch(type){
            case "chat_create":
                v.put("id",id);v.put("title",p.getString("title"));v.put("created",ms);v.put("updated",ms);
                d.insertWithOnConflict("chats",null,v,SQLiteDatabase.CONFLICT_IGNORE);break;
            case "chat_rename":v.put("title",p.getString("title"));v.put("updated",ms);d.update("chats",v,"id=?",new String[]{id});break;
            case "chat_delete":v.put("deleted",1);v.put("updated",ms);d.update("chats",v,"id=?",new String[]{id});break;
            case "chat_pin":v.put("pinned",p.getBoolean("value")?1:0);d.update("chats",v,"id=? AND deleted=0",new String[]{id});break;
            case "chat_archive":v.put("archived",p.getBoolean("value")?1:0);d.update("chats",v,"id=? AND deleted=0",new String[]{id});break;
            case "message":
                v.put("id",id);v.put("chat_id",p.getString("chat_id"));v.put("role",p.getString("role"));
                v.put("content",p.getString("content"));v.put("provider",p.optString("provider",""));v.put("created",ms);
                d.insertWithOnConflict("messages",null,v,SQLiteDatabase.CONFLICT_IGNORE);
                d.execSQL("UPDATE chats SET updated=MAX(updated,?) WHERE id=?",new Object[]{ms,p.getString("chat_id")});break;
            case "memory_suggest":
                v.put("id",id);v.put("text",p.getString("text"));v.put("state","pending");v.put("created",ms);
                d.insertWithOnConflict("memories",null,v,SQLiteDatabase.CONFLICT_IGNORE);break;
            case "memory_decision":v.put("state",p.getString("state"));d.update("memories",v,"id=?",new String[]{id});break;
            case "memory_delete":v.put("state","deleted");d.update("memories",v,"id=?",new String[]{id});break;
            default:throw new IllegalArgumentException("Unknown event type");
        }
    }
    private static void validateEvent(JSONObject e)throws Exception{
        String type=e.getString("event_type"),id=e.getString("event_id"),device=e.getString("device_id");
        if(id.length()>100||device.length()>100||!e.getString("created_at").matches("[0-9T:.+\\-Z]{20,40}"))throw new Exception("Invalid remote event metadata");
        if(!java.util.Arrays.asList("chat_create","chat_rename","chat_delete","chat_pin","chat_archive","message","memory_suggest","memory_decision","memory_delete").contains(type))throw new Exception("Unexpected remote event type");
        JSONObject p=e.getJSONObject("payload");if(!p.has("id")||p.toString().length()>400000)throw new Exception("Remote event payload invalid");
        if("message".equals(type)&&(!p.has("chat_id")||!java.util.Arrays.asList("user","assistant").contains(p.getString("role"))))throw new Exception("Remote message invalid");
        if("memory_decision".equals(type)&&!java.util.Arrays.asList("approved","rejected").contains(p.getString("state")))throw new Exception("Remote memory invalid");
    }
    public synchronized int importEvents(JSONArray incoming,String expectedDevice)throws Exception{
        if(incoming.length()>200000)throw new Exception("Remote history exceeds safe event limit");
        SQLiteDatabase d=getWritableDatabase();int added=0;d.beginTransaction();
        try{
            for(int i=0;i<incoming.length();i++){
                JSONObject e=incoming.getJSONObject(i);validateEvent(e);
                if(!expectedDevice.equals(e.getString("device_id")))throw new Exception("Remote device ID mismatch");
                ContentValues v=new ContentValues();v.put("event_id",e.getString("event_id"));v.put("device_id",e.getString("device_id"));
                v.put("created_at",e.getString("created_at"));v.put("event_type",e.getString("event_type"));v.put("payload",e.getJSONObject("payload").toString());
                if(d.insertWithOnConflict("sync_events",null,v,SQLiteDatabase.CONFLICT_IGNORE)!=-1)added++;
            }
            if(added>0){
                // Deterministic replay is safer than applying an old remote change out of order.
                d.delete("chats",null,null);d.delete("messages",null,null);d.delete("memories",null,null);
                try(Cursor c=d.rawQuery("SELECT * FROM sync_events ORDER BY created_at,event_id",null)){
                    while(c.moveToNext()){
                        JSONObject e=new JSONObject().put("event_type",c.getString(c.getColumnIndexOrThrow("event_type")))
                            .put("created_at",c.getString(c.getColumnIndexOrThrow("created_at")))
                            .put("payload",new JSONObject(c.getString(c.getColumnIndexOrThrow("payload"))));
                        apply(d,e);
                    }
                }
            }
            d.setTransactionSuccessful();return added;
        }finally{d.endTransaction();}
    }
    public synchronized String newChat(){String id=UUID.randomUUID().toString();emit("chat_create",j("id",id,"title","New Chat"));return id;}
    private static JSONObject j(Object... kv){JSONObject o=new JSONObject();try{for(int i=0;i<kv.length;i+=2)o.put((String)kv[i],kv[i+1]);}catch(Exception e){throw new IllegalStateException(e);}return o;}
    public synchronized JSONArray chats(boolean archived){return select("SELECT * FROM chats WHERE deleted=0 AND archived="+(archived?1:0)+" ORDER BY pinned DESC,updated DESC LIMIT 500");}
    public synchronized JSONArray messages(String id){return select("SELECT * FROM messages WHERE chat_id=? ORDER BY created,id LIMIT 5000",id);}
    public synchronized JSONObject chat(String id){JSONArray a=select("SELECT * FROM chats WHERE id=? AND deleted=0",id);return a.length()>0?a.optJSONObject(0):new JSONObject();}
    public synchronized void addMessage(String id,String role,String content,String provider){
        if(!chat(id).has("id"))throw new IllegalArgumentException("Chat unavailable");
        String title=chat(id).optString("title");
        emit("message",j("id",UUID.randomUUID().toString(),"chat_id",id,"role",role,"content",content,"provider",provider));
        if("New Chat".equals(title)&&"user".equals(role)){
            String t=content.replaceAll("\\s+"," ").trim();if(t.length()>48)t=t.substring(0,48)+"…";
            emit("chat_rename",j("id",id,"title",t));
        }
    }
    public synchronized void changeChat(String id,String action,String value){
        if(!chat(id).has("id"))return;
        switch(action){
            case "rename":if(!value.trim().isEmpty())emit("chat_rename",j("id",id,"title",value.trim().substring(0,Math.min(100,value.trim().length()))));break;
            case "pin":emit("chat_pin",j("id",id,"value",Boolean.parseBoolean(value)));break;
            case "archive":emit("chat_archive",j("id",id,"value",Boolean.parseBoolean(value)));break;
            case "delete":emit("chat_delete",j("id",id));break;
            default:throw new IllegalArgumentException("Unknown chat action");
        }
    }
    public synchronized JSONArray memories(String state){return "all".equals(state)?select("SELECT * FROM memories ORDER BY created DESC"):select("SELECT * FROM memories WHERE state=? ORDER BY created DESC",state);}
    public synchronized String suggest(String text){text=text.trim();if(text.isEmpty()||text.length()>700)return "";
        JSONArray same=select("SELECT id FROM memories WHERE lower(text)=lower(?) AND state!='rejected'",text);
        if(same.length()>0)return "";String id=UUID.randomUUID().toString();emit("memory_suggest",j("id",id,"text",text));return id;
    }
    public synchronized void decide(String id,String choice){
        if(!java.util.Arrays.asList("approved","rejected","deleted").contains(choice))return;
        if("deleted".equals(choice))emit("memory_delete",j("id",id));
        else emit("memory_decision",j("id",id,"state",choice));
    }
    public synchronized JSONArray providerContext(String chatId,int count){
        return select("SELECT role,content FROM (SELECT role,content,created,id FROM messages WHERE chat_id=? ORDER BY created DESC,id DESC LIMIT ?) ORDER BY created,id",chatId,String.valueOf(count));
    }
    public synchronized String approvedContext(){JSONArray a=memories("approved");StringBuilder b=new StringBuilder();
        for(int i=0;i<a.length()&&i<30;i++){String s=a.optJSONObject(i).optString("text");if(b.length()+s.length()>4500)break;b.append("- ").append(s).append('\n');}
        return b.toString();
    }
}
