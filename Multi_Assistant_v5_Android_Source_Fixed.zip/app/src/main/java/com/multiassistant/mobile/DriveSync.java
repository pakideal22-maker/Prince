package com.multiassistant.mobile;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.URLEncoder;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Small REST client for the SAME encrypted Google Drive appDataFolder event logs as PC.
 * No client_secret or Drive auth token is shipped inside this app.
 * The caller obtains a short-lived token from Google Identity AuthorizationClient.
 */
public final class DriveSync {
    private static final String API="https://www.googleapis.com/drive/v3/files";
    private static final String UPLOAD="https://www.googleapis.com/upload/drive/v3/files";
    private static final String PREFIX="multi_assistant_events_";
    private static final int MAX_FILE_BYTES=24*1024*1024;
    private DriveSync(){}
    public static final class Result {
        public final int imported, uploaded;
        Result(int a,int b){imported=a;uploaded=b;}
    }
    private static byte[] readLimited(InputStream input)throws Exception{
        try(InputStream in=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n,total=0;
            while((n=in.read(b))!=-1){total+=n;if(total>MAX_FILE_BYTES)throw new Exception("Sync log too large for mobile; please contact support before continuing");out.write(b,0,n);}
            return out.toByteArray();
        }
    }
    private static byte[] request(String token,String verb,String path,String type,byte[] body)throws Exception{
        if(!path.startsWith("https://www.googleapis.com/"))throw new IllegalArgumentException("Untrusted host");
        okhttp3.OkHttpClient client=new okhttp3.OkHttpClient.Builder()
            .connectTimeout(20,java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(45,java.util.concurrent.TimeUnit.SECONDS).build();
        okhttp3.RequestBody payload=body==null?null:okhttp3.RequestBody.create(
            okhttp3.MediaType.parse(type==null?"application/octet-stream":type),body);
        okhttp3.Request req=new okhttp3.Request.Builder().url(path)
            .header("Authorization","Bearer "+token)
            .header("Accept","application/json").method(verb,payload).build();
        try(okhttp3.Response resp=client.newCall(req).execute()){
            byte[] result=resp.body()==null?new byte[0]:readLimited(resp.body().byteStream());
            if(!resp.isSuccessful()){
                String msg=new String(result,StandardCharsets.UTF_8);
                throw new Exception("Google Drive HTTP "+resp.code()+": "+msg.substring(0,Math.min(350,msg.length())));
            }
            return result;
        }
    }
    private static String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
    private static JSONArray allFiles(String token)throws Exception{
        JSONArray all=new JSONArray();String page="";
        do{
            String path=API+"?spaces=appDataFolder&fields="+enc("nextPageToken,files(id,name)")+"&pageSize=1000&q="+enc("name contains 'multi_assistant_events_' and trashed = false");
            if(!page.isEmpty())path+="&pageToken="+enc(page);
            JSONObject response=new JSONObject(new String(request(token,"GET",path,null,null),StandardCharsets.UTF_8));
            JSONArray rows=response.optJSONArray("files");if(rows!=null)for(int i=0;i<rows.length();i++)all.put(rows.getJSONObject(i));
            page=response.optString("nextPageToken","");
        }while(!page.isEmpty());return all;
    }
    public static Result once(ChatStore db,String passphrase,String token)throws Exception{
        if(passphrase.length()<12)throw new Exception("Google Drive sync password must be at least 12 characters");
        if(token==null||token.length()<16)throw new Exception("Google Drive authorization unavailable");
        String own=PREFIX+db.deviceId()+".bin";
        JSONArray files=allFiles(token);String ownFileId="";int received=0;
        // Receive and safely commit peers first. If decryption fails, never overwrite existing Drive data.
        for(int i=0;i<files.length();i++){
            JSONObject f=files.getJSONObject(i);String name=f.optString("name","");
            if(!name.startsWith(PREFIX)||!name.endsWith(".bin"))continue;
            if(name.equals(own)){ownFileId=f.getString("id");continue;}
            String remoteDevice=name.substring(PREFIX.length(),name.length()-4);
            byte[] encrypted=request(token,"GET",API+"/"+enc(f.getString("id"))+"?alt=media",null,null);
            byte[] plain=DriveCrypto.decrypt(encrypted,passphrase);
            JSONObject log=new JSONObject(new String(plain,StandardCharsets.UTF_8));
            if(log.optInt("format",0)!=1||!remoteDevice.equals(log.optString("device_id"))||log.optJSONArray("events")==null)
                throw new Exception("Remote sync device log invalid: "+name);
            received+=db.importEvents(log.getJSONArray("events"),remoteDevice);
        }
        // Own device log only; each machine has a distinct file. Never update another device's file.
        JSONArray ownEvents=db.eventsForDevice();
        JSONObject data=new JSONObject().put("format",1).put("device_id",db.deviceId()).put("events",ownEvents);
        byte[] ciphertext=DriveCrypto.encrypt(data.toString().getBytes(StandardCharsets.UTF_8),passphrase);
        if(ciphertext.length>MAX_FILE_BYTES)throw new Exception("Own log too large for single upload");
        if(!ownFileId.isEmpty()){
            request(token,"PATCH",UPLOAD+"/"+enc(ownFileId)+"?uploadType=media","application/octet-stream",ciphertext);
        }else{
            String boundary="mas"+UUID.randomUUID().toString().replace("-","");
            String meta=new JSONObject().put("name",own).put("parents",new JSONArray().put("appDataFolder")).toString();
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            bytes.write(("--"+boundary+"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+meta+"\r\n").getBytes(StandardCharsets.UTF_8));
            bytes.write(("--"+boundary+"\r\nContent-Type: application/octet-stream\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            bytes.write(ciphertext);
            bytes.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));
            request(token,"POST",UPLOAD+"?uploadType=multipart&fields=id","multipart/related; boundary="+boundary,bytes.toByteArray());
        }
        return new Result(received,ownEvents.length());
    }
}
