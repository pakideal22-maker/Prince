package com.multiassistant.mobile;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Encrypt API keys with a non-exportable Android KeyStore AES key. */
public final class SecureVault {
    private static final String ALIAS="multiassistant_mobile_v1_key";
    private final SharedPreferences p;
    public SecureVault(Context context) { p=context.getSharedPreferences("secure_options",Context.MODE_PRIVATE); }
    private SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(!ks.containsAlias(ALIAS)){
            KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                 .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                 .setRandomizedEncryptionRequired(true).build());
            kg.generateKey();
        }
        return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null)).getSecretKey();
    }
    public synchronized void save(String provider,String value) throws Exception {
        if(value.trim().isEmpty()){p.edit().remove("key_"+provider).apply();return;}
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());
        byte[] data=c.doFinal(value.trim().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        byte[] combined=new byte[12+data.length];System.arraycopy(c.getIV(),0,combined,0,12);System.arraycopy(data,0,combined,12,data.length);
        p.edit().putString("key_"+provider,Base64.getEncoder().encodeToString(combined)).apply();
    }
    public synchronized String get(String provider){
        String s=p.getString("key_"+provider,"");if(s.isEmpty())return "";
        try{
            byte[] data=Base64.getDecoder().decode(s);if(data.length<29)return "";
            byte[] iv=java.util.Arrays.copyOfRange(data,0,12),ciphertext=java.util.Arrays.copyOfRange(data,12,data.length);
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));
            return new String(c.doFinal(ciphertext),java.nio.charset.StandardCharsets.UTF_8);
        }catch(Exception e){return "";}
    }
    public void setModel(String provider,String model){p.edit().putString("model_"+provider,model).apply();}
    public String getModel(String provider,String fallback){return p.getString("model_"+provider,fallback);}
    public void setInstructions(String text){p.edit().putString("instructions",text).apply();}
    public String instructions(){return p.getString("instructions","You are Multi-Assistant, a helpful personal AI assistant. Answer naturally in Roman Urdu unless the user requests otherwise. Never claim to have tools you lack. You may draft code and documents as text; saving files requires an explicit export action.");}
    public void setPreference(String key, String v){p.edit().putString("pref_"+key,v).apply();}
    public String preference(String key,String fallback){return p.getString("pref_"+key,fallback);}
}
