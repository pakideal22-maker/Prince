# Multi-Assistant Android v2 — Google Drive + Robot Icon

## Kya implement hua
- Android home-screen aur chat header par blue AI robot icon.
- 5 free-tier AI provider options: Gemini, Groq, OpenRouter Free, Cerebras Free, Cloudflare Workers AI.
- Local SQLite chat messages + approval-based memories; v1 database migration logic included.
- Google Drive appDataFolder mein Windows PC ke same encrypted per-device event-log format.
- Windows sync password se AES-256-GCM + scrypt encryption (MAS1).
- Google Play Services OAuth; Google Drive Sync Connect, Sync Now aur Disconnect controls.
- App khulne ke baad sync attempt, active app mein ~10 minute periodic check, messages ke baad short sync request.
- PC aur Android history merge karne ka event-based mechanism; shared SQLite file directly edit nahi ki jati.

## Zaroori: source ZIP vs APK
Ye Android Studio/GitHub Actions **source project** hai, pre-built APK nahi. Windows PC par use hone wali Google OAuth Desktop JSON is Android app mein paste nahi karni. Google Drive sync ke liye Android OAuth client **usi Google Cloud project** mein create karo.

## Mobile GitHub se APK banane ke steps
1. `Multi_Assistant_Android_v2_Drive_Robot_Source.zip` GitHub repo root par upload karo.
2. Existing `.github/workflows/build-apk.yml` file mein `build-apk-v2.yml` ka poora content replace karke commit karo.
3. Repo ke `Actions` mein `Build Multi-Assistant Android v2` -> `Run workflow`.
4. Success par artifact download karo. ZIP mein `app-debug.apk` aur `SIGNING_CERT_REPORT.txt` honge.
5. **Signing note:** GitHub ke disposable build runners ka debug certificate har build mein change ho sakta hai. Purani v1 debug app ko seedha update karne par `App not installed` aa sakta hai. V1 ki important conversations pehle export/backup kar lo. Uninstall karna pada to phone ke local app data delete ho sakte hain. Production ke liye apna stable signing keystore securely configure karna hoga.

## Android Google OAuth setup — pehli dafa
1. [Google Auth Platform → Clients](https://console.cloud.google.com/auth/clients) kholo aur **usi Multi-Assistant Cloud project** ko select karo jo Windows Drive API ke liye hai.
2. `Create Client` -> Application Type **Android**.
3. Package name **com.multiassistant.mobile**.
4. SHA-1 **SIGNING_CERT_REPORT.txt** mein `Variant: debug` ke `SHA1:` se lo. Agar APK different signing certificate se signed hai to uski actual SHA-1 use karo.
5. Project `Audience` mein Testing ke andar apni Gmail test user add rehni chahiye.
6. Android app -> Settings -> Google Drive Sync -> PC jaisa **same Google account** aur **same 12+ character sync password** use karo -> Connect -> Google permission approve karo -> Sync Now.
7. Windows app mein bhi Drive sync now chalao. Kuch hi der mein Android ki chats Windows par aur Windows ki Android par nazar aani chahiye. **Abhi ye live cross-device test nahi hua.**

## Safety
- Kisi ko Google OAuth token, sync password ya Groq/Gemini key mat bhejo.
- App ke private Android Keystore mein sync password encrypted save hota hai.
- Import se pehle old PC chat backups rakhna achha hai.
- Google Drive appDataFolder hidden hai; My Drive mein normal file ki tarah nahi dikhega.
- App background mein Android OS network kaam rok sakta hai; 10-minute syncing app *active* rehne par planned hai, 24/7 guaranteed background service nahi.
- Google OAuth login/sharing aur APK functional performance ko abhi real phone par verify karna zaroori hai.
