@echo off
cd /d "%~dp0"
echo This Android source project requires JDK 17, Android SDK 35 and Gradle 8.7.
echo Android Studio is recommended. This script needs gradle on PATH.
gradle :app:assembleDebug --no-daemon
if errorlevel 1 (
 echo Build failed. Open the project in Android Studio and check Gradle/SDK setup.
 pause
 exit /b 1
)
echo Built APK: app\build\outputs\apk\debug\app-debug.apk
pause
