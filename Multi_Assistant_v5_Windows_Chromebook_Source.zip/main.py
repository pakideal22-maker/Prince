"""Launch existing Multi-Assistant with optional USB portable workspace."""
import os
import sys
from pathlib import Path

# A built portable executable always uses the adjacent Data folder.
if getattr(sys,'frozen',False):
    os.environ['MULTI_ASSISTANT_PORTABLE_HOME']=str(Path(sys.executable).resolve().parent)

from multi_assistant.ui import run

if __name__ == '__main__':
    run()
