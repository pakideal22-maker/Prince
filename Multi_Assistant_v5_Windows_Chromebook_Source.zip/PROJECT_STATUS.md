# Multi-Assistant v3.3 — FREE AI Edition

- Core source: Windows PC v3.2, patched for free-tier providers only.
- Status: **62/62 offline tests passed**; Python source compile check passed.
- Unverified: live Windows desktop GUI and live API key connections.
- Active providers: Groq, Gemini, OpenRouter Free, Cerebras Free, Cloudflare Free.
- Disabled/removed from UI/active routing: OpenAI paid, Claude paid, DeepSeek paid.
- Data/Drive: existing local directories and sync logic retained, no migration required.
- Protects against accidental OpenRouter paid-model selection by `:free` / `openrouter/free` enforcement; uses explicit allowlists for other providers.
- Free tier / no billing on user account must be maintained by user; rate limits change.

## v3.4 Sidebar controls
- Per-chat ⋯ menu: Rename / Pin or Unpin / Archive or Unarchive / Export TXT / Delete (confirmation).
- Archived conversations can be restored from Chat > Archived conversations.
- Pin/archive are stored as append-only sync events, compatible with Google Drive.
- Database upgrades existing local chats in place; no fresh keys or Google OAuth required.
- Qt visual testing remains pending on Windows.
