# Multi-Assistant v3.4 — ChatGPT-style Sidebar Options

## Kya naya hai?
- Har chat ke right par **⋯** menu. Right-click se bhi khol sakte ho.
- **Rename:** chat ka naam badlo.
- **Pin to top / Unpin:** zaroori chat upar rakho.
- **Archive:** chat ko sidebar se hide karo (delete nahi hoti).
- **Chat > Archived conversations:** archived chat ko Restore karo.
- **Export as TXT:** ek chat ki text copy save karo.
- **Delete:** sirf confirmation ke baad; deletion agle Drive sync ke saath propagate hogi.

## Safe update (Windows)
1. Multi-Assistant completely CLOSE karo.
2. Project folder ka backup lo.
3. Is ZIP ko extract karo aur **program files** existing folder mein copy/replace karo.
4. `.venv` ya `%LOCALAPPDATA%\Multi-Assistant` DELETE/REPLACE mat karo.
5. `START_WINDOWS.bat` se app start karo.
6. Sidebar mein kisi chat ke saamne **⋯** dabao.

Local SQLite migration app startup par in-place hogi. Koi API key dobara create nahi karni.
Existing chat history aur approved memories preserve karni hain. Old imported chats mein bhi options aayenge.
Google Drive sync previously configured ho to 10-minute auto-sync wahi rahega.

NOTE: Offline tests pass hone ke bawajood Windows GUI ka live visual test user PC par zaroori hai.
