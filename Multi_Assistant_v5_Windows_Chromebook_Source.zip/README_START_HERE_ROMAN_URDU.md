**LATEST UPDATE v3.4:** Pehle `README_V3_4_SIDEBAR_ROMAN_URDU.md` dekho — chat ⋯ menu, rename, pin/archive/delete, safe upgrade.

# Multi-Assistant Windows v3.3 — FREE AI Edition

Is update mein paid-only AI providers **OpenAI GPT, Claude, DeepSeek** ko desktop AI list se hata diya gaya hai.

## Active AI Providers

| Provider | Default model | Key link |
| --- | --- | --- |
| Groq | `openai/gpt-oss-20b` | https://console.groq.com/keys |
| Gemini | `gemini-3.5-flash-lite` | https://aistudio.google.com/api-keys |
| OpenRouter Free | `openrouter/free` | https://openrouter.ai/settings/keys |
| Cerebras Free | `llama3.1-8b` | https://cloud.cerebras.ai/ |
| Cloudflare Free | `@cf/meta/llama-3.1-8b-instruct-fp8` | https://dash.cloudflare.com/ (Workers AI > Use REST API) |

**Groq ka model ID `openai/gpt-oss-20b` hai, lekin yeh Groq API par chalta hai; OpenAI paid key nahi chahiye.**

> Free tiers par rate limits, selected available models, terms aur quotas apply hoti hain. Agar provider account khud paid tier par hai, provider ke apne billing rules apply ho sakte hain. App automatically billing disable nahi kar sakta. Cloudflare Free plan mein free daily quota exceed hone par requests reject honi chahiye; paid model names deliberately block hain. OpenRouter mein sirf `openrouter/free` ya `:free` model allow hoga.

## Upgrade without losing data

1. **Multi-Assistant close karo.**
2. Existing project folder ka backup banao.
3. Is ZIP ko Windows par **Extract All** karo.
4. Extracted folder ki updated `multi_assistant`, `main.py`, `.bat`, `requirements.txt` waghera files existing **program** folder mein copy kar do; replace poochhe to Replace select karo.
5. **`.venv` ko delete ya replace mat karna.**
6. **`%LOCALAPPDATA%\Multi-Assistant` data folder ko touch mat karna.** Ismein tumhari chats, Google OAuth/settings aur SQLite data hain.
7. `START_WINDOWS.bat` run karo. Nayi Python library required nahi; purani installation kaafi honi chahiye.

## Nayi API keys add karna

Multi-Assistant > **Settings > AI Keys & Models** khol kar har required provider ka **API key** paste karo aur usi row mein **Save key** dabao. Agar model edit karo ya Cloudflare Account ID add karo to dialog ke **neeche Save** bhi dabao.

- **OpenRouter Free:** free account se key lo; default model `openrouter/free` rakho. Official free plan currently 50 requests/day.
- **Cerebras Free:** account ke free-tier API key se start karo. Free-tier mein currently available models change ho sakte hain. Agar `llama3.1-8b` 404 de, live model availability check karni hogi. App free allow-list ko update kiye baghair paid fallback nahi karega.
- **Cloudflare Free:** Workers AI page > **Use REST API** > **API Token** aur **Account ID** dono lo. Settings mein Cloudflare row ki key Save key se aur alag **Cloudflare Account ID** box mein Account ID save karo. OAuth/Google Drive ka project is se unrelated hai. API token ko Workers AI permission chahiye.

## Auto & Compare modes

- **Auto:** pehle Groq, phir Gemini, phir OpenRouter Free, Cerebras Free, Cloudflare Free (jin ki keys configured hain). Provider failed ho to next available try karega.
- **Compare Groq + Gemini:** dono configured hon to dono ke answers compare kar sakta hai.
- Kisi paid-only provider ko select ya send karna is edition mein possible nahi.
- Existing paid-provider keys (agar Windows Credential Manager mein stored hain) uninstall/update ke waqt intentionally delete **nahi** hoti; lekin is software mein inaccessible/inactive hain. Chaaho to Windows Credential Manager se unhein separately remove kar sakte ho.

## Storage safety

Existing **SQLite chat history, approved/pending memories, ChatGPT history import, Google Drive OAuth, encrypted sync, passphrase** ko update intentionally delete/migrate nahi karta. Same `%LOCALAPPDATA%\Multi-Assistant` location use hoti hai. Drive automatic sync and sync-on-exit previous v3.2 behavior remain.

## Tests / limitations

62 offline tests pass. Provider HTTP requests ke mocked test pass hue; **real API calls aur Windows GUI** yahan execute nahin ho sake. Windows par Groq/Gemini, phir naya provider manually test karo; OpenRouter/Cerebras/Cloudflare quota/account eligibility har account ke mutabiq hoti hai.

## Security

API keys publicly share na karo. Keys Windows Credential Manager mein rahti hain, `settings.json` mein nahi. Gemini aur doosre free tiers ka data handling paid tiers se different ho sakta hai. Sensitive project data dene se pehle relevant provider ki policy dekh lena.
