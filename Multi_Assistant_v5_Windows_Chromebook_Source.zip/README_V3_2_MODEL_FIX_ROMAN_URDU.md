# Multi-Assistant PC v3.2 — Groq Model Fix

## Error 404 fix
Groq free/developer tier par `llama-3.1-8b-instant` 16 August 2026 se deprecated hai. Is update mein default model `openai/gpt-oss-20b` hai. Saved settings mein purana model ho to app usko running configuration mein automatically replace karta hai. Doosre selected models change nahi hotay.

## Bina update install kiye foran fix
Settings > AI Keys & Models > **Groq** ki Model field mein `openai/gpt-oss-20b` likho aur Save karo, phir Groq select karke test message bhejo. Nayi API key zaroori nahi.

## Update installation
1. Multi-Assistant ko band karo.
2. Purane software folder ka backup lo.
3. Is ZIP ke files purane folder mein merge/replace karo.
4. `.venv` aur `%LOCALAPPDATA%\Multi-Assistant` ko delete ya replace mat karna.
5. START_WINDOWS.bat chalao.
6. Settings > AI Keys & Models khol kar Groq Model `openai/gpt-oss-20b` confirm karo.

**Important:** Is ZIP mein koi API key, local chat database ya personal credential nahi. Existing Google Drive sync logic aur GUI unchanged hain. Ye change source/config level par tested hai; live Groq API request user ke credentials se abhi test nahi hui.
