"""Static regression checks for PC-only source where Qt is unavailable in CI."""
import ast
import unittest
from pathlib import Path

UI = Path(__file__).resolve().parents[1] / 'multi_assistant' / 'ui.py'

class TestV31LayoutGuard(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=UI.read_text('utf-8')
        cls.tree=ast.parse(cls.source)

    def test_windows_menus_above_chats(self):
        src=self.source
        for label in ('File', 'Chat', 'Workspace', 'Settings'):
            self.assertIn("menubar.addMenu('"+label+"')",src)
        self.assertIn('root.addWidget(splitter,1)',src)
        self.assertIn('main.setMinimumWidth(570)',src)
        self.assertIn('root.addWidget(toolbar)',src)

    def test_existing_chat_loaded_even_without_selection_signal(self):
        self.assertIn('if first:self.open_chat(first.data(Qt.UserRole))',self.source)

    def test_sync_and_exit_menu_and_worker_finish(self):
        self.assertIn("'Sync & Exit'",self.source)
        self.assertIn("'Exit Without Sync'",self.source)
        self.assertIn('self.sync_worker.finished.connect(self._finish_exit_if_synced)',self.source)
        self.assertIn('save_sync_passphrase(self.sync_password)',self.source)
        self.assertIn('self._sync_timer.start()',self.source)

    def test_no_data_dir_or_keyring_delete_on_upgrade(self):
        # Do not wipe persisted chats/keys or overwrite OAuth identity.
        self.assertNotIn('shutil.rmtree(data_dir()',self.source)
        self.assertNotIn('self.db = Database(path=',self.source)

if __name__=='__main__': unittest.main()
