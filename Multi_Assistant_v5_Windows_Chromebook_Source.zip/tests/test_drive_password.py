"""Regression tests for Drive passphrase persistence without writing plaintext files."""
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from multi_assistant import config


class FakeKeyring(types.ModuleType):
    class errors:
        class PasswordDeleteError(Exception):
            pass

    def __init__(self):
        super().__init__('keyring')
        self.entries={}

    def get_password(self,service,user):
        return self.entries.get((service,user))

    def set_password(self,service,user,value):
        self.entries[(service,user)]=value

    def delete_password(self,service,user):
        if (service,user) not in self.entries:
            raise self.errors.PasswordDeleteError()
        del self.entries[(service,user)]


class TestDrivePassphrase(unittest.TestCase):
    def setUp(self):
        self.ring=FakeKeyring()
        self.patcher=patch.dict(sys.modules, {'keyring':self.ring})
        self.patcher.start()

    def tearDown(self):
        self.patcher.stop()

    def test_first_launch_has_no_stored_password(self):
        self.assertEqual(config.get_sync_passphrase(), '')

    def test_password_is_retrievable_across_sessions(self):
        password='example-strong-22-character-passphrase'
        config.save_sync_passphrase(password)
        self.assertEqual(config.get_sync_passphrase(),password)
        self.assertEqual(len(self.ring.entries),1)

    def test_weak_password_rejected_before_store(self):
        with self.assertRaises(ValueError):
            config.save_sync_passphrase('short')
        self.assertEqual(self.ring.entries,{})

    def test_forget_does_not_touch_local_settings(self):
        password='example-strong-22-character-passphrase'
        with tempfile.TemporaryDirectory() as tmp, patch.object(config,'data_dir',lambda:Path(tmp)):
            config.save_settings(config.load_settings())
            before=config.config_path().read_bytes()
            config.save_sync_passphrase(password)
            self.assertNotIn(password,config.config_path().read_text())
            config.forget_sync_passphrase()
            self.assertEqual(config.get_sync_passphrase(),'')
            self.assertEqual(config.config_path().read_bytes(),before)
            # Forget is harmless when already forgotten.
            config.forget_sync_passphrase()

if __name__=='__main__':unittest.main()
