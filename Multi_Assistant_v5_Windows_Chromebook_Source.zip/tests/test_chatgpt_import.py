import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from multi_assistant.db import Database
from multi_assistant.chatgpt_import import import_chatgpt_export,extract_text,ImportErrorUser


def sample():
    return [{
        'id':'conv-123', 'title':'ATtiny45 Needle Stop',
        'create_time':1720000000, 'current_node':'final',
        'mapping':{
            'root': {'parent':None,'message':None},
            'user': {'parent':'root','message':{'id':'m1','author':{'role':'user'},
                'create_time':1720000001,'content':{'content_type':'text','parts':['A3144 sensor kaise connect karein?']}}},
            'badpath': {'parent':'user','message':{'id':'m2a','author':{'role':'assistant'},
                'create_time':1720000002,'content':{'parts':['Wrong alternative branch']}}},
            'hidden': {'parent':'user','message':{'id':'m2b','author':{'role':'assistant'},
                'recipient':'python','create_time':1720000002,'content':{'parts':['private tool execution']}}},
            'final': {'parent':'hidden','message':{'id':'m3','author':{'role':'assistant'},
                'create_time':1720000003,'content':{'parts':['Pin 8 par 5V connect karein.']}}},
        }
    },{
        'id':'conv-456','title':'Image only', 'create_time':1720001000,
        'mapping':{'n':{'parent':None,'message':{'author':{'role':'user'},
               'content':{'content_type':'multimodal_text','parts':[{'image':'secret_binary'}]}}}}
    }]

class TestChatGPTImport(unittest.TestCase):
    def setUp(self):
        self.dir=tempfile.TemporaryDirectory()
        self.root=Path(self.dir.name)
        self.db=Database(self.root/'chats.sqlite3')
        self.existing=self.db.new_chat('My Gemini chat')
        self.db.add_message(self.existing,'user','hi')
        self.db.add_message(self.existing,'assistant','Hello','Gemini')
        self.memory=self.db.suggest_memory('Own ESP32')
        self.db.decide_memory(self.memory,True)
        self.path=self.root/'ChatGPT-export.zip'
        with zipfile.ZipFile(self.path,'w',compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr('account/conversations.json',json.dumps(sample()))
            z.writestr('account/other.json','{}')
    def tearDown(self):self.dir.cleanup()

    def test_zip_import_preserves_existing_and_visible_branch(self):
        result=import_chatgpt_export(self.db,self.path)
        self.assertEqual(result['chats_with_text'],1)
        self.assertEqual(result['messages_processed'],2)
        self.assertEqual(result['events_added'],3)
        self.assertEqual(self.db.count_chats(),2)
        self.assertEqual(self.db.messages(self.existing)[1]['content'],'Hello')
        imported=[c for c in self.db.list_chats() if c['id'].startswith('chatgpt-')]
        self.assertEqual(len(imported),1)
        self.assertEqual(imported[0]['title'],'ATtiny45 Needle Stop')
        msgs=self.db.messages(imported[0]['id'])
        self.assertEqual([m['role'] for m in msgs],['user','assistant'])
        self.assertEqual(msgs[1]['provider'],'ChatGPT')
        self.assertNotIn('Wrong alternative', str(msgs))
        self.assertNotIn('private tool', str(msgs))
        self.assertEqual(len(self.db.memories('approved')),1)
        self.assertEqual(self.db.memories('pending'),[])
        self.assertTrue(Path(result['backup_path']).is_file())
        self.assertEqual(len(self.db.search('A3144')),1)

    def test_same_export_is_idempotent(self):
        first=import_chatgpt_export(self.db,self.path)
        second=import_chatgpt_export(self.db,self.path)
        self.assertEqual(first['events_added'],3)
        self.assertEqual(second['events_added'],0)
        self.assertEqual(second['already_imported'],3)
        self.assertEqual(self.db.count_chats(),2)

    def test_direct_json(self):
        file=self.root/'conversations.json'
        file.write_text(json.dumps(sample()),encoding='utf-8')
        self.assertEqual(import_chatgpt_export(self.db,file)['messages_processed'],2)

    def test_invalid_zip(self):
        path=self.root/'bad.zip';path.write_bytes(b'Not a zip')
        with self.assertRaises(ImportErrorUser):import_chatgpt_export(self.db,path)

    def test_missing_json(self):
        path=self.root/'empty.zip'
        with zipfile.ZipFile(path,'w') as z:z.writestr('foo.json','{}')
        with self.assertRaises(ImportErrorUser):import_chatgpt_export(self.db,path)

    def test_content_text_only(self):
        self.assertEqual(extract_text({'parts':['hello',{'text':'world'},{'image':'blob'}]}),'hello\n\nworld')
        self.assertEqual(extract_text({'parts':[{'asset_pointer':'abc'}]}),'')

    def test_title_browsing(self):
        import_chatgpt_export(self.db,self.path)
        self.assertEqual(len(self.db.browse_titles('ATtiny')),1)
        self.assertEqual(self.db.browse_titles('NOT FOUND'),[])

    def test_archive_context_opt_in_only(self):
        import_chatgpt_export(self.db,self.path)
        hit=self.db.relevant_archive_messages('A3144 sensor', self.existing)
        self.assertTrue(hit)
        self.assertEqual(hit[0]['title'],'ATtiny45 Needle Stop')

if __name__=='__main__':unittest.main()
