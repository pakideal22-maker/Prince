import tempfile,unittest
from pathlib import Path
from multi_assistant.db import Database
from multi_assistant.files import read_context
from multi_assistant.project_agent import project_snapshot

class AdvancedFeatures(unittest.TestCase):
    def test_cross_chat_ranks_and_cites(self):
        with tempfile.TemporaryDirectory() as d:
            db=Database(Path(d)/'my.sqlite3')
            a=db.new_chat('ATtiny45 needle up'); b=db.new_chat('Current chat')
            db.add_message(a,'user','ATtiny45 used CD4053 analog switch to stop needle up')
            db.add_message(b,'user','What is my ATtiny45 switch?')
            results=db.relevant_archive_messages('ATtiny45 CD4053 switch',b)
            self.assertTrue(results)
            self.assertEqual(results[0]['chat_id'],a)
            self.assertIn('message_id',results[0])
            self.assertIn('CD4053',results[0]['content'])
    def test_usage_migrates_and_counts(self):
        with tempfile.TemporaryDirectory() as d:
            db=Database(Path(d)/'usage.sqlite3')
            db.record_usage('Groq', True,.2,80,'',400)
            summary=db.activity_summary()['by_provider'][0]
            self.assertEqual(summary['input_estimate'],100)
            self.assertEqual(summary['output_estimate'],20)
    def test_large_text_bounded(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'long.py'
            p.write_text('A'*250_000)
            text=read_context(p)
            self.assertLess(len(text),19_000)
            self.assertIn('PARTIAL FILE',text)
    def test_project_preview_skips_secrets(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            (root/'main.py').write_text('print(123)')
            (root/'private_api_key.json').write_text('SECRET_HERE')
            data=project_snapshot(root)
            self.assertIn('main.py',data['context'])
            self.assertNotIn('SECRET_HERE',data['context'])

if __name__=='__main__':unittest.main()
