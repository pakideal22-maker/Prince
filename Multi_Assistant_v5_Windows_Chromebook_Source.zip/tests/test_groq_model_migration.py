import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from multi_assistant.config import PROVIDERS, load_settings, _migrate_models

class TestGroqModelMigration(unittest.TestCase):
    def test_new_default_is_supported_replacement(self):
        self.assertEqual(PROVIDERS['Groq']['model'], 'openai/gpt-oss-20b')

    def test_legacy_8b_migrates(self):
        self.assertEqual(_migrate_models({'Groq':'llama-3.1-8b-instant'})['Groq'], 'openai/gpt-oss-20b')

    def test_legacy_70b_migrates(self):
        self.assertEqual(_migrate_models({'Groq':'llama-3.3-70b-versatile'})['Groq'], 'openai/gpt-oss-120b')

    def test_valid_custom_model_unchanged(self):
        self.assertEqual(_migrate_models({'Groq':'openai/gpt-oss-120b'})['Groq'], 'openai/gpt-oss-120b')

    def test_existing_settings_migrates_without_overwriting_history(self):
        with tempfile.TemporaryDirectory() as d:
            settings=Path(d)/'settings.json'
            original={'models':{'Groq':'llama-3.1-8b-instant','Gemini':'custom-gemini'},'instructions':'My rules'}
            settings.write_text(json.dumps(original), encoding='utf8')
            with patch('multi_assistant.config.config_path', return_value=settings):
                config=load_settings()
            self.assertEqual(config['models']['Groq'], 'openai/gpt-oss-20b')
            self.assertEqual(config['models']['Gemini'], 'custom-gemini')
            self.assertEqual(config['instructions'], 'My rules')
            self.assertEqual(json.loads(settings.read_text()),original)

if __name__ == '__main__': unittest.main()
