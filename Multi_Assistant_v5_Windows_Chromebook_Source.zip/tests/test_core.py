import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch,MagicMock

from multi_assistant.db import Database
from multi_assistant.memory import suggest
from multi_assistant.files import write_output,read_context,extract_named_files,save_named_zip
from multi_assistant.sync import encrypt_events,decrypt_events
from multi_assistant.providers import _sse,_openai_stream,_gemini_stream,_cloudflare_stream,ProviderError


class TestDB(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.db=Database(Path(self.temp.name)/'one.db')
    def tearDown(self):self.temp.cleanup()
    def test_new_chat(self):
        chat=self.db.new_chat()
        self.assertEqual(self.db.get_chat(chat)['title'],'New Chat')
    def test_message_history(self):
        c=self.db.new_chat()
        self.db.add_message(c,'user','Hello')
        self.db.add_message(c,'assistant','Hi','Groq')
        self.assertEqual([m['role'] for m in self.db.messages(c)],['user','assistant'])
        self.assertEqual(self.db.messages(c,1)[0]['content'],'Hi')
    def test_chat_rename_delete(self):
        c=self.db.new_chat()
        self.db.rename_chat(c,'Project')
        self.assertEqual(self.db.get_chat(c)['title'],'Project')
        self.db.delete_chat(c)
        self.assertIsNone(self.db.get_chat(c))
        self.assertEqual(self.db.list_chats(),[])
    def test_memories_require_approval(self):
        m=self.db.suggest_memory('I own Arduino Uno')
        self.assertEqual(len(self.db.memories('pending')),1)
        self.assertEqual(self.db.memories('approved'),[])
        self.db.decide_memory(m,True)
        self.assertEqual(self.db.memories('approved')[0]['text'],'I own Arduino Uno')
        self.db.forget_memory(m)
        self.assertEqual(self.db.memories('approved'),[])
    def test_duplicate_memory_suggestion(self):
        self.assertIsNotNone(self.db.suggest_memory('I own Arduino Uno'))
        self.assertIsNone(self.db.suggest_memory('i own arduino uno'))
    def test_rejected_memory_not_used(self):
        m=self.db.suggest_memory('some proposal')
        self.db.decide_memory(m,False)
        self.assertEqual(self.db.memories('approved'),[])
    def test_search(self):
        c=self.db.new_chat();self.db.add_message(c,'user','Sensor A3144 works')
        self.assertEqual(len(self.db.search('A3144')),1)
        self.assertEqual(len(self.db.search('notthere')),0)
    def test_event_idempotency(self):
        events=self.db.export_device_events()
        count=len(events)
        self.db.import_events(events)
        self.assertEqual(len(self.db.export_device_events()),count)
        self.assertEqual(len(self.db.list_chats()),0)
    def test_remote_sync_merge(self):
        d2=Database(Path(self.temp.name)/'two.db')
        c1=self.db.new_chat('Windows');self.db.add_message(c1,'user','PC hello')
        c2=d2.new_chat('Chromebook');d2.add_message(c2,'user','Chromebook hello')
        self.db.import_events(d2.export_device_events())
        d2.import_events(self.db.export_device_events())
        self.assertEqual(len(self.db.list_chats()),2)
        self.assertEqual(len(d2.list_chats()),2)
        self.assertEqual(self.db.messages(c2)[0]['content'],'Chromebook hello')
        # second import must not duplicate chat or messages
        self.db.import_events(d2.export_device_events())
        self.assertEqual(len(self.db.list_chats()),2)
    def test_deleted_remote_chat_stays_deleted(self):
        d2=Database(Path(self.temp.name)/'two.db')
        c=self.db.new_chat()
        d2.import_events(self.db.export_device_events())
        self.db.delete_chat(c)
        d2.import_events(self.db.export_device_events())
        self.assertIsNone(d2.get_chat(c))
    def test_usage_summary(self):
        self.db.record_usage('Groq',True,1.5,550)
        self.db.record_usage('Gemini',False,0.5,0,'429')
        stats=self.db.activity_summary()
        self.assertEqual(stats['total'],2)
        self.assertEqual(stats['successful'],1)
        self.assertEqual(stats['failed'],1)
        self.assertEqual(stats['reply_chars'],550)

    def test_invalid_remote_event_ignored(self):
        self.db.import_events([{'event_id':'fake','device_id':'test','created_at':'now','event_type':'hack','payload':{'id':'some'}}])
        self.assertEqual(len(self.db.list_chats()),0)


class TestMemory(unittest.TestCase):
    def test_suggest_pref(self):self.assertIn('mere paas',suggest('Mere paas ESP32 aur Arduino Uno hain').lower())
    def test_no_secret(self):self.assertIsNone(suggest('I have api key: gsk_abcdefabc'))
    def test_skip_questions(self):self.assertIsNone(suggest('Mere paas konsa Arduino hai?'))
    def test_skip_short(self):self.assertIsNone(suggest('Hi'))
    def test_skip_none(self):self.assertIsNone(suggest(None))


class TestFiles(unittest.TestCase):
    def test_read_write_text(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'code.ino'
            write_output(p,'void setup() {}')
            self.assertIn('setup',read_context(p))
    def test_xlsx(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'table.xlsx';write_output(p,'Name,Value\nENA,10')
            self.assertIn('ENA',read_context(p))
    def test_docx(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'report.docx';write_output(p,'Title\nBody text')
            self.assertIn('Body text',read_context(p))
    def test_named_zip(self):
        src='```python filename=main.py\nprint(1)\n```\n```cpp filename=motor.ino\nvoid setup(){}\n```'
        found=extract_named_files(src)
        self.assertEqual(set(found),{'main.py','motor.ino'})
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'project.zip';save_named_zip(path,found)
            import zipfile
            with zipfile.ZipFile(path) as z:self.assertIn('motor.ino',z.namelist())
    def test_path_traversal_blocked(self):
        s='```python filename=../evil.py\nprint(1)\n```\n```python filename=okay.py\nprint(2)\n```'
        self.assertEqual(set(extract_named_files(s)),{'okay.py'})
    def test_invalid_extension(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):write_output(Path(d)/'x.exe','danger')


class TestDriveCrypto(unittest.TestCase):
    def test_round_trip(self):
        b=b'{"chat": "secret messages"}'
        enc=encrypt_events(b,'a long enough passphrase')
        self.assertNotIn(b'secret messages',enc)
        self.assertEqual(decrypt_events(enc,'a long enough passphrase'),b)
    def test_wrong_passphrase(self):
        with self.assertRaises(Exception):decrypt_events(encrypt_events(b'data','correct passphrase'),'wrong password okay')
    def test_min_passphrase(self):
        with self.assertRaises(ValueError):encrypt_events(b'x','too short')
    def test_bad_header(self):
        with self.assertRaises(ValueError):decrypt_events(b'not encrypted','hello world secret')


class TestSSE(unittest.TestCase):
    def test_sse_event_parsing(self):
        response=MagicMock()
        response.iter_lines.return_value=iter([b'event: content_block_delta',b'data: {"x":1}',b'',b'data: [DONE]',b''])
        self.assertEqual(list(_sse(response)), [('content_block_delta','{"x":1}'),('message','[DONE]')])
    @patch('multi_assistant.providers.get_key',return_value='test')
    @patch('multi_assistant.providers.requests.post')
    def test_groq_stream(self,post,key):
        resp=MagicMock();resp.status_code=200
        resp.iter_lines.return_value=iter([b'data: {"choices":[{"delta":{"content":"Hello"}}]}',b'',b'data: [DONE]',b''])
        post.return_value.__enter__.return_value=resp
        self.assertEqual(''.join(_openai_stream('Groq',[{'role':'user','content':'hey'}],'openai/gpt-oss-20b')),'Hello')
    @patch('multi_assistant.providers.get_key',return_value='test')
    @patch('multi_assistant.providers.requests.post')
    def test_gemini_stream(self,post,key):
        resp=MagicMock();resp.status_code=200
        resp.iter_lines.return_value=iter([b'data: {"candidates":[{"content":{"parts":[{"text":"Hi"}]}}]}',b''])
        post.return_value.__enter__.return_value=resp
        self.assertEqual(''.join(_gemini_stream([{'role':'user','content':'hello'}],'gemini-3.5-flash-lite')),'Hi')
    @patch('multi_assistant.providers.get_cloudflare_account_id', return_value='abc123')
    @patch('multi_assistant.providers.get_key', return_value='test')
    @patch('multi_assistant.providers.requests.post')
    def test_cloudflare_rest(self,post,key,account):
        resp=MagicMock();resp.status_code=200
        resp.json.return_value={'success': True, 'result': {'response': 'Cloudflare hello'}}
        post.return_value.__enter__.return_value=resp
        self.assertEqual(''.join(_cloudflare_stream([{'role':'user','content':'Hi'}], '@cf/meta/llama-3.1-8b-instruct-fp8')), 'Cloudflare hello')
        self.assertIn('/accounts/abc123/ai/run/', post.call_args.args[0])
    @patch('multi_assistant.providers.get_key',return_value='')
    def test_no_key(self,key):
        with self.assertRaises(ProviderError):list(_openai_stream('Groq',[{'role':'user','content':'hey'}],'openai/gpt-oss-20b'))

if __name__=='__main__':unittest.main()
