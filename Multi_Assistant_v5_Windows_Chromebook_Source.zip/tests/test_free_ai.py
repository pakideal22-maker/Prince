"""Free-only, endpoint and persisted configuration regression tests."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock
from multi_assistant.config import PROVIDERS,load_settings,validate_free_model
from multi_assistant.providers import _openai_stream, stream, ProviderError, available_providers

class FreeAIGuards(unittest.TestCase):
    def test_free_providers_remain_and_paid_is_optional(self):
        self.assertIn('OpenAI (Paid API)', PROVIDERS)
        for p in ('Groq','Gemini','OpenRouter Free','Cerebras Free','Cloudflare Free'):
            self.assertIn(p, PROVIDERS)
        self.assertNotIn('Claude', PROVIDERS)
        self.assertNotIn('DeepSeek', PROVIDERS)
        validate_free_model('OpenAI (Paid API)','gpt-4.1-mini')
        with self.assertRaises(ValueError):
            validate_free_model('OpenAI (Paid API)','../../wrong')

    def test_openrouter_router_is_free(self):
        validate_free_model('OpenRouter Free','openrouter/free')
        validate_free_model('OpenRouter Free','vendor/model:free')

    def test_paid_openrouter_blocked(self):
        for m in ('openai/gpt-4.1','claude-sonnet-4','vendor/model','openrouter/auto'):
            with self.assertRaises(ValueError):validate_free_model('OpenRouter Free',m)

    def test_model_validation(self):
        for p in ('Groq','Gemini','Cloudflare Free','Cerebras Free'):
            validate_free_model(p,PROVIDERS[p]['model'])
            with self.assertRaises(ValueError):validate_free_model(p,'some-paid-model')
        with self.assertRaises(ValueError):validate_free_model('OpenAI','gpt-4.1')

    def test_old_paid_saved_models_not_loaded(self):
        with tempfile.TemporaryDirectory() as d:
            conf=Path(d)/'settings.json'
            original={'models': {'Groq':'llama-3.1-8b-instant', 'OpenAI':'gpt-4.1-mini',
                                 'Claude':'claude-sonnet-4-5','DeepSeek':'deepseek-chat'},
                      'instructions':'custom user instruction'}
            conf.write_text(json.dumps(original),'utf8')
            with patch('multi_assistant.config.config_path',return_value=conf):
                current=load_settings()
            self.assertNotIn('OpenAI',current['models'])
            self.assertNotIn('Claude',current['models'])
            self.assertNotIn('DeepSeek',current['models'])
            self.assertEqual(current['models']['Groq'],'openai/gpt-oss-20b')
            self.assertEqual(current['instructions'],'custom user instruction')
            self.assertEqual(json.loads(conf.read_text()),original)

    @patch('multi_assistant.providers.get_key',return_value='sample')
    @patch('multi_assistant.providers.requests.post')
    def test_openrouter_free_endpoint_and_model(self,post,key):
        resp=MagicMock();resp.status_code=200
        resp.iter_lines.return_value=iter([b'data: {"choices":[{"delta":{"content":"Free hello"}}]}',b'',b'data: [DONE]',b''])
        post.return_value.__enter__.return_value=resp
        self.assertEqual(''.join(_openai_stream('OpenRouter Free',[{'role':'user','content':'hello'}],'openrouter/free')),'Free hello')
        self.assertEqual(post.call_args.args[0],'https://openrouter.ai/api/v1/chat/completions')
        self.assertEqual(post.call_args.kwargs['json']['model'],'openrouter/free')

    @patch('multi_assistant.providers.get_key',return_value='sample')
    @patch('multi_assistant.providers.requests.post')
    def test_cerebras_endpoint(self,post,key):
        resp=MagicMock();resp.status_code=200
        resp.iter_lines.return_value=iter([b'data: {"choices":[{"delta":{"content":"Hi"}}]}',b''])
        post.return_value.__enter__.return_value=resp
        self.assertEqual(''.join(_openai_stream('Cerebras Free',[{'role':'user','content':'Hi'}],'llama3.1-8b')),'Hi')
        self.assertEqual(post.call_args.args[0],'https://api.cerebras.ai/v1/chat/completions')

    def test_stream_refuses_paid_provider_before_network(self):
        with self.assertRaises(ProviderError):list(stream('OpenAI',[], 'gpt-4.1'))

    @patch('multi_assistant.providers.get_cloudflare_account_id',return_value='')
    @patch('multi_assistant.providers.get_key',return_value='fake')
    def test_cloudflare_no_account_not_ready(self,key,acct):
        self.assertNotIn('Cloudflare Free',available_providers())

if __name__=='__main__':unittest.main()
