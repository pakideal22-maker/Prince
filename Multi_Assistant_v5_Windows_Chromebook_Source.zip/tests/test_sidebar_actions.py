"""Sidebar action/state tests: no Qt installation required for DB regression tests."""
import sqlite3
import tempfile
import unittest
from pathlib import Path
from multi_assistant.db import Database


class SidebarDBTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'history.db'
        self.db = Database(self.path)

    def tearDown(self):
        self.tmp.cleanup()

    def test_pin_sorts_first_and_unpin(self):
        a = self.db.new_chat('Arduino')
        b = self.db.new_chat('Gemini')
        self.assertEqual(self.db.list_chats()[0]['id'], b)
        self.db.pin_chat(a)
        self.assertTrue(self.db.get_chat(a)['pinned'])
        self.assertEqual(self.db.list_chats()[0]['id'], a)
        self.db.pin_chat(a, False)
        self.assertFalse(self.db.get_chat(a)['pinned'])
        self.assertEqual(self.db.list_chats()[0]['id'], b)

    def test_archive_retains_history_restores(self):
        a = self.db.new_chat('Archive test')
        self.db.add_message(a, 'assistant', 'Important wiring information', 'Gemini')
        self.db.archive_chat(a, True)
        self.assertEqual(self.db.count_chats(), 0)
        self.assertEqual(self.db.count_archived(), 1)
        self.assertEqual(self.db.get_chat(a)['title'], 'Archive test')
        self.assertEqual(len(self.db.messages(a)), 1)
        self.db.archive_chat(a, False)
        self.assertEqual(self.db.count_archived(), 0)
        self.assertEqual(self.db.count_chats(), 1)
        self.assertEqual(self.db.messages(a)[0]['content'], 'Important wiring information')

    def test_deleted_chat_stays_deleted(self):
        a = self.db.new_chat('Delete test')
        self.db.delete_chat(a)
        self.assertIsNone(self.db.get_chat(a))
        self.assertFalse(self.db.list_chats())

    def test_multiple_devices_sync_new_events(self):
        b = Database(Path(self.tmp.name) / 'chromebook.db')
        c = self.db.new_chat('First')
        self.db.add_message(c, 'user', 'Kept on both')
        b.import_events(self.db.export_device_events())
        self.db.rename_chat(c, 'Renamed')
        self.db.pin_chat(c, True)
        self.db.archive_chat(c, True)
        b.import_events(self.db.export_device_events())
        self.assertEqual(b.get_chat(c)['title'], 'Renamed')
        self.assertTrue(b.get_chat(c)['pinned'])
        self.assertTrue(b.get_chat(c)['archived'])
        self.assertEqual(b.messages(c)[0]['content'], 'Kept on both')
        self.assertEqual(b.count_archived(), 1)
        self.db.archive_chat(c,False)
        b.import_events(self.db.export_device_events())
        self.assertFalse(b.get_chat(c)['archived'])
        self.assertEqual(b.list_chats()[0]['id'], c)

    def test_remote_out_of_order_projection_rebuild_preserves_flags(self):
        b = Database(Path(self.tmp.name) / 'chromebook.db')
        c = self.db.new_chat('New folder')
        self.db.pin_chat(c)
        self.db.archive_chat(c)
        # b writes newer event before receiving old history, forcing chronological replay.
        b.new_chat('Other machine')
        b.import_events(self.db.export_device_events())
        self.assertTrue(b.get_chat(c)['pinned'])
        self.assertTrue(b.get_chat(c)['archived'])

    def test_invalid_remote_pin_is_ignored(self):
        c = self.db.new_chat('Test')
        fake = {
            'event_id': 'new_fake_event', 'device_id':'other',
            'created_at': '2027-01-01T00:00:00Z',
            'event_type':'chat_pin', 'payload':{'id': c, 'value': 'yes'}
        }
        self.assertEqual(self.db.import_events([fake]), 0)
        self.assertFalse(self.db.get_chat(c)['pinned'])

    def test_legacy_schema_is_upgraded_without_losing_data(self):
        legacy_path=Path(self.tmp.name) / 'old_v3.db'
        with sqlite3.connect(legacy_path) as conn:
            conn.execute('CREATE TABLE chats (id TEXT PRIMARY KEY, title TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0)')
            conn.execute('INSERT INTO chats VALUES (?,?,?,?,0)', ('legacy','Before update','2026-10-25','2026-10-25'))
        converted=Database(legacy_path)
        chat=converted.get_chat('legacy')
        self.assertEqual(chat['title'], 'Before update')
        self.assertFalse(chat['pinned'])
        self.assertFalse(chat['archived'])
        converted.pin_chat('legacy')
        self.assertTrue(converted.get_chat('legacy')['pinned'])

    def test_ui_has_menu_and_confirmation(self):
        src=(Path(__file__).parents[1] / 'multi_assistant' / 'ui.py').read_text(encoding='utf-8')
        for phrase in ['Conversation options', 'Pin to top', 'Rename', 'Archive',
                       'Export as TXT', 'Delete conversation', 'Archived conversations']:
            self.assertIn(phrase, src)

if __name__ == '__main__': unittest.main()
