import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from multi_assistant.db import Database
from multi_assistant.project_agent import preview_edits,apply_edits_approved,inspect_project_tests
from multi_assistant.files import extract_project_files
from multi_assistant.research import research_sources,research_context,source_appendix,ResearchError

class MandatoryV5(unittest.TestCase):
    def test_memory_fts_persists_after_restart_and_sync(self):
        with tempfile.TemporaryDirectory() as p:
            path=Path(p)/'db.sqlite3';db=Database(path)
            old=db.new_chat('Needle Stop Project');db.add_message(old,'user','ATtiny45 plus CD4053 motor position')
            current=db.new_chat('Current')
            self.assertTrue(db.relevant_archive_messages('ATtiny45 CD4053',current))
            count=db.memory_index_count()
            self.assertGreaterEqual(count,1)
            new=Database(path)
            refs=new.relevant_archive_messages('CD4053 motor',current)
            self.assertEqual(refs[0]['chat_id'],old)
            self.assertTrue(refs[0]['message_id'])
            self.assertEqual(new.memory_index_count(),count)
            new.delete_chat(old)
            self.assertEqual(new.relevant_archive_messages('CD4053 motor',current),[])
    def test_older_remote_replay_reindexes(self):
        with tempfile.TemporaryDirectory() as p:
            a=Database(Path(p)/'one.db');b=Database(Path(p)/'two.db')
            chat=a.new_chat('Sewing control');a.add_message(chat,'user','needle CD4053 controller')
            # Newer local projection first, older incoming requires replay.
            bchat=b.new_chat('fresh');b.add_message(bchat,'user','hello world')
            b.import_events(a.export_device_events())
            refs=b.relevant_archive_messages('needle CD4053')
            self.assertEqual(refs[0]['chat_id'],chat)
            self.assertEqual(len(refs),1)
            self.assertGreaterEqual(b.memory_index_count(),2)
    def test_coding_patch_preview_approval_backup(self):
        with tempfile.TemporaryDirectory() as p:
            root=Path(p)/'ORION_TEST';root.mkdir();(root/'orion').mkdir()
            path=root/'orion'/'market.py';path.write_text('print(1)\n','utf-8')
            plan=preview_edits(root,{'orion/market.py':'print(2)\n','tests/test_unit.py':'pass\n'})
            self.assertIn('-print(1)',plan['diff'])
            self.assertEqual(path.read_text(),'print(1)\n') # no changes before approval
            report=apply_edits_approved(plan)
            self.assertEqual(path.read_text(),'print(2)\n')
            self.assertTrue((Path(report['backup'])/'orion'/'market.py').exists())
            self.assertTrue((root/'tests'/'test_unit.py').exists())
            self.assertEqual(inspect_project_tests(root)['failures'],[])
    def test_unsafe_paths_denied(self):
        with tempfile.TemporaryDirectory() as p:
            root=Path(p)
            for bad in ('../oops.py','secrets.py','module.env','/etc/passwd','orion/.env','orion/private_key.py'):
                with self.assertRaises(ValueError, msg=bad):preview_edits(root,{bad:'hello'})
            (root/'a.py').write_text('old','utf-8')
            plan=preview_edits(root,{'a.py':'new'})
            (root/'a.py').write_text('race','utf-8')
            with self.assertRaises(ValueError):apply_edits_approved(plan)
            self.assertEqual((root/'a.py').read_text(),'race')
    def test_nested_code_markers(self):
        answer='```python filename=orion/market.py\nprint(2)\n```'
        self.assertEqual(extract_project_files(answer),{'orion/market.py':'print(2)\n'})
    @patch('multi_assistant.research._fetch_text',return_value='Some corroborating page content')
    @patch('multi_assistant.research._public_url',return_value=True)
    @patch('multi_assistant.research.requests.get')
    def test_web_sources_grounded_and_deduped(self,get,_,__):
        response=get.return_value
        response.raise_for_status.return_value=None
        response.json.return_value={'web':{'results':[
            {'title':'Source A','url':'https://a.example/article','description':'Evidence A'},
            {'title':'Again A','url':'https://a.example/article','description':'duplicate'},
            {'title':'Source B','url':'https://b.example/post','description':'Evidence B'}]}}
        sources=research_sources('test','key')
        self.assertEqual(len(sources),2)
        context=research_context(sources,'test')
        self.assertIn('[1]',context)
        self.assertIn('https://b.example/post',source_appendix(sources))
    def test_no_search_with_missing_key(self):
        with self.assertRaises(ResearchError):research_sources('test','')

if __name__=='__main__':unittest.main()
