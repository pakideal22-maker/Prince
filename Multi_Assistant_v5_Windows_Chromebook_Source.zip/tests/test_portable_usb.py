import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from multi_assistant import portable_vault
from multi_assistant import config
from multi_assistant.db import Database


class PortableUSBTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.ev=patch.dict(os.environ, {'MULTI_ASSISTANT_PORTABLE_HOME':self.temp.name})
        self.ev.start()
        portable_vault._SECRETS=None
        portable_vault._PASSWORD=None

    def tearDown(self):
        portable_vault._SECRETS=None
        portable_vault._PASSWORD=None
        self.ev.stop()
        self.temp.cleanup()

    def test_data_stays_on_usb(self):
        self.assertEqual(config.data_dir(),Path(self.temp.name)/'Data')

    def test_vault_round_trip_and_no_plain_keys(self):
        portable_vault.unlock('masterpassword1234',create=True)
        config.put_key('Groq','gsk_DONT_STORE_PLAINTEXT')
        config.save_sync_passphrase('my sync password safe')
        path=portable_vault.secrets_file()
        self.assertNotIn('DONT_STORE_PLAINTEXT',path.read_text())
        self.assertNotIn('my sync password safe',path.read_text())
        portable_vault._SECRETS=None
        portable_vault._PASSWORD=None
        portable_vault.unlock('masterpassword1234')
        self.assertEqual(config.get_key('Groq'),'gsk_DONT_STORE_PLAINTEXT')
        self.assertEqual(config.get_sync_passphrase(),'my sync password safe')

    def test_wrong_password_protects_vault(self):
        portable_vault.unlock('masterpassword1234',create=True)
        portable_vault.set_secret('token','secret')
        portable_vault._SECRETS=None
        portable_vault._PASSWORD=None
        with self.assertRaises(Exception):
            portable_vault.unlock('wrongpassword9876')
        self.assertIsNone(portable_vault._SECRETS)

    def test_create_requires_minimum_password(self):
        with self.assertRaises(ValueError):
            portable_vault.unlock('short',create=True)

    def test_db_keeps_old_windows_separate(self):
        db=Database()
        chat=db.new_chat('Portable only')
        self.assertEqual(db.get_chat(chat)['title'],'Portable only')
        self.assertEqual(db.path.parent,Path(self.temp.name)/'Data')

    def test_credentials_on_usb_vault(self):
        portable_vault.unlock('masterpassword1234',create=True)
        config.save_cloudflare_account_id('ABC123')
        self.assertEqual(config.get_cloudflare_account_id(),'ABC123')
        config.save_cloudflare_account_id('')
        self.assertEqual(config.get_cloudflare_account_id(),'')

if __name__=='__main__':unittest.main()
