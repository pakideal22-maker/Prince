#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export MULTI_ASSISTANT_PORTABLE_HOME="$PWD"
if [[ ! -x .venv/bin/python ]]; then
  echo 'First-time setup needs Python 3, venv, internet, and Chromebook Linux (x86_64).'
  python3 -m venv .venv
  .venv/bin/python -m pip install -r requirements.txt -r requirements_drive.txt
fi
.venv/bin/python main.py
