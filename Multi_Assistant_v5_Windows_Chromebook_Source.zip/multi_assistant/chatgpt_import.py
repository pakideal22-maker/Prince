"""Offline, permissioned import of ChatGPT data-export conversations.json / ZIP.

Imports text-only user/assistant messages into the event-based database without
changing existing chats. Source IDs ensure idempotent re-imports. ChatGPT image,
audio, file blobs, private model reasoning and tool messages are not imported.
"""
from __future__ import annotations

from datetime import datetime, timezone, timedelta
import json
from pathlib import Path
import sqlite3
import uuid
import zipfile
from contextlib import closing

from .db import utc_now

NAMESPACE = uuid.UUID('a04c4411-15e5-445e-aeca-40d333e5b3ba')
MAX_ARCHIVE_BYTES = 200 * 1024 * 1024
MAX_MESSAGE_CHARS = 150000
MAX_CONVERSATIONS = 200000


class ImportErrorUser(ValueError):
    pass


def _time(value, fallback: str) -> str:
    try:
        if value is None:
            return fallback
        if isinstance(value, str):
            # ChatGPT history sometimes contains ISO strings.
            result = datetime.fromisoformat(value.replace('Z', '+00:00'))
            if result.tzinfo is None:
                result = result.replace(tzinfo=timezone.utc)
        else:
            result = datetime.fromtimestamp(float(value), tz=timezone.utc)
        return result.astimezone(timezone.utc).isoformat(timespec='microseconds')
    except (ValueError, TypeError, OverflowError, OSError):
        return fallback


def _id(kind: str, key: str) -> str:
    return str(uuid.uuid5(NAMESPACE, f'chatgpt:{kind}:{key}'))


def _part_text(part) -> str:
    if isinstance(part, str):
        return part
    if isinstance(part, dict):
        # Only known textual fields. Never stringify blobs or metadata.
        if isinstance(part.get('text'), str):
            return part['text']
        if isinstance(part.get('content'), str):
            return part['content']
    return ''


def extract_text(content) -> str:
    if isinstance(content, str):
        return content.strip()
    if not isinstance(content, dict):
        return ''
    parts = content.get('parts')
    if isinstance(parts, list):
        return '\n\n'.join(filter(None, (_part_text(p).strip() for p in parts))).strip()
    for key in ('text', 'result'):
        if isinstance(content.get(key), str):
            return content[key].strip()
    return ''


def _messages(conversation):
    """Use the visible conversation branch, not abandoned alternate branches."""
    mapping = conversation.get('mapping')
    if isinstance(mapping, dict) and mapping:
        current = conversation.get('current_node')
        if current in mapping:
            ancestry = []
            seen = set()
            while current in mapping and current not in seen:
                seen.add(current)
                node = mapping[current]
                if not isinstance(node, dict):
                    break
                ancestry.append((current, node.get('message')))
                current = node.get('parent')
            ancestry.reverse()
        else:
            ancestry = [(k, node.get('message')) for k,node in mapping.items() if isinstance(node,dict)]
            ancestry.sort(key=lambda x: (str((x[1] or {}).get('create_time') or ''), str(x[0])))
        return ancestry
    # Defensive support for simplified conversation exports.
    msgs=conversation.get('messages')
    if isinstance(msgs, list):
        return [(str(m.get('id',n)) if isinstance(m,dict) else str(n),m)
                for n,m in enumerate(msgs)]
    return []


def _open_history(path: Path):
    if not path.is_file():
        raise ImportErrorUser('Selected export file was not found.')
    if path.suffix.lower() == '.zip':
        try:
            with zipfile.ZipFile(path) as z:
                choices=[i for i in z.infolist() if not i.is_dir() and
                         i.filename.replace('\\','/').split('/')[-1].lower()=='conversations.json']
                if not choices:
                    raise ImportErrorUser('ZIP mein conversations.json nahi mila.')
                item = sorted(choices, key=lambda i:(i.filename.count('/'),len(i.filename)))[0]
                if item.file_size > MAX_ARCHIVE_BYTES:
                    raise ImportErrorUser('conversations.json is too large for this version (200 MB limit).')
                with z.open(item) as f:
                    raw = f.read(MAX_ARCHIVE_BYTES+1)
        except zipfile.BadZipFile as exc:
            raise ImportErrorUser('This is not a valid ZIP file.') from exc
    elif path.suffix.lower() == '.json':
        if path.stat().st_size > MAX_ARCHIVE_BYTES:
            raise ImportErrorUser('JSON is too large for this version (200 MB limit).')
        raw=path.read_bytes()
    else:
        raise ImportErrorUser('Select a ChatGPT export ZIP or conversations.json file.')
    if len(raw) > MAX_ARCHIVE_BYTES:
        raise ImportErrorUser('Export is larger than 200 MB.')
    try:
        data=json.loads(raw.decode('utf-8-sig'))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ImportErrorUser('Could not read conversations.json as valid UTF-8 JSON.') from exc
    if isinstance(data, dict):
        data=data.get('conversations')
    if not isinstance(data,list) or len(data)>MAX_CONVERSATIONS:
        raise ImportErrorUser('Unsupported ChatGPT conversations.json format.')
    return data


def _events_from_export(data, device_id: str, callback=None):
    events=[]
    counts={'conversations_found':len(data),'chats_with_text':0,'messages_processed':0,
            'skipped_empty_or_nontext':0, 'truncated_messages':0}
    fallback=utc_now()
    for index,conv in enumerate(data):
        if not isinstance(conv, dict):
            continue
        original_id=str(conv.get('id') or conv.get('conversation_id') or f'fallback-{index}-{conv.get("title","")}')
        chat_id='chatgpt-'+_id('chat',original_id)
        items=[]
        conv_time=_time(conv.get('create_time'),fallback)
        for order,(node_id,message) in enumerate(_messages(conv)):
            if not isinstance(message,dict):
                counts['skipped_empty_or_nontext']+=1
                continue
            author=message.get('author')
            role=(author.get('role','') if isinstance(author,dict) else author)
            if role not in ('user','assistant'):
                continue
            metadata=message.get('metadata') or {}
            if isinstance(metadata,dict) and metadata.get('is_visually_hidden_from_conversation'):
                continue
            # Only output shown in the conversation, no internal/tool-directed messages.
            recipient=message.get('recipient')
            if recipient not in (None,'all'):
                continue
            if isinstance(metadata,dict) and metadata.get('channel') in ('analysis','commentary','justify','confidence'):
                continue
            contents=extract_text(message.get('content',{}))
            if not contents:
                counts['skipped_empty_or_nontext']+=1
                continue
            if len(contents)>MAX_MESSAGE_CHARS:
                contents=contents[:MAX_MESSAGE_CHARS]+'\n\n[Message truncated during import]'
                counts['truncated_messages']+=1
            mid=str(message.get('id') or node_id or order)
            msg_id='chatgpt-'+_id('msg', original_id+':'+mid)
            # A missing message timestamp is assigned a stable point after chat creation.
            t=_time(message.get('create_time'),
                    (datetime.fromisoformat(conv_time)+timedelta(microseconds=order+1)).isoformat(timespec='microseconds'))
            items.append((t,order,msg_id,role,contents))
        if not items:
            continue
        counts['chats_with_text']+=1
        title=str(conv.get('title') or 'Imported ChatGPT Chat').strip()[:100]
        chat_created=min([conv_time]+[t for t,_,_,_,_ in items])
        events.append(dict(event_id='0-'+_id('evt-chat',original_id),device_id=device_id,
                           created_at=chat_created,event_type='chat_create',
                           payload={'id':chat_id,'title':title}))
        for t,order,msg_id,role,content in items:
            events.append(dict(event_id='1-'+_id('evt-msg',original_id+':'+msg_id),
                               device_id=device_id, created_at=t,event_type='message',
                               payload={'id':msg_id,'chat_id':chat_id,'role':role,
                                        'content':content,'provider':'ChatGPT' if role=='assistant' else ''}))
            counts['messages_processed']+=1
        if callback and index % 100 == 0:
            callback(f'Preparing ChatGPT history: {index+1}/{len(data)} chats')
    return events,counts


def import_chatgpt_export(db, path: Path, callback=None):
    """Back up the existing SQLite data, then import idempotent event IDs.

    No long-term memories are approved or suggested as a side effect.
    """
    data=_open_history(Path(path))
    if callback: callback(f'Found {len(data)} exported conversations. Making a local backup...')
    backup_dir=db.path.parent/'backups';backup_dir.mkdir(parents=True,exist_ok=True)
    backup=backup_dir/('before_chatgpt_import_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite3')
    # Backup via SQLite API, not copying the WAL/SHM in-use database files.
    with closing(sqlite3.connect(db.path)) as source, closing(sqlite3.connect(backup)) as target:
        source.backup(target)
    if callback: callback('Preparing imported messages...')
    events,counts=_events_from_export(data,db.device_id,callback)
    del data
    if callback: callback('Adding conversations to local database (this may take time)...')
    count=db.import_events(events)
    counts['events_added']=count
    counts['already_imported']=len(events)-count
    counts['backup_path']=str(backup)
    return counts
