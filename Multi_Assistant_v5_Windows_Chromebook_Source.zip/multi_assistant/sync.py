"""Encrypted, per-device append-only event logs in Google Drive appDataFolder.

Requires a user-provided OAuth Desktop client JSON and a shared sync passphrase.
No shared SQLite file is ever directly modified across devices.
"""
from __future__ import annotations
import base64
import io
import json
import os
from pathlib import Path
from .config import data_dir
from . import portable_vault
from .db import Database

NAME_PREFIX='multi_assistant_events_'
SCOPES=['https://www.googleapis.com/auth/drive.appdata']


def encrypt_events(data: bytes, passphrase: str)->bytes:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    if len(passphrase)<12:raise ValueError('Sync passphrase kam se kam 12 characters ho.')
    salt=os.urandom(16)
    key=Scrypt(salt=salt,length=32,n=2**14,r=8,p=1).derive(passphrase.encode('utf-8'))
    nonce=os.urandom(12)
    return b'MAS1'+salt+nonce+AESGCM(key).encrypt(nonce,data,None)


def decrypt_events(blob:bytes,passphrase:str)->bytes:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    if not blob.startswith(b'MAS1') or len(blob)<49:
        raise ValueError('Drive sync file format not recognized.')
    salt,nonce=blob[4:20],blob[20:32]
    key=Scrypt(salt=salt,length=32,n=2**14,r=8,p=1).derive(passphrase.encode('utf-8'))
    return AESGCM(key).decrypt(nonce,blob[32:],None)


def _service():
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build
    oauth_file=data_dir()/'google_oauth_client.json'
    token_file=data_dir()/'google_token.json'
    if not oauth_file.exists():
        raise ValueError('Google OAuth Desktop JSON missing. Settings > Drive Setup instructions dekho.')
    creds=None
    if portable_vault.is_portable():
        saved=portable_vault.get_secret('google_token_json')
        if saved:creds=Credentials.from_authorized_user_info(json.loads(saved),SCOPES)
    elif token_file.exists():
        creds=Credentials.from_authorized_user_file(str(token_file),SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            creds=InstalledAppFlow.from_client_secrets_file(str(oauth_file),SCOPES).run_local_server(port=0)
        if portable_vault.is_portable():
            portable_vault.set_secret('google_token_json',creds.to_json())
        else:
            token_file.write_text(creds.to_json(),encoding='utf-8')
            try:token_file.chmod(0o600)
            except OSError:pass
    return build('drive','v3',credentials=creds,cache_discovery=False)


def sync_once(db:Database, passphrase:str)->tuple[int,int]:
    """Download every peer log, idempotently import, upload only own device log.
    Returns (remote events fetched, local events uploaded).
    """
    from googleapiclient.http import MediaIoBaseUpload
    service=_service()
    own_name=NAME_PREFIX+db.device_id+'.bin'
    docs=[]
    token=None
    while True:
        resp=service.files().list(q="name contains 'multi_assistant_events_' and trashed = false",
                 spaces='appDataFolder',fields='nextPageToken,files(id,name)',
                 pageSize=1000,pageToken=token).execute()
        docs.extend(resp.get('files',[]))
        token=resp.get('nextPageToken')
        if not token:break
    downloaded=0
    for f in docs:
        if not f['name'].startswith(NAME_PREFIX) or not f['name'].endswith('.bin'):
            continue
        if f['name']==own_name:
            continue
        ciphertext=service.files().get_media(fileId=f['id']).execute()
        plaintext=decrypt_events(ciphertext,passphrase)
        obj=json.loads(plaintext)
        if not isinstance(obj,dict) or obj.get('format')!=1 or not isinstance(obj.get('events'),list):
            raise ValueError('Unexpected remote sync content.')
        # Do not import arbitrary events from a mismatched device source.
        expected=f['name'][len(NAME_PREFIX):-4]
        if any(x.get('device_id')!=expected for x in obj['events']):
            raise ValueError('Remote sync events have mismatched device ID.')
        db.import_events(obj['events'])
        downloaded+=len(obj['events'])
    own=db.export_device_events()
    blob=encrypt_events(json.dumps({'format':1,'device_id':db.device_id,
                'events':own},ensure_ascii=False).encode('utf-8'),passphrase)
    media=MediaIoBaseUpload(io.BytesIO(blob),mimetype='application/octet-stream',resumable=False)
    own_docs=[d for d in docs if d['name']==own_name]
    if own_docs:
        service.files().update(fileId=own_docs[0]['id'],media_body=media).execute()
    else:
        service.files().create(body={'name':own_name,'parents':['appDataFolder']},
                 media_body=media,fields='id').execute()
    return downloaded,len(own)
