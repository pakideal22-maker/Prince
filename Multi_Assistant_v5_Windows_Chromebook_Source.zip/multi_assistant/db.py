"""SQLite projections + per-device append-only event log for conflict-tolerant sync."""
from __future__ import annotations
import json
import sqlite3
from contextlib import contextmanager
import uuid
from datetime import datetime, timezone
from pathlib import Path
from .config import data_dir


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='microseconds')


class Database:
    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path else data_dir() / 'chats.sqlite3'
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as cx:
            cx.executescript('''
            CREATE TABLE IF NOT EXISTS meta (name TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events (
              event_id TEXT PRIMARY KEY, device_id TEXT NOT NULL, created_at TEXT NOT NULL,
              event_type TEXT NOT NULL, payload TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_events_time ON events(created_at, event_id);
            CREATE TABLE IF NOT EXISTS chats (
              id TEXT PRIMARY KEY, title TEXT NOT NULL, created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0,
              pinned INTEGER NOT NULL DEFAULT 0,
              archived INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS messages (
              id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, role TEXT NOT NULL,
              content TEXT NOT NULL, provider TEXT, created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, created_at, id);
            CREATE TABLE IF NOT EXISTS memories (
              id TEXT PRIMARY KEY, text TEXT NOT NULL, state TEXT NOT NULL,
              created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS usage_events (
              id TEXT PRIMARY KEY, time TEXT NOT NULL, provider TEXT NOT NULL,
              ok INTEGER NOT NULL, duration_s REAL NOT NULL, chars INTEGER NOT NULL,
              error TEXT NOT NULL DEFAULT ''
            );
            ''')
            # Upgrade existing v3.3 databases in place; never drop existing chats.
            columns={r['name'] for r in cx.execute('PRAGMA table_info(chats)').fetchall()}
            if 'pinned' not in columns:
                cx.execute('ALTER TABLE chats ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0')
            if 'archived' not in columns:
                cx.execute('ALTER TABLE chats ADD COLUMN archived INTEGER NOT NULL DEFAULT 0')
            usage_columns={r['name'] for r in cx.execute('PRAGMA table_info(usage_events)')}
            for field in ('input_estimate','output_estimate'):
                if field not in usage_columns:
                    cx.execute(f'ALTER TABLE usage_events ADD COLUMN {field} INTEGER NOT NULL DEFAULT 0')
            # FTS5 is a local derived index: never sent in Drive sync events.
            # Trigger maintenance also handles imports, deletes, and full replay.
            try:
                cx.executescript('''
                CREATE VIRTUAL TABLE IF NOT EXISTS message_fts USING fts5(
                  content, content='messages', content_rowid='rowid', tokenize='unicode61');
                CREATE TRIGGER IF NOT EXISTS msg_fts_insert AFTER INSERT ON messages BEGIN
                  INSERT INTO message_fts(rowid,content) VALUES(new.rowid,new.content);
                END;
                CREATE TRIGGER IF NOT EXISTS msg_fts_delete AFTER DELETE ON messages BEGIN
                  INSERT INTO message_fts(message_fts,rowid,content) VALUES('delete',old.rowid,old.content);
                END;
                CREATE TRIGGER IF NOT EXISTS msg_fts_update AFTER UPDATE OF content ON messages BEGIN
                  INSERT INTO message_fts(message_fts,rowid,content) VALUES('delete',old.rowid,old.content);
                  INSERT INTO message_fts(rowid,content) VALUES(new.rowid,new.content);
                END;
                ''')
                # A one-time rebuild for databases upgraded from an older version.
                if cx.execute("SELECT value FROM meta WHERE name='fts5_ready'").fetchone() is None:
                    cx.execute("INSERT INTO message_fts(message_fts) VALUES('rebuild')")
                    cx.execute("INSERT INTO meta(name,value) VALUES('fts5_ready','1')")
            except sqlite3.OperationalError:
                # Older SQLite builds without FTS5 fall back to keyword retrieval.
                pass
            row = cx.execute("SELECT value FROM meta WHERE name='device_id'").fetchone()
            if not row:
                cx.execute("INSERT INTO meta(name,value) VALUES('device_id',?)", (str(uuid.uuid4()),))
        self.device_id = self._device_id()

    @contextmanager
    def _conn(self):
        cx = sqlite3.connect(self.path, timeout=15)
        try:
            cx.row_factory = sqlite3.Row
            cx.execute('PRAGMA busy_timeout = 15000')
            cx.execute('PRAGMA journal_mode = WAL')
            with cx:
                yield cx
        finally:
            cx.close()

    def _device_id(self):
        with self._conn() as cx:
            return cx.execute("SELECT value FROM meta WHERE name='device_id'").fetchone()['value']

    def _emit(self, kind: str, payload: dict):
        event = dict(event_id=str(uuid.uuid4()), device_id=self.device_id,
                     created_at=utc_now(), event_type=kind, payload=payload)
        self.import_events([event])
        return payload.get('id')

    def new_chat(self, title='New Chat'):
        id_ = str(uuid.uuid4())
        self._emit('chat_create', {'id': id_, 'title': title[:100]})
        return id_

    def rename_chat(self, id_, title):
        self._emit('chat_rename', {'id': id_, 'title': title[:100]})

    def delete_chat(self, id_):
        self._emit('chat_delete', {'id': id_})

    def pin_chat(self, id_, pinned=True):
        if self.get_chat(id_):
            self._emit('chat_pin', {'id': id_, 'value': bool(pinned)})

    def archive_chat(self, id_, archived=True):
        if self.get_chat(id_):
            self._emit('chat_archive', {'id': id_, 'value': bool(archived)})

    def add_message(self, chat_id, role, content, provider=''):
        id_ = str(uuid.uuid4())
        self._emit('message', {'id': id_, 'chat_id': chat_id, 'role': role,
                               'content': content, 'provider': provider})
        return id_

    def suggest_memory(self, text):
        text = text.strip()
        if not text or len(text) > 700:
            return None
        # Avoid duplicates among active/pending.
        with self._conn() as cx:
            if cx.execute("SELECT 1 FROM memories WHERE lower(text)=lower(?) AND state!='rejected'", (text,)).fetchone():
                return None
        id_ = str(uuid.uuid4())
        self._emit('memory_suggest', {'id': id_, 'text': text})
        return id_

    def decide_memory(self, id_, approve: bool):
        self._emit('memory_decision', {'id': id_, 'state': 'approved' if approve else 'rejected'})

    def forget_memory(self, id_):
        self._emit('memory_delete', {'id': id_})

    def _apply(self, cx, event):
        kind, p, at = event['event_type'], event['payload'], event['created_at']
        if kind == 'chat_create':
            cx.execute('INSERT OR IGNORE INTO chats (id,title,created_at,updated_at,deleted,pinned,archived) VALUES (?,?,?,?,0,0,0)', (p['id'], p['title'], at, at))
        elif kind == 'chat_rename':
            cx.execute('UPDATE chats SET title=?,updated_at=? WHERE id=?', (p['title'], at, p['id']))
        elif kind == 'chat_delete':
            cx.execute('UPDATE chats SET deleted=1,updated_at=? WHERE id=?', (at, p['id']))
        elif kind == 'chat_pin':
            cx.execute('UPDATE chats SET pinned=? WHERE id=? AND deleted=0', (int(p['value']), p['id']))
        elif kind == 'chat_archive':
            cx.execute('UPDATE chats SET archived=? WHERE id=? AND deleted=0', (int(p['value']), p['id']))
        elif kind == 'message':
            cx.execute('INSERT OR IGNORE INTO messages VALUES (?,?,?,?,?,?)',
                       (p['id'], p['chat_id'], p['role'], p['content'], p.get('provider',''), at))
            cx.execute('UPDATE chats SET updated_at=? WHERE id=? AND updated_at < ?',
                       (at, p['chat_id'], at))
        elif kind == 'memory_suggest':
            cx.execute('INSERT OR IGNORE INTO memories VALUES (?,?,?,?,?)',
                       (p['id'], p['text'], 'pending', at, at))
        elif kind == 'memory_decision':
            cx.execute('UPDATE memories SET state=?,updated_at=? WHERE id=?',
                       (p['state'], at, p['id']))
        elif kind == 'memory_delete':
            cx.execute("UPDATE memories SET state='deleted',updated_at=? WHERE id=?", (at, p['id']))

    @staticmethod
    def _validated(event):
        if not isinstance(event, dict):
            return False
        if not all(isinstance(event.get(k), str) and 0 < len(event[k]) < 150
                   for k in ('event_id', 'device_id', 'created_at', 'event_type')):
            return False
        if event['event_type'] not in {'chat_create','chat_rename','chat_delete','chat_pin','chat_archive','message',
                                     'memory_suggest','memory_decision','memory_delete'}:
            return False
        p=event.get('payload')
        if not isinstance(p, dict) or not isinstance(p.get('id'), str) or len(p['id']) > 100:
            return False
        if len(json.dumps(p, ensure_ascii=False)) > 400000:
            return False
        if event['event_type'] == 'message' and (p.get('role') not in {'user','assistant'} or
           not isinstance(p.get('chat_id'),str) or not isinstance(p.get('content'),str)):
            return False
        if event['event_type'] in ('chat_create','chat_rename','memory_suggest') and not isinstance(p.get('title' if event['event_type'].startswith('chat_') else 'text'),str):
            return False
        if event['event_type']=='memory_decision' and p.get('state') not in ('approved','rejected'):
            return False
        if event['event_type'] in ('chat_pin','chat_archive') and type(p.get('value')) is not bool:
            return False
        return True

    def import_events(self, events):
        """Import idempotently, rebuild projection in chronological order when new remote events arrive."""
        incoming=[]
        for e in events:
            if self._validated(e):
                incoming.append(e)
        with self._conn() as cx:
            old_last=cx.execute('SELECT created_at,event_id FROM events ORDER BY created_at DESC,event_id DESC LIMIT 1').fetchone()
            accepted=[]
            for e in incoming:
                cur=cx.execute('INSERT OR IGNORE INTO events VALUES (?,?,?,?,?)',
                           (e['event_id'],e['device_id'],e['created_at'],e['event_type'],
                            json.dumps(e['payload'],ensure_ascii=False)))
                if cur.rowcount:
                    accepted.append(e)
            # New local events are almost always newer; incremental projection is fast.
            # Older remote events require deterministic chronological replay.
            if accepted:
                new_order=sorted(accepted,key=lambda e:(e['created_at'],e['event_id']))
                needs_replay=(old_last is not None and (new_order[0]['created_at'],new_order[0]['event_id'])<
                              (old_last['created_at'],old_last['event_id']))
                if needs_replay:
                    cx.execute('DELETE FROM chats')
                    cx.execute('DELETE FROM messages')
                    cx.execute('DELETE FROM memories')
                    for row in cx.execute('SELECT * FROM events ORDER BY created_at,event_id').fetchall():
                        self._apply(cx, {'event_type':row['event_type'],
                                         'payload':json.loads(row['payload']), 'created_at':row['created_at']})
                else:
                    for e in new_order:
                        self._apply(cx,e)
        return len(accepted)

    def export_device_events(self):
        with self._conn() as cx:
            return [dict(event_id=r['event_id'], device_id=r['device_id'], created_at=r['created_at'],
                         event_type=r['event_type'], payload=json.loads(r['payload']))
                    for r in cx.execute('SELECT * FROM events WHERE device_id=? ORDER BY created_at,event_id',
                                        (self.device_id,)).fetchall()]

    def list_chats(self, limit=350):
        with self._conn() as cx:
            return [dict(r) for r in cx.execute(
                'SELECT * FROM chats WHERE deleted=0 AND archived=0 ORDER BY pinned DESC, updated_at DESC LIMIT ?', (limit,)).fetchall()]

    def count_chats(self):
        with self._conn() as cx:
            return cx.execute('SELECT count(*) FROM chats WHERE deleted=0 AND archived=0').fetchone()[0]

    def archived_chats(self, limit=350):
        with self._conn() as cx:
            return [dict(r) for r in cx.execute(
                'SELECT * FROM chats WHERE deleted=0 AND archived=1 ORDER BY updated_at DESC LIMIT ?',
                (limit,)).fetchall()]

    def count_archived(self):
        with self._conn() as cx:
            return cx.execute('SELECT count(*) FROM chats WHERE deleted=0 AND archived=1').fetchone()[0]

    def browse_titles(self, needle='', limit=300):
        with self._conn() as cx:
            return [dict(r) for r in cx.execute(
                'SELECT id, title, updated_at FROM chats WHERE deleted=0 AND lower(title) LIKE ? ORDER BY updated_at DESC LIMIT ?',
                ('%' + needle.lower().replace('%','') + '%', limit)).fetchall()]

    def relevant_archive_messages(self, query, exclude_chat_id='', limit=5):
        """Rank globally indexed chats, return original message/chat IDs for citations.

        No entire-history prompt stuffing; shared events remain untouched. FTS5
        index persists for rapid retrieval and updates on imported/synced rows.
        """
        import re
        words=re.findall(r'[^\W_]{3,}', (query or '').lower(), flags=re.UNICODE)
        stop={'the','this','that','with','from','please','kya','hai','aur','mujhe',
              'mera','mere','karna','kaise','karo','batao','banao','into','about',
              'what','some','their','main','meri','mein','hain','you','your','and',
              'for','will','please','file','project','bot','code'}
        terms=list(dict.fromkeys(w for w in words if w not in stop))[:10]
        if not terms:return []
        with self._conn() as cx:
            rows=[]
            try:
                # Terms are individually quoted to prevent FTS syntax injection.
                phrase=' OR '.join('"'+w.replace('"','')+'"' for w in terms)
                rows=cx.execute("""SELECT c.id chat_id,c.title,m.id message_id,m.role,
                       m.content,m.created_at,bm25(message_fts) relevance
                       FROM message_fts JOIN messages m ON m.rowid=message_fts.rowid
                       JOIN chats c ON c.id=m.chat_id
                       WHERE message_fts MATCH ? AND c.deleted=0 AND c.id<>?
                       ORDER BY relevance ASC LIMIT 65""",(phrase,exclude_chat_id)).fetchall()
            except sqlite3.OperationalError:
                where=' OR '.join('lower(m.content) LIKE ?' for _ in terms)
                rows=cx.execute("""SELECT c.id chat_id,c.title,m.id message_id,m.role,
                    m.content,m.created_at FROM messages m JOIN chats c ON c.id=m.chat_id
                    WHERE c.deleted=0 AND c.id<>? AND ("""+where+""")
                    ORDER BY m.created_at DESC LIMIT 120""",
                    (exclude_chat_id,*['%'+t.replace('%','').replace('_','')+'%' for t in terms])).fetchall()
        scored=[]
        for row in rows:
            r=dict(row); body=r['content'].lower();title=r['title'].lower()
            score=sum(3*(t in body)+2*(t in title) for t in terms)
            if score:scored.append((score,r))
        scored.sort(key=lambda x:(x[0],x[1]['created_at']),reverse=True)
        return [dict(r,content=r['content'][:1100]) for _,r in scored[:limit]]

    def memory_index_count(self) -> int:
        with self._conn() as cx:
            try:return cx.execute('SELECT COUNT(*) FROM message_fts').fetchone()[0]
            except sqlite3.OperationalError:return 0

    def get_chat(self, id_):
        with self._conn() as cx:
            r=cx.execute('SELECT * FROM chats WHERE id=? AND deleted=0',(id_,)).fetchone()
            return dict(r) if r else None

    def message_count(self, chat_id):
        with self._conn() as cx:
            return cx.execute('SELECT count(*) FROM messages WHERE chat_id=?',(chat_id,)).fetchone()[0]

    def messages(self, chat_id, limit=None):
        with self._conn() as cx:
            if limit:
                rows=cx.execute('SELECT * FROM (SELECT * FROM messages WHERE chat_id=? ORDER BY created_at DESC,id DESC LIMIT ?) ORDER BY created_at,id', (chat_id,limit)).fetchall()
            else:
                rows=cx.execute('SELECT * FROM messages WHERE chat_id=? ORDER BY created_at,id',(chat_id,)).fetchall()
            return [dict(r) for r in rows]

    def memories(self, state=None):
        with self._conn() as cx:
            if state:
                rows=cx.execute('SELECT * FROM memories WHERE state=? ORDER BY updated_at DESC',(state,)).fetchall()
            else:
                rows=cx.execute("SELECT * FROM memories WHERE state NOT IN ('deleted','rejected') ORDER BY updated_at DESC").fetchall()
            return [dict(r) for r in rows]

    def record_usage(self, provider: str, ok: bool, duration_s: float,
                     chars: int=0, error: str='', input_chars: int=0) -> None:
        # Rough estimates, NOT provider-returned token totals.
        with self._conn() as cx:
            cx.execute('''INSERT INTO usage_events
                (id,time,provider,ok,duration_s,chars,error,input_estimate,output_estimate)
                VALUES (?,?,?,?,?,?,?,?,?)''',
                (str(uuid.uuid4()),utc_now(),provider,int(ok),max(0,float(duration_s)),
                 max(0,int(chars)),error[:250],max(0,(input_chars+3)//4),max(0,(chars+3)//4)))

    def activity_summary(self) -> dict:
        with self._conn() as cx:
            counts=cx.execute('SELECT COUNT(*) total,SUM(ok) successful,SUM(chars) chars FROM usage_events').fetchone()
            per=cx.execute('''SELECT provider,COUNT(*) calls,SUM(ok) good,
                           SUM(input_estimate) input_estimate,
                           SUM(output_estimate) output_estimate
                           FROM usage_events GROUP BY provider ORDER BY calls DESC''').fetchall()
            return {'total':counts['total'] or 0,'successful':counts['successful'] or 0,
                    'failed':(counts['total'] or 0)-(counts['successful'] or 0),
                    'reply_chars':counts['chars'] or 0,
                    'by_provider':[dict(r) for r in per]}

    def search(self, needle):
        with self._conn() as cx:
            rows=cx.execute('''SELECT m.*, c.title FROM messages m JOIN chats c ON m.chat_id=c.id
                               WHERE c.deleted=0 AND m.content LIKE ? ESCAPE '\\'
                               ORDER BY m.created_at DESC LIMIT 60''',
                            ('%' + needle.replace('\\','\\\\').replace('%','\\%').replace('_','\\_') + '%',)).fetchall()
            return [dict(r) for r in rows]
