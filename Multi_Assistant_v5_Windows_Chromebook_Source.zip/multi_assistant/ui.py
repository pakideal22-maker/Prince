"""Modern lightweight Windows desktop GUI with streaming and safe, explicit file tools."""
from __future__ import annotations
import json
import os
import sys
import time
from pathlib import Path
from PySide6.QtCore import Qt,QThread,Signal,QTimer,QUrl,QSize
from PySide6.QtGui import QFont,QDesktopServices,QKeyEvent
from PySide6.QtWidgets import (
 QApplication,QMainWindow,QWidget,QHBoxLayout,QVBoxLayout,QListWidget,QListWidgetItem,
 QLabel,QPushButton,QLineEdit,QPlainTextEdit,QTextBrowser,QScrollArea,QFrame,QSplitter,
 QComboBox,QFileDialog,QMessageBox,QInputDialog,QDialog,QDialogButtonBox,QFormLayout,
 QTabWidget,QSpinBox,QCheckBox,QGroupBox,QProgressBar,QMenu,QToolButton,QSizePolicy,
)
from . import __version__, portable_vault
from .config import (PROVIDERS,data_dir,load_settings,save_settings,get_key,put_key,
    get_sync_passphrase,save_sync_passphrase,forget_sync_passphrase,
    get_cloudflare_account_id,save_cloudflare_account_id,validate_free_model,
    get_brave_search_key,save_brave_search_key)
from .db import Database
from .providers import stream,available_providers
from .memory import suggest as detect_memory
from .files import read_context,write_output,extract_named_files,extract_project_files,save_named_zip
from .chatgpt_import import import_chatgpt_export, ImportErrorUser
from .research import research_sources,research_context,source_appendix

STYLE='''
QWidget { background: #0b1020; color: #e6ebf8; font-family: "Segoe UI", Arial; font-size: 13px; }
QMainWindow { background: #0b1020; }
QFrame#side { background: #10182b; border-right: 1px solid #263248; }
QFrame#header { background: #10182b; border-bottom: 1px solid #263248; }
QFrame#composer { background: #10182b; border-top: 1px solid #263248; }
QFrame#toolbar { background: #141e32; border-bottom: 1px solid #293956; }
QMenuBar { background: #10182b; color: #ebf1ff; padding: 4px 6px; border-bottom: 1px solid #33415c; }
QMenuBar::item { background: transparent; padding: 6px 12px; border-radius: 5px; }
QMenuBar::item:selected { background: #273853; }
QMenuBar::item:pressed { background: #34486c; }
QLabel#topBrand { font-size: 16px; font-weight: 800; color: #fff; }
QPushButton#topNav, QToolButton#topMenu { background: transparent; color: #dfebff; padding: 8px 10px; border: 1px solid transparent; border-radius: 8px; font-weight: 600; }
QPushButton#topNav:hover, QToolButton#topMenu:hover { background: #26395a; border: 1px solid #40547a; }
QLabel#driveIndicator { color: #80d5bd; font-size: 11px; padding: 3px 8px; }
QMenu { background: #19263d; border: 1px solid #42516d; color: #e6ebf8; padding: 5px; }
QMenu::item { padding: 8px 18px; }
QMenu::item:selected { background: #334966; }

QFrame#chatCard { background: #172239; border: 1px solid #2b3b55; border-radius: 16px; }
QFrame#userCard { background: #192c48; border: 1px solid #355274; border-radius: 16px; }
QFrame#welcomeCard { background: #131f35; border: 1px solid #2c3f61; border-radius: 22px; }
QLabel#appTitle { font-size: 18px; font-weight: 800; color: #ffffff; }
QLabel#muted, QLabel#caption { color: #90a1bb; }
QLabel#sectionLabel { color: #8296b4; font-size: 11px; font-weight: 700; letter-spacing: 1px; }
QLabel#titleLarge { color: #f7faff; font-size: 27px; font-weight: 750; }
QLabel#modelChip { background: #172e38; color: #77e1ca; border: 1px solid #285e59; border-radius: 12px; padding: 6px 10px; font-weight: bold; }
QPushButton { background: #1d2a42; border: 1px solid #34455f; color: #e6edff; padding: 9px 13px; border-radius: 10px; font-weight: 500; }
QPushButton:hover { background: #2d405e; border-color: #5575a3; }
QPushButton:pressed { background: #263752; }
QPushButton:disabled { color: #77869d; background: #172338; border-color: #27364b; }
QPushButton#primary { background: #6d5ef3; border-color: #8c81ff; color: #ffffff; font-weight: 700; }
QPushButton#primary:hover { background: #8074fc; }
QPushButton#sideAction { border: 1px solid transparent; background: transparent; text-align: left; padding: 11px 12px; }
QPushButton#sideAction:hover { background: #1e2f4a; border-color: #34465e; }
QPushButton#feature { border: 1px solid #34486d; background: #1c2b48; text-align: left; padding: 16px; }
QPushButton#feature:hover { background: #2a3f63; }
QComboBox, QLineEdit, QPlainTextEdit, QTextBrowser, QSpinBox { background: #111c31; border: 1px solid #3a4e69; border-radius: 10px; padding: 9px; color: #f0f4ff; selection-background-color: #6259c7; }
QComboBox:focus, QLineEdit:focus, QPlainTextEdit:focus { border-color: #8a81ff; }
QComboBox::drop-down { border: 0; width: 23px; }
QListWidget { background: transparent; border: 0; outline: 0; }
QListWidget::item { padding: 12px 10px; border-radius: 9px; margin: 3px 0; color: #b9c8db; }
QListWidget::item:hover { background: #223250; }
QListWidget::item:selected { background: #2c426a; color: #ffffff; }
QToolButton#chatDots { background: transparent; border: 0; border-radius: 6px; padding: 2px 5px; font-size: 18px; color: #b8c9e4; }
QToolButton#chatDots:hover { background: #395275; color: #ffffff; }
QScrollArea { border: 0; }
QScrollBar:vertical { background: #121c2c; width: 9px; }
QScrollBar::handle:vertical { background: #506682; border-radius: 4px; min-height: 30px; }
QScrollBar:horizontal { height: 8px; }
QTabBar::tab { padding: 11px 17px; background: #21324b; }
QTabBar::tab:selected { background: #4d54a9; }
QCheckBox { padding: 6px; }
QStatusBar { background: #10182b; color: #8395b2; }
'''

class InputBox(QPlainTextEdit):
    send_requested=Signal()
    def keyPressEvent(self,event:QKeyEvent):
        if event.key()==Qt.Key_Return and event.modifiers() & Qt.ControlModifier:
            self.send_requested.emit()
        else:
            super().keyPressEvent(event)


class Bubble(QFrame):
    def __init__(self,role:str,provider:str,content:str=''):
        super().__init__()
        self.setObjectName('userCard' if role=='user' else 'chatCard')
        layout=QVBoxLayout(self)
        layout.setContentsMargins(21,16,21,16)
        layout.setSpacing(7)
        title=QLabel('YOU  /  PERSONAL CHAT' if role=='user' else 'MULTI-ASSISTANT  /  '+(provider or 'AI').upper())
        title.setStyleSheet('color:#adbbf5;font-size:11px;font-weight:bold;background:transparent;border:0')
        layout.addWidget(title)
        self.text=QTextBrowser()
        self.text.setFrameShape(QFrame.NoFrame)
        self.text.setStyleSheet('background:transparent;border:0;padding:0;font-size:14px')
        self.text.setOpenExternalLinks(False)
        self.text.anchorClicked.connect(lambda url: QDesktopServices.openUrl(url) if url.scheme() in ('https','http') else None)
        self.set_text(content)
        layout.addWidget(self.text)

    def set_text(self,text:str):
        # Markdown is rendered locally. Qt's HTML engine doesn't run browser JavaScript.
        self.text.setMarkdown(text or '...')
        self.text.document().setTextWidth(max(180,self.text.viewport().width()-20))
        h=max(48,min(1100,int(self.text.document().size().height())+22))
        self.text.setFixedHeight(h)

    def resizeEvent(self,event):
        super().resizeEvent(event)
        self.text.document().setTextWidth(max(180,self.text.viewport().width()-22))
        h=max(48,min(1100,int(self.text.document().size().height())+22))
        self.text.setFixedHeight(h)


class ChatRow(QWidget):
    """A clickable conversation row with a genuine per-chat three-dot menu."""
    clicked=Signal(str)

    def __init__(self, chat_id, title, pinned, parent=None):
        super().__init__(parent)
        self.chat_id=chat_id
        self.setObjectName('chatRow')
        self.setFixedHeight(42)
        self.setCursor(Qt.PointingHandCursor)
        row=QHBoxLayout(self)
        row.setContentsMargins(7,2,4,2)
        row.setSpacing(4)
        self.title_label=QLabel(('📌 ' if pinned else '')+title)
        self.title_label.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.title_label.setStyleSheet('background: transparent; border: 0; color:#dce6f7; padding:0')
        self.title_label.setToolTip(title)
        self.title_label.setMinimumWidth(0)
        self.title_label.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        row.addWidget(self.title_label,1)
        dots=QToolButton()
        dots.setObjectName('chatDots')
        dots.setText('⋯')
        dots.setToolTip('Conversation options')
        dots.setFixedWidth(30)
        dots.setCursor(Qt.PointingHandCursor)
        dots.setPopupMode(QToolButton.InstantPopup)
        self.dots=dots
        row.addWidget(dots,0)
        self.set_selected(False)

    def mousePressEvent(self,event):
        if event.button()==Qt.LeftButton:
            self.clicked.emit(self.chat_id)
        super().mousePressEvent(event)

    def set_selected(self, selected):
        color='#2b4369' if selected else 'transparent'
        self.setStyleSheet(f'QWidget#chatRow {{background:{color}; border-radius:9px;}}')


class AIWorker(QThread):
    fragment=Signal(str)
    status=Signal(str)
    finished_ok=Signal(str,str)
    request_usage=Signal(str,bool,int,int,str)
    failed=Signal(str)

    def __init__(self,mode:str,messages:list,models:dict):
        super().__init__()
        self.mode=mode
        self.messages=messages
        self.models=models
        self._stop=False
        self.research_query=''
        self.research_key=''

    def stop(self):self._stop=True

    def run(self):
        options=available_providers()
        if self.mode=='Auto':
            choices=[p for p in ('Groq','Gemini','OpenRouter Free','Cerebras Free','Cloudflare Free') if p in options]
        elif self.mode=='Compare Groq + Gemini':
            choices=[p for p in ('Groq','Gemini') if p in options]
        else:
            choices=[self.mode] if self.mode in options else []
        if not choices:
            self.failed.emit('Selected AI ki key available nahi. Settings > AI Keys kholo.')
            return
        found_sources=[]
        if self.research_query:
            try:
                self.status.emit('Searching and reading sources...')
                found_sources=research_sources(self.research_query,self.research_key)
                self.messages=[self.messages[0],{'role':'system',
                   'content':research_context(found_sources,self.research_query)}]+self.messages[1:]
            except Exception as exc:
                self.failed.emit('Deep Research: '+str(exc));return
        compare=self.mode=='Compare Groq + Gemini'
        combined=''
        responded=False
        failures=[]
        for provider in choices:
            if self._stop:
                self.failed.emit('Request cancelled.');return
            self.status.emit('Connecting: '+provider+' ...')
            prefix=('\n\n### '+provider+'\n\n') if compare else ''
            current=''
            try:
                for chunk in stream(provider,self.messages,self.models[provider]):
                    if self._stop:
                        self.failed.emit('Request cancelled.');return
                    if not current and prefix:
                        combined+=prefix
                        self.fragment.emit(combined)
                    current+=chunk
                    combined+=chunk
                    self.fragment.emit(combined)
                self.request_usage.emit(provider,bool(current),sum(len(str(m.get('content',''))) for m in self.messages),len(current),'')
                if current:
                    responded=True
                    if not compare:break
                else:
                    failures.append(provider+': Empty response')
            except Exception as ex:
                self.request_usage.emit(provider,False,sum(len(str(m.get('content',''))) for m in self.messages),len(current),str(ex)[:200])
                failures.append(provider+': '+str(ex))
                if current:
                    responded=True
                if compare:
                    combined+= '\n\n*'+provider+' API error: '+str(ex)[:250]+'*\n'
                    self.fragment.emit(combined)
                elif current:
                    combined+='\n\n[Partial response; interrupted: '+str(ex)[:250]+']'
                    self.fragment.emit(combined)
                    break
        if responded:
            if found_sources:
                combined+=source_appendix(found_sources)
                self.fragment.emit(combined)
            self.finished_ok.emit(combined,self.mode if compare else provider)
        else:
            self.failed.emit(' | '.join(failures)[:1200] if failures else 'No response')


class ProjectTestWorker(QThread):
    result=Signal(object)
    failure=Signal(str)
    def __init__(self,folder):
        super().__init__();self.folder=folder
    def run(self):
        try:
            from .project_agent import run_trusted_offline_tests
            self.result.emit(run_trusted_offline_tests(self.folder,timeout=90))
        except Exception as exc:self.failure.emit(str(exc))


class ChatGPTImportWorker(QThread):
    progress=Signal(str)
    success=Signal(dict)
    failure=Signal(str)

    def __init__(self,db,path):
        super().__init__()
        self.db=db
        self.path=Path(path)

    def run(self):
        try:
            stats=import_chatgpt_export(self.db,self.path,self.progress.emit)
            self.success.emit(stats)
        except Exception as ex:
            self.failure.emit(str(ex))


class SyncWorker(QThread):
    done=Signal(str)
    error=Signal(str)
    def __init__(self,db,passphrase):
        super().__init__();self.db=db;self.passphrase=passphrase
    def run(self):
        try:
            from .sync import sync_once
            got,sent=sync_once(self.db,self.passphrase)
            self.done.emit(f'Drive sync complete. Remote events: {got}; own events: {sent}.')
        except Exception as ex:
            self.error.emit(str(ex))


class SettingsDialog(QDialog):
    def __init__(self,parent,settings):
        super().__init__(parent)
        self.setWindowTitle('Multi-Assistant Settings')
        self.resize(670,520)
        self.settings=settings
        layout=QVBoxLayout(self)
        tabs=QTabWidget();layout.addWidget(tabs)
        general=QWidget();form=QFormLayout(general)
        self.instructions=QPlainTextEdit(settings['instructions'])
        self.instructions.setFixedHeight(110)
        form.addRow('Custom assistant instructions:',self.instructions)
        self.context=QSpinBox();self.context.setRange(4,30)
        self.context.setValue(int(settings.get('max_context_messages',14)))
        form.addRow('Recent context messages:',self.context)
        self.automemory=QCheckBox('Automatically suggest possible long-term memories')
        self.automemory.setChecked(bool(settings.get('auto_memory',True)))
        form.addRow('',self.automemory)
        self.archive_context=QCheckBox('Use relevant older chats as context (may send excerpts to chosen AI provider)')
        self.archive_context.setChecked(bool(settings.get('use_archive_context',False)))
        self.archive_context.setToolTip('OFF by default for privacy. ChatGPT archive is searchable locally either way.')
        form.addRow('',self.archive_context)
        self.auto_voice=QCheckBox('Automatically read AI replies aloud (system TTS engine)')
        self.auto_voice.setChecked(bool(settings.get('auto_voice',False)))
        form.addRow('',self.auto_voice)
        tabs.addTab(general,'Assistant')
        ai=QWidget();ai_form=QFormLayout(ai)
        self.model_inputs={};self.key_edits={}
        for provider in PROVIDERS:
            block=QWidget();row=QHBoxLayout(block)
            row.setContentsMargins(0,0,0,0)
            model=QLineEdit(settings['models'][provider]);model.setMinimumWidth(170)
            key=QLineEdit();key.setEchoMode(QLineEdit.Password)
            key.setPlaceholderText('Key saved' if get_key(provider) else 'Paste new key')
            key.setMinimumWidth(170)
            btn=QPushButton('Save key')
            clear=QPushButton('Remove')
            btn.clicked.connect(lambda _,p=provider,e=key:self._save_key(p,e))
            clear.clicked.connect(lambda _,p=provider:self._clear_key(p))
            row.addWidget(QLabel('Model:'));row.addWidget(model)
            row.addWidget(QLabel('API key:'));row.addWidget(key)
            row.addWidget(btn);row.addWidget(clear)
            ai_form.addRow(provider+':',block)
            self.model_inputs[provider]=model;self.key_edits[provider]=key
        # Cloudflare REST API requires two credentials (account ID + API token).
        self.cf_account=QLineEdit()
        self.cf_account.setPlaceholderText('Cloudflare Account ID')
        self.cf_account.setText(get_cloudflare_account_id())
        ai_form.addRow('Cloudflare Account ID:',self.cf_account)
        ai_form.addRow(QLabel('Free Edition: paid-only AI options are disabled.\n'
                              'OpenAI (Paid API) is OPTIONAL and incurs separate API charges.\nUse free-tier models for no-cost requests.'))
        # Brave is a search provider, not a generative AI provider.
        research_row=QWidget();rr=QHBoxLayout(research_row);rr.setContentsMargins(0,0,0,0)
        self.brave_key=QLineEdit();self.brave_key.setEchoMode(QLineEdit.Password)
        self.brave_key.setPlaceholderText('Saved' if get_brave_search_key() else 'Brave Search API key (optional)')
        rr.addWidget(self.brave_key)
        save_search=QPushButton('Save Search Key');save_search.clicked.connect(self._save_search_key)
        rr.addWidget(save_search)
        ai_form.addRow('Deep Research:',research_row)
        ai_form.addRow(QLabel('Get optional Brave Search API key: https://api-dashboard.search.brave.com/'))
        tabs.addTab(ai,'AI Keys & Models')
        drive=QWidget();vl=QVBoxLayout(drive)
        info=QLabel('''<b>One-time Google Drive setup (optional)</b><br><br>
1. Go to <b>console.cloud.google.com</b>, create a project, enable Google Drive API.<br>
2. Configure OAuth consent screen. For Testing, add your own Google email as a test user.<br>
3. Create OAuth Client ID, <b>Desktop app</b>, download JSON credentials.<br>
4. Click the button below and copy that JSON file. Then choose <b>Google Drive Sync</b> on the main window.<br>
5. First sync opens your browser once for Google account approval.<br><br>
Uses only the <b>drive.appdata</b> OAuth scope; stores encrypted records in hidden Google Drive app data.<br>
Use the <b>same sync passphrase on PC and Chromebook</b>, or they cannot decrypt each other.<br>
<b>Do not forget the passphrase. No recovery is provided.</b><br>
Install optional Drive packages using INSTALL_DRIVE_SYNC.bat.''')
        info.setWordWrap(True);info.setTextFormat(Qt.RichText)
        vl.addWidget(info)
        copy=QPushButton('Choose downloaded Google OAuth Desktop JSON...')
        copy.clicked.connect(self._copy_oauth)
        vl.addWidget(copy);vl.addStretch()
        tabs.addTab(drive,'Google Drive')
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._done)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _save_search_key(self):
        try:
            value=self.brave_key.text().strip()
            if not value:raise ValueError('Paste a key first.')
            save_brave_search_key(value);self.brave_key.clear();self.brave_key.setPlaceholderText('Saved')
            QMessageBox.information(self,'Search API','Brave Search API key saved. Query usage may be billable under your Brave plan.')
        except Exception as exc:QMessageBox.warning(self,'Search key',str(exc))

    def _save_key(self,provider,edit):
        try:
            if not edit.text().strip():
                QMessageBox.information(self,'Key','Paste a new key first.');return
            put_key(provider,edit.text())
            edit.clear();edit.setPlaceholderText('Key saved')
            QMessageBox.information(self,'Saved',provider+' API key saved securely.')
        except Exception as ex:QMessageBox.warning(self,'Credential error',str(ex))

    def _clear_key(self,provider):
        if QMessageBox.question(self,'Remove key',f'Remove {provider} key from local credential store?')!=QMessageBox.Yes:return
        try:
            put_key(provider,'');self.key_edits[provider].setPlaceholderText('Paste new key')
        except Exception as ex:QMessageBox.warning(self,'Key error',str(ex))

    def _copy_oauth(self):
        import shutil
        file,_=QFileDialog.getOpenFileName(self,'Select Google Desktop OAuth JSON',str(Path.home()),'JSON (*.json)')
        if not file:return
        try:
            obj=json.loads(Path(file).read_text('utf-8'))
            if 'installed' not in obj:raise ValueError('This is not a Desktop OAuth credentials JSON.')
            dest=data_dir()/'google_oauth_client.json'
            shutil.copy2(file,dest)
            QMessageBox.information(self,'Ready','OAuth credentials saved locally. You can now try Drive Sync.')
        except Exception as ex:QMessageBox.warning(self,'Google OAuth',str(ex))

    def _done(self):
        self.settings['instructions']=self.instructions.toPlainText()[:5000]
        self.settings['max_context_messages']=self.context.value()
        self.settings['auto_memory']=self.automemory.isChecked()
        self.settings['use_archive_context']=self.archive_context.isChecked()
        self.settings['auto_voice']=self.auto_voice.isChecked()
        models={p:edit.text().strip() or PROVIDERS[p]['model'] for p,edit in self.model_inputs.items()}
        try:
            for provider,model in models.items():
                validate_free_model(provider,model)
            if self.cf_account.text().strip() != get_cloudflare_account_id():
                save_cloudflare_account_id(self.cf_account.text())
        except Exception as exc:
            QMessageBox.warning(self,'Free AI settings',str(exc))
            return
        self.settings['models']=models
        save_settings(self.settings)
        self.accept()


class MemoryDialog(QDialog):
    def __init__(self,parent,db):
        super().__init__(parent);self.db=db
        self.setWindowTitle('Memory Review — approve before saving')
        self.resize(620,460)
        layout=QVBoxLayout(self)
        layout.addWidget(QLabel('Pending suggestions (not used by the AI until approved):'))
        self.pending=QListWidget();layout.addWidget(self.pending)
        row=QHBoxLayout();layout.addLayout(row)
        accept=QPushButton('Approve selected');reject=QPushButton('Reject selected')
        accept.clicked.connect(lambda:self.action_pending(True))
        reject.clicked.connect(lambda:self.action_pending(False))
        row.addWidget(accept);row.addWidget(reject)
        layout.addWidget(QLabel('Approved long-term memories:'))
        self.approved=QListWidget();layout.addWidget(self.approved)
        forget=QPushButton('Forget selected approved memory');layout.addWidget(forget)
        forget.clicked.connect(self.forget)
        self.refresh()

    def refresh(self):
        self.pending.clear();self.approved.clear()
        for memory in self.db.memories('pending'):
            item=QListWidgetItem(memory['text']);item.setData(Qt.UserRole,memory['id'])
            item.setToolTip(memory['text']);self.pending.addItem(item)
        for memory in self.db.memories('approved'):
            item=QListWidgetItem(memory['text']);item.setData(Qt.UserRole,memory['id'])
            item.setToolTip(memory['text']);self.approved.addItem(item)

    def action_pending(self,approve):
        item=self.pending.currentItem()
        if not item:return
        self.db.decide_memory(item.data(Qt.UserRole),approve);self.refresh()

    def forget(self):
        item=self.approved.currentItem()
        if not item:return
        if QMessageBox.question(self,'Forget memory','Remove this approved memory?')==QMessageBox.Yes:
            self.db.forget_memory(item.data(Qt.UserRole));self.refresh()


class DashboardDialog(QDialog):
    def __init__(self,parent,db):
        super().__init__(parent)
        self.db=db
        self.setWindowTitle('Multi-Assistant • PC Activity Dashboard')
        self.resize(530,410)
        layout=QVBoxLayout(self)
        layout.addWidget(QLabel('System Monitoring (local PC)'))
        self.cpu=QLabel();self.ram=QLabel();self.disk=QLabel()
        self.cpu_bar=QProgressBar();self.ram_bar=QProgressBar()
        for label,bar in [(self.cpu,self.cpu_bar),(self.ram,self.ram_bar)]:
            layout.addWidget(label);layout.addWidget(bar)
        layout.addWidget(self.disk)
        layout.addWidget(QLabel('AI requests recorded on this PC:'))
        self.ai=QLabel();self.ai.setWordWrap(True)
        layout.addWidget(self.ai)
        layout.addWidget(QLabel('API keys configured:'))
        self.keys=QLabel();self.keys.setWordWrap(True)
        layout.addWidget(self.keys)
        layout.addStretch()
        self.timer=QTimer(self);self.timer.timeout.connect(self.refresh)
        self.timer.start(3000);self.refresh()

    def refresh(self):
        try:
            import psutil
            cpu=psutil.cpu_percent(interval=None)
            mem=psutil.virtual_memory()
            self.cpu.setText(f'CPU: {cpu:.0f}%')
            self.cpu_bar.setValue(int(cpu))
            self.ram.setText(f'RAM: {mem.used/(1024**3):.1f} / {mem.total/(1024**3):.1f} GB  ({mem.percent:.0f}%)')
            self.ram_bar.setValue(int(mem.percent))
            self.disk.setText('Disk free: {:.1f} GB'.format(psutil.disk_usage(str(data_dir())).free/1024**3))
        except Exception as ex:
            self.cpu.setText('Monitoring unavailable: '+str(ex))
        summary=self.db.activity_summary()
        self.ai.setText(f"Requests: {summary['total']} • Success: {summary['successful']} • Failed: {summary['failed']}\n"+
            '\n'.join(f"{row['provider']}: {row['good']}/{row['calls']} successful • ~{row['input_estimate']} input / ~{row['output_estimate']} output tokens" for row in summary['by_provider']))
        self.keys.setText(', '.join(p for p in PROVIDERS if get_key(p)) or '(none)')


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.db=Database()
        self.settings=load_settings()
        self.setWindowTitle('Multi-Assistant v5 • Windows / Chromebook')
        self.setMinimumSize(980,690)
        self.resize(1190,800)
        self.chat_id=None
        self.worker=None
        self.sync_worker=None
        self.import_worker=None
        self.test_worker=None
        self.messages_to_show=90
        self._view_chat_id=None
        self.sync_password=get_sync_passphrase()
        self._save_sync_after_success=False
        self._exit_after_sync=False
        self._sync_succeeded_for_exit=False
        self._allow_exit=False
        self._sync_reason='auto'
        self._sync_last_ok=False
        self.attached=None
        self.last_answer=''
        self._speech=None
        self._project_context=''
        self._project_root=None
        self.research_next=False
        self._request_started=0
        self.live_bubble=None
        self._live_text=''
        self._displayed_live=None
        self._render_timer=QTimer(self)
        self._render_timer.setInterval(100)
        self._render_timer.timeout.connect(self._flush_live)
        self._sync_timer=QTimer(self);self._sync_timer.setInterval(10*60*1000)
        self._sync_timer.timeout.connect(self.do_sync)
        self._build()
        self.refresh_chats()
        if self.chat_list.count():
            # Explicit load: never rely only on the selection-changed event.
            self.chat_list.setCurrentRow(0)
            first=self.chat_list.item(0)
            if first:self.open_chat(first.data(Qt.UserRole))
        else:self.new_chat()
        self.statusBar().showMessage('Ready • data stored locally: '+str(self.db.path))
        # Only resume if Windows Credential Manager has a previously saved passphrase.
        # Never force a fresh password prompt on application startup.
        if self.sync_password and (data_dir()/'google_oauth_client.json').exists():
            self.sync_status.setText('Drive: reconnecting...')
            QTimer.singleShot(1200,self.do_sync)
        if not available_providers():
            QTimer.singleShot(350,lambda:QMessageBox.information(self,'Connect AI','Settings > AI Keys mein kisi free provider ki API key add karo.'))

    def _build(self):
        central=QWidget();self.setCentralWidget(central)
        root=QVBoxLayout(central);root.setSpacing(0);root.setContentsMargins(0,0,0,0)

        # Windows-style menu bar: workspace actions go above, not in the sidebar.
        menubar=self.menuBar()
        menubar.setNativeMenuBar(False)
        file_menu=menubar.addMenu('File')
        file_menu.addAction('Import ChatGPT history...').triggered.connect(self.import_chatgpt)
        file_menu.addAction('Export last AI answer...').triggered.connect(self.open_export_menu)
        file_menu.addAction('Export project ZIP...').triggered.connect(self.export_code_project)
        file_menu.addSeparator()
        file_menu.addAction('Sync & Exit').triggered.connect(self.sync_and_exit)
        file_menu.addAction('Exit').triggered.connect(self.close)
        chat_menu=menubar.addMenu('Chat')
        chat_menu.addAction('New conversation').triggered.connect(self.new_chat)
        chat_menu.addAction('Reload current conversation').triggered.connect(self.reload_chat)
        chat_menu.addAction('Search conversations').triggered.connect(self.search_chats)
        chat_menu.addAction('Browse full archive').triggered.connect(self.browse_archive)
        chat_menu.addAction('Archived conversations...').triggered.connect(self.view_archived_chats)
        chat_menu.addAction('Rename selected conversation').triggered.connect(self.rename_chat)
        chat_menu.addSeparator()
        chat_menu.addAction('Delete selected conversation').triggered.connect(self.delete_chat)
        workspace_menu=menubar.addMenu('Workspace')
        workspace_menu.addAction('Review saved memories').triggered.connect(self.open_memories)
        workspace_menu.addAction('PC activity and usage').triggered.connect(self.open_dashboard)
        workspace_menu.addAction('Import ChatGPT history').triggered.connect(self.import_chatgpt)
        workspace_menu.addAction('Review existing project folder...').triggered.connect(self.review_project_folder)
        workspace_menu.addAction('Coding Agent: preview + apply AI changes...').triggered.connect(self.apply_ai_project_changes)
        workspace_menu.addAction('Coding Agent: check Python syntax...').triggered.connect(self.check_project_syntax)
        workspace_menu.addAction('Coding Agent: run approved unit tests...').triggered.connect(self.run_project_tests)
        workspace_menu.addAction('Read last AI answer aloud').triggered.connect(self.play_last_answer)
        workspace_menu.addAction('Stop speaking').triggered.connect(self.stop_speaking)
        settings_menu=menubar.addMenu('Settings')
        settings_menu.addAction('AI keys and app settings').triggered.connect(self.open_settings)
        settings_menu.addAction('Google Drive sync now').triggered.connect(self.start_drive_sync)
        settings_menu.addAction('Forget saved Drive password').triggered.connect(self.forget_saved_drive_password)
        # A narrow toolbar leaves room for the actual conversation pane.
        toolbar=QFrame();toolbar.setObjectName('toolbar')
        tl=QHBoxLayout(toolbar);tl.setContentsMargins(16,7,16,7);tl.setSpacing(12)
        brand=QLabel('✦  MULTI-ASSISTANT');brand.setObjectName('topBrand')
        tl.addWidget(brand)
        btn_new=QPushButton('＋ New Chat');btn_new.setObjectName('primary')
        btn_new.clicked.connect(self.new_chat);tl.addWidget(btn_new)
        tl.addStretch(1)
        self.sync_status=QLabel('Drive: ready' if self.sync_password else 'Drive: offline')
        self.sync_status.setObjectName('driveIndicator')
        self.sync_status.setToolTip('Encrypted Google Drive chat sync status')
        tl.addWidget(self.sync_status)
        root.addWidget(toolbar)

        splitter=QSplitter(Qt.Horizontal);splitter.setChildrenCollapsible(False)
        root.addWidget(splitter,1)
        sidebar=QFrame();sidebar.setObjectName('side')
        sidebar.setMinimumWidth(185);sidebar.setMaximumWidth(255)
        left=QVBoxLayout(sidebar);left.setContentsMargins(12,19,12,15);left.setSpacing(9)
        title=QLabel('CONVERSATIONS');title.setObjectName('sectionLabel');left.addWidget(title)
        new=QPushButton('＋   New conversation');new.setObjectName('primary')
        new.clicked.connect(self.new_chat);left.addWidget(new)
        search=QPushButton('⌕   Search conversations');search.setObjectName('sideAction')
        search.clicked.connect(self.search_chats);left.addWidget(search)
        browse=QPushButton('▤   Browse full archive');browse.setObjectName('sideAction')
        browse.clicked.connect(self.browse_archive);left.addWidget(browse)
        left.addSpacing(5)
        section=QLabel('RECENT CHATS');section.setObjectName('sectionLabel');left.addWidget(section)
        self.chat_list=QListWidget();self.chat_list.currentItemChanged.connect(self._select_chat)
        self.chat_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.chat_list.customContextMenuRequested.connect(self._chat_context_menu)
        self.chat_list.setToolTip('Har chat ke samne ⋯ dabao, ya right-click karo')
        left.addWidget(self.chat_list,1)
        self.archive_count=QLabel('');self.archive_count.setObjectName('muted')
        self.archive_count.setWordWrap(True);left.addWidget(self.archive_count)
        splitter.addWidget(sidebar)

        main=QWidget();right=QVBoxLayout(main);right.setContentsMargins(0,0,0,0);right.setSpacing(0)
        head=QFrame();head.setObjectName('header');hr=QHBoxLayout(head)
        hr.setContentsMargins(25,15,22,15);hr.setSpacing(10)
        col=QVBoxLayout();col.setSpacing(4)
        self.chat_title=QLabel('New conversation')
        self.chat_title.setStyleSheet('font-size:20px;font-weight:750;color:#f7f9ff;')
        col.addWidget(self.chat_title)
        self.chat_meta=QLabel('Local chat history • synced to Drive when connected')
        self.chat_meta.setObjectName('muted');self.chat_meta.setStyleSheet('color:#90a4bf;font-size:11px;')
        col.addWidget(self.chat_meta);hr.addLayout(col,1)
        self.provider_status=QLabel('● AI MODE');self.provider_status.setObjectName('modelChip')
        hr.addWidget(self.provider_status)
        self.provider=QComboBox()
        self.provider.addItems(['Auto','Groq','Gemini','OpenRouter Free','Cerebras Free','Cloudflare Free','OpenAI (Paid API)','Compare Groq + Gemini'])
        self.provider.setMinimumWidth(140);hr.addWidget(self.provider)
        export=QPushButton('Export');export.clicked.connect(self.open_export_menu);hr.addWidget(export)
        code=QPushButton('Project ZIP');code.clicked.connect(self.export_code_project);hr.addWidget(code)
        listen=QPushButton('🔊 Play');listen.clicked.connect(self.play_last_answer);hr.addWidget(listen)
        right.addWidget(head)
        self.scroller=QScrollArea();self.scroller.setWidgetResizable(True)
        self.scroller.setFrameShape(QFrame.NoFrame)
        self.scroll_inner=QWidget()
        self.msg_layout=QVBoxLayout(self.scroll_inner)
        self.msg_layout.setContentsMargins(28,23,28,21);self.msg_layout.setSpacing(15)
        self.msg_layout.addStretch(1)
        self.scroller.setWidget(self.scroll_inner);right.addWidget(self.scroller,1)

        bottom=QFrame();bottom.setObjectName('composer')
        btm=QVBoxLayout(bottom);btm.setContentsMargins(27,13,27,18);btm.setSpacing(8)
        self.context_label=QLabel('Attach PDF, DOCX, XLSX, Arduino, Python or text file')
        self.context_label.setObjectName('muted');btm.addWidget(self.context_label)
        self.entry=InputBox()
        self.entry.setPlaceholderText('Message Multi-Assistant...     Ctrl + Enter to send')
        self.entry.setFixedHeight(90)
        self.entry.send_requested.connect(self.send_message)
        btm.addWidget(self.entry)
        actions=QHBoxLayout();actions.setSpacing(9);btm.addLayout(actions)
        attach=QPushButton('＋ Attach file');attach.clicked.connect(self.attach_file);actions.addWidget(attach)
        self.research_btn=QPushButton('🌐 Deep Research');self.research_btn.clicked.connect(self.toggle_deep_research)
        actions.addWidget(self.research_btn)
        clear=QPushButton('Remove attachment');clear.clicked.connect(self.clear_attachment);actions.addWidget(clear)
        actions.addStretch()
        self.status=QLabel('Ready');self.status.setObjectName('muted');actions.addWidget(self.status)
        self.send_btn=QPushButton('Send  ➤');self.send_btn.setObjectName('primary')
        self.send_btn.clicked.connect(self.send_message);actions.addWidget(self.send_btn)
        self.stop_btn=QPushButton('Stop');self.stop_btn.clicked.connect(self.stop_request)
        self.stop_btn.setEnabled(False);actions.addWidget(self.stop_btn)
        right.addWidget(bottom)
        main.setMinimumWidth(570)
        splitter.addWidget(main)
        splitter.setStretchFactor(0,0);splitter.setStretchFactor(1,1)
        splitter.setSizes([215,975])

    def _welcome(self):
        card=QFrame();card.setObjectName('welcomeCard')
        card.setMaximumWidth(820)
        box=QVBoxLayout(card);box.setSpacing(18);box.setContentsMargins(32,31,32,29)
        logo=QLabel('✦  MULTI-ASSISTANT');logo.setObjectName('sectionLabel')
        logo.setStyleSheet('color:#a7a0ff;font-size:14px;font-weight:bold;')
        box.addWidget(logo)
        headline=QLabel('What can I help you build?');headline.setObjectName('titleLarge')
        box.addWidget(headline)
        desc=QLabel('Ask Gemini a question, explore electronics ideas, create documents, or continue a project. Your chats stay on this PC.')
        desc.setWordWrap(True);desc.setObjectName('muted')
        desc.setStyleSheet('color:#aabbd1;font-size:14px;')
        box.addWidget(desc)
        topics=[('Electronics & Arduino','Explain ATtiny45 hall sensor wiring with code.'),
                ('Project & coding','Help me plan an ESP32 motor control project.'),
                ('Writing & files','Create a professional one-page project summary.'),
                ('Troubleshooting','Help diagnose a Python error step by step.')]
        for label,prompt in topics:
            btn=QPushButton('↗   '+label);btn.setObjectName('feature')
            btn.clicked.connect(lambda _,t=prompt:(self.entry.setPlainText(t),self.entry.setFocus()))
            box.addWidget(btn)
        hint=QLabel('Use the Import button in the top toolbar for ChatGPT history.')
        hint.setObjectName('muted');box.addWidget(hint)
        wrap=QWidget();r=QVBoxLayout(wrap);r.addStretch(1)
        r.addWidget(card,0,Qt.AlignHCenter);r.addStretch(1)
        self.msg_layout.insertWidget(self.msg_layout.count()-1,wrap)

    def _refresh_title(self):
        chat=self.db.get_chat(self.chat_id)
        self.chat_title.setText(chat['title'] if chat else 'New conversation')
        if chat and hasattr(self,'chat_meta'):
            self.chat_meta.setText(f"{self.db.message_count(self.chat_id)} saved messages  •  Local SQLite history")

    def _defer_chat_action(self, action, *args):
        # Let Qt close the per-row popup before refreshing/deleting its widget.
        QTimer.singleShot(0,lambda:action(*args))

    def _make_chat_menu(self,chat_id,parent=None,chat=None):
        chat=chat or self.db.get_chat(chat_id)
        menu=QMenu(parent or self)
        if not chat:return menu
        menu.addAction('✎  Rename').triggered.connect(
            lambda _,c=chat_id:self._defer_chat_action(self.rename_chat,c))
        menu.addAction('Unpin' if chat['pinned'] else 'Pin to top').triggered.connect(
            lambda _,c=chat_id,p=chat['pinned']:self._defer_chat_action(self.toggle_pin,c,not bool(p)))
        menu.addAction('Unarchive' if chat['archived'] else 'Archive').triggered.connect(
            lambda _,c=chat_id,a=chat['archived']:self._defer_chat_action(self.toggle_archive,c,not bool(a)))
        menu.addAction('Export as TXT...').triggered.connect(
            lambda _,c=chat_id:self._defer_chat_action(self.export_chat_txt,c))
        menu.addSeparator()
        menu.addAction('Delete...').triggered.connect(
            lambda _,c=chat_id:self._defer_chat_action(self.delete_chat,c))
        return menu

    def _chat_context_menu(self,pos):
        item=self.chat_list.itemAt(pos)
        if item:
            menu=self._make_chat_menu(item.data(Qt.UserRole),self.chat_list)
            menu.exec(self.chat_list.mapToGlobal(pos))
            menu.deleteLater()

    def _chat_row_clicked(self,chat_id):
        for i in range(self.chat_list.count()):
            item=self.chat_list.item(i)
            if item.data(Qt.UserRole)==chat_id:
                self.chat_list.setCurrentItem(item)
                # Reopening an already selected chat after a toolbar action is useful.
                if self.chat_id!=chat_id:self.open_chat(chat_id)
                return

    def _highlight_chat_rows(self):
        for i in range(self.chat_list.count()):
            item=self.chat_list.item(i)
            row=self.chat_list.itemWidget(item)
            if row:row.set_selected(item.data(Qt.UserRole)==self.chat_id)

    def refresh_chats(self,select_id=None):
        select_id=select_id or self.chat_id
        self.chat_list.blockSignals(True)
        self.chat_list.clear()
        count=self.db.count_chats()
        self.archive_count.setText(f'{count:,} chats • {self.db.count_archived():,} archived')
        for c in self.db.list_chats():
            item=QListWidgetItem()
            item.setData(Qt.UserRole,c['id'])
            item.setSizeHint(QSize(185,46))
            self.chat_list.addItem(item)
            row=ChatRow(c['id'],c['title'],bool(c['pinned']),self.chat_list)
            row.dots.setMenu(self._make_chat_menu(c['id'],row,chat=c))
            row.clicked.connect(self._chat_row_clicked)
            self.chat_list.setItemWidget(item,row)
            if c['id']==select_id:
                self.chat_list.setCurrentItem(item)
        self.chat_list.blockSignals(False)
        self._highlight_chat_rows()

    def new_chat(self):
        if self.worker and self.worker.isRunning():return
        id_=self.db.new_chat();self.refresh_chats(id_);self.open_chat(id_)

    def _select_chat(self,item,previous):
        if item and not (self.worker and self.worker.isRunning()):
            self.open_chat(item.data(Qt.UserRole))
        self._highlight_chat_rows()

    def reload_chat(self):
        if self.chat_id and self.db.get_chat(self.chat_id):
            self.open_chat(self.chat_id)
        else:
            self.new_chat()

    def open_chat(self,id_):
        if not self.db.get_chat(id_):
            self.new_chat()
            return
        if self._view_chat_id!=id_:
            self.messages_to_show=90
            self._view_chat_id=id_
        self.chat_id=id_;self._refresh_title()
        self._highlight_chat_rows()
        self._clear_messages()
        self.last_answer=''
        self._speech=None
        self._project_context=''
        total=self.db.message_count(id_)
        if total>self.messages_to_show:
            older=QPushButton(f'↑ Load older messages  •  showing latest {self.messages_to_show:,} of {total:,}')
            older.setObjectName('feature')
            older.clicked.connect(lambda:self.load_older(id_))
            self.msg_layout.insertWidget(self.msg_layout.count()-1,older)
        for m in self.db.messages(id_,limit=self.messages_to_show):
            self.add_bubble(m['role'],m.get('provider') or '',m['content'])
            if m['role']=='assistant':self.last_answer=m['content']
        if not self.db.messages(id_,limit=1):self._welcome()
        self.scroll_end()

    def load_older(self,chat_id):
        self.messages_to_show+=90
        self.open_chat(chat_id)

    def _clear_messages(self):
        while self.msg_layout.count()>1:
            item=self.msg_layout.takeAt(0)
            w=item.widget()
            if w:w.deleteLater()

    def add_bubble(self,role,provider,content):
        bubble=Bubble(role,provider,content)
        self.msg_layout.insertWidget(self.msg_layout.count()-1,bubble)
        self.scroll_end()
        return bubble

    def scroll_end(self):
        QTimer.singleShot(0,lambda:self.scroller.verticalScrollBar().setValue(self.scroller.verticalScrollBar().maximum()))

    def _activate_first_available_chat(self):
        self.refresh_chats()
        if self.chat_list.count():
            first=self.chat_list.item(0)
            self.chat_list.setCurrentItem(first)
            self.open_chat(first.data(Qt.UserRole))
        else:
            self.chat_id=None
            self.new_chat()

    def rename_chat(self,chat_id=None):
        if self.worker and self.worker.isRunning():return
        target=chat_id or self.chat_id
        chat=self.db.get_chat(target) if target else None
        if not chat:return
        title,ok=QInputDialog.getText(self,'Rename conversation','New chat title:',text=chat['title'])
        title=title.strip()[:100]
        if ok and title and title!=chat['title']:
            self.db.rename_chat(target,title)
            self.refresh_chats(target if target==self.chat_id else self.chat_id)
            if target==self.chat_id:self._refresh_title()

    def toggle_pin(self,chat_id,pinned):
        if self.worker and self.worker.isRunning():return
        if not self.db.get_chat(chat_id):return
        self.db.pin_chat(chat_id,pinned)
        self.refresh_chats(self.chat_id)

    def toggle_archive(self,chat_id,archived):
        if self.worker and self.worker.isRunning():return
        if not self.db.get_chat(chat_id):return
        self.db.archive_chat(chat_id,archived)
        if archived and self.chat_id==chat_id:
            self._activate_first_available_chat()
        else:self.refresh_chats(self.chat_id)

    def view_archived_chats(self):
        dialog=QDialog(self)
        dialog.setWindowTitle('Archived conversations')
        dialog.resize(560,420)
        layout=QVBoxLayout(dialog)
        layout.addWidget(QLabel('Select an archived chat and click Restore.'))
        archive=QListWidget()
        layout.addWidget(archive)
        for c in self.db.archived_chats():
            item=QListWidgetItem(c['title'])
            item.setData(Qt.UserRole,c['id'])
            archive.addItem(item)
        buttons=QHBoxLayout();layout.addLayout(buttons)
        restore=QPushButton('Restore selected')
        cancel=QPushButton('Close')
        buttons.addWidget(restore);buttons.addWidget(cancel)
        cancel.clicked.connect(dialog.reject)
        def do_restore():
            item=archive.currentItem()
            if not item:return
            target=item.data(Qt.UserRole)
            self.toggle_archive(target,False)
            dialog.accept()
            self._chat_row_clicked(target)
        restore.clicked.connect(do_restore)
        archive.itemDoubleClicked.connect(lambda _:do_restore())
        dialog.exec()

    def export_chat_txt(self,chat_id):
        chat=self.db.get_chat(chat_id)
        if not chat:return
        filename,_=QFileDialog.getSaveFileName(self,'Export conversation',chat['title'][:50]+'.txt',
            'Text files (*.txt)')
        if not filename:return
        try:
            with open(filename,'w',encoding='utf-8') as output:
                output.write(chat['title']+'\n\n')
                for msg in self.db.messages(chat_id):
                    output.write(f"[{msg['role']} • {msg.get('provider') or 'local'} • {msg['created_at']}]\n{msg['content']}\n\n")
            QMessageBox.information(self,'Export complete','Conversation saved as TXT.')
        except Exception as ex:
            QMessageBox.warning(self,'Export failed',str(ex))

    def delete_chat(self,chat_id=None):
        if self.worker and self.worker.isRunning():return
        target=chat_id or self.chat_id
        chat=self.db.get_chat(target) if target else None
        if not chat:return
        msg=(f"Delete conversation '{chat['title']}'?\n\n"
             'This action removes it from the app and will sync the deletion to Google Drive. '
             'A separate ChatGPT export is unaffected.')
        if QMessageBox.question(self,'Delete conversation',msg)!=QMessageBox.Yes:return
        self.db.delete_chat(target)
        if self.chat_id==target:
            self._activate_first_available_chat()
        else:self.refresh_chats(self.chat_id)

    def search_chats(self):
        text,ok=QInputDialog.getText(self,'Search all chats','Word or phrase:')
        if not ok or not text.strip():return
        results=self.db.search(text.strip())
        dialog=QDialog(self);dialog.setWindowTitle('Search results');dialog.resize(680,450)
        layout=QVBoxLayout(dialog);ls=QListWidget();layout.addWidget(ls)
        for r in results:
            item=QListWidgetItem(r['title']+'  •  '+r['role']+'\n'+r['content'][:200].replace('\n',' '))
            item.setData(Qt.UserRole,r['chat_id']);ls.addItem(item)
        ls.itemDoubleClicked.connect(lambda item:(dialog.accept(),self.open_chat(item.data(Qt.UserRole))))
        dialog.exec()

    def browse_archive(self):
        term,ok=QInputDialog.getText(self,'Browse full chat archive','Chat title contains (leave blank for recent 300):')
        if not ok:return
        results=self.db.browse_titles(term.strip(),300)
        dialog=QDialog(self);dialog.setWindowTitle('Chat archive — '+str(len(results))+' results (max 300)')
        dialog.resize(730,510)
        layout=QVBoxLayout(dialog)
        label=QLabel('Double-click a conversation to open it. For text within chats, use Search.')
        label.setObjectName('muted');layout.addWidget(label)
        ls=QListWidget();layout.addWidget(ls)
        for r in results:
            item=QListWidgetItem(r['title']+'   •   '+r['updated_at'][:10]);item.setData(Qt.UserRole,r['id'])
            ls.addItem(item)
        ls.itemDoubleClicked.connect(lambda item:(dialog.accept(),self.open_chat(item.data(Qt.UserRole))))
        dialog.exec()

    def import_chatgpt(self):
        if self.import_worker and self.import_worker.isRunning():
            QMessageBox.information(self,'Import already running','ChatGPT history import is already running.');return
        if self.worker and self.worker.isRunning():
            QMessageBox.warning(self,'AI busy','Please finish the current AI request before importing.');return
        filename,_=QFileDialog.getOpenFileName(self,'Import ChatGPT export',str(Path.home()/'Downloads'),
                                      'ChatGPT Export (*.zip *.json)')
        if not filename:return
        message=('Import all available ChatGPT conversation text from this export?\n\n'
                 '• Existing local chats remain unchanged.\n'
                 '• The database is backed up before importing.\n'
                 '• Duplicate imports are skipped.\n'
                 '• Long-term memories are NOT auto-approved.\n'
                 '• Images/audio/attachments are not transferred.\n'
                 '• Imported chats are local until Drive sync is set up.\n\n'
                 'For privacy, inspect the export before importing.')
        if QMessageBox.question(self,'Confirm ChatGPT history import',message)!=QMessageBox.Yes:return
        self.statusBar().showMessage('ChatGPT import running...')
        self.archive_count.setText('Importing ChatGPT archive...')
        self.import_worker=ChatGPTImportWorker(self.db,filename)
        self.import_worker.progress.connect(lambda t:self.statusBar().showMessage(t))
        self.import_worker.success.connect(self._import_done)
        self.import_worker.failure.connect(self._import_failed)
        self.import_worker.start()

    def _import_done(self,stats):
        self.refresh_chats(self.chat_id)
        self.statusBar().showMessage('ChatGPT history import complete.',12000)
        QMessageBox.information(self,'ChatGPT import complete',
            f"Exported chats found: {stats['conversations_found']:,}\n"
            f"Chats with text: {stats['chats_with_text']:,}\n"
            f"Text messages processed: {stats['messages_processed']:,}\n"
            f"New database events: {stats['events_added']:,}\n"
            f"Already imported events: {stats['already_imported']:,}\n"
            f"Skipped empty/nontext messages: {stats['skipped_empty_or_nontext']:,}\n"
            f"Truncated long messages: {stats['truncated_messages']:,}\n\n"
            'Backup file:\n'+stats['backup_path']+'\n\n'
            'Imported conversations are searchable. Approved memories are unchanged.')

    def _import_failed(self,message):
        self.refresh_chats(self.chat_id)
        self.statusBar().showMessage('ChatGPT import failed',10000)
        QMessageBox.warning(self,'ChatGPT history import error',message[:2000])

    def attach_file(self):
        filename,_=QFileDialog.getOpenFileName(self,'Select context file',str(Path.home()),
             'Supported (*.txt *.md *.py *.ino *.json *.csv *.html *.js *.css *.log *.yaml *.yml *.cpp *.h *.hpp *.pdf *.docx *.xlsx);;All files (*)')
        if not filename:return
        try:
            content=read_context(Path(filename))
            if not content.strip():raise ValueError('File appears empty or scanned (no extractable text).')
            self.attached=(Path(filename).name,content)
            self.context_label.setText('Attached: '+Path(filename).name+' • will be sent to external AI provider')
        except Exception as ex:QMessageBox.warning(self,'File import failed',str(ex))

    def clear_attachment(self):
        self.attached=None;self.context_label.setText('Attach text, code, PDF, DOCX or XLSX (sent to selected AI)')

    def toggle_deep_research(self):
        if not self.research_next:
            if not get_brave_search_key():
                QMessageBox.information(self,'Deep Research','Brave Search API key chahiye. Settings > AI Keys & Models mein save karo. Search API plan charges apply ho sakte hain.')
                return
            if QMessageBox.question(self,'Enable Deep Research?',
                'Next question Brave Search API ko bheja jayega. Relevant pages ke excerpts selected AI provider ko jayenge. Continue?')!=QMessageBox.Yes:return
            self.research_next=True;self.research_btn.setText('🌐 Research ON')
        else:
            self.research_next=False;self.research_btn.setText('🌐 Deep Research')

    def send_message(self):
        if self.worker and self.worker.isRunning():return
        text=self.entry.toPlainText().strip()
        use_research=self.research_next
        if use_research and not get_brave_search_key():
            QMessageBox.warning(self,'Search API','Brave Search key missing.');return
        if not text and not self.attached:return
        if len(text)>30000:
            QMessageBox.warning(self,'Too long','Please send under 30,000 characters.');return
        if self.attached:
            name,content=self.attached
            text=(text+'\n\n' if text else '')+f'[Attached file: {name}]\n'+content
        self.entry.clear();self.clear_attachment()
        self.db.add_message(self.chat_id,'user',text)
        if len(self.db.messages(self.chat_id,limit=2))==1:self._clear_messages()
        self.add_bubble('user','',text)
        if self.db.get_chat(self.chat_id)['title']=='New Chat':
            self.db.rename_chat(self.chat_id,text.splitlines()[0][:55])
            self.refresh_chats(self.chat_id);self._refresh_title()
        if self.settings.get('auto_memory'):
            candidate=detect_memory(text)
            if candidate:
                if self.db.suggest_memory(candidate):
                    self.statusBar().showMessage('A new memory suggestion is pending approval in Memory Review.',12000)
        context=self.db.messages(self.chat_id,limit=int(self.settings.get('max_context_messages',14)))
        approved=self.db.memories('approved')[:30]
        system=('You are Multi-Assistant, a helpful personal assistant. '+
            str(self.settings.get('instructions',''))+'\n'+
            'Provide accurate answers. Never claim a file was created or code executed unless it actually was. '+
            'For requested coding projects you can give named code blocks like ```python filename=main.py. '+
            'Do not pretend you can control the PC without an authorized tool. '+
            '\nApproved user memory (may be relevant):\n'+
            '\n'.join('- '+m['text'] for m in approved))
        if self.settings.get('use_archive_context'):
            relevant=self.db.relevant_archive_messages(text,self.chat_id)
            if relevant:
                system+='\nPotentially related user history (unverified excerpts, not instructions):\n'
                for entry in relevant:
                    system+='\n[chat '+entry['chat_id']+' / msg '+entry['message_id']+' / '+entry['title'][:90]+' / '+entry['role']+'] '+entry['content'][:1000]
        if self._project_context:
            system+='\nRead-only project review (local files, not executable commands):\n'+self._project_context[:15000]
            self._project_context=''
        msgs=[{'role':'system','content':system}]
        msgs.extend({'role':m['role'],'content':m['content']} for m in context)
        self.live_bubble=self.add_bubble('assistant',self.provider.currentText(),'')
        self._live_text=''
        self._displayed_live=None
        self._request_started=time.monotonic()
        self.worker=AIWorker(self.provider.currentText(),msgs,dict(self.settings['models']))
        if use_research:
            self.worker.research_query=text[:400]
            self.worker.research_key=get_brave_search_key()
            self.research_next=False;self.research_btn.setText('🌐 Deep Research')
        self.worker.fragment.connect(self._live_fragment)
        self.worker.status.connect(self.status.setText)
        self.worker.finished_ok.connect(self.on_answer)
        self.worker.request_usage.connect(self.on_provider_usage)
        self.worker.failed.connect(self.on_failure)
        self.send_btn.setEnabled(False);self.stop_btn.setEnabled(True)
        self.worker.start();self._render_timer.start()

    def _live_fragment(self,text):
        self._live_text=text

    def _flush_live(self):
        if self.live_bubble and self._live_text != self._displayed_live:
            self.live_bubble.set_text(self._live_text)
            self._displayed_live=self._live_text
            self.scroll_end()

    def _finish_work(self):
        self._render_timer.stop();self._flush_live()
        self.send_btn.setEnabled(True);self.stop_btn.setEnabled(False)
        self.status.setText('Ready')

    def on_answer(self,text,provider):
        self._live_text=text
        self._finish_work()
        self.db.add_message(self.chat_id,'assistant',text,provider)
        if self.settings.get('auto_voice',False):self.play_last_answer(text)
        self.last_answer=text
        self.live_bubble=None
        self.refresh_chats(self.chat_id)
        # QThread finishes on its own. Keep reference until next request.

    def on_failure(self,error):
        self._live_text='⚠ '+error
        self._finish_work();self.live_bubble=None
        # Individual provider attempts are logged by AIWorker.request_usage.
        QMessageBox.warning(self,'AI request failed',error)

    def stop_request(self):
        if self.worker:self.worker.stop();self.status.setText('Stopping after next received chunk...')

    def on_provider_usage(self,provider,ok,input_chars,output_chars,error):
        self.db.record_usage(provider,ok,time.monotonic()-self._request_started,
                             output_chars,error,input_chars)

    def play_last_answer(self,text=None):
        message=(text if isinstance(text,str) else self.last_answer or '').strip()
        if not message:
            self.statusBar().showMessage('No AI answer to read.',4500);return
        try:
            from PySide6.QtTextToSpeech import QTextToSpeech
            if self._speech is None:self._speech=QTextToSpeech(self)
            if not self._speech.availableEngines():
                raise RuntimeError('No TTS engine installed on this computer.')
            self._speech.stop()
            self._speech.say(message[:12000])
        except Exception as ex:
            QMessageBox.warning(self,'System Voice','Text-to-speech unavailable: '+str(ex)+'\nCheck Windows speech voices / Linux speech packages.')

    def stop_speaking(self):
        if self._speech is not None:self._speech.stop()

    def review_project_folder(self):
        from .project_agent import project_snapshot
        folder=QFileDialog.getExistingDirectory(self,'Select project folder (read-only review)',str(Path.home()))
        if not folder:return
        try:
            snapshot=project_snapshot(Path(folder))
            if QMessageBox.question(self,'Share project excerpts?',
                'The selected project contains '+str(snapshot['files'])+' readable files.\n'
                'Limited source excerpts may be sent to the AI provider with your NEXT message.\n'
                'No files will be edited or executed.\n\nContinue?') != QMessageBox.Yes:return
            self._project_root=Path(folder).resolve()
            self._project_context=snapshot['context']
            self.statusBar().showMessage('Read-only project loaded. Type your requested changes, then send.',10000)
        except Exception as exc:QMessageBox.warning(self,'Project review',str(exc))

    def _active_project(self):
        if self._project_root and self._project_root.exists():return self._project_root
        folder=QFileDialog.getExistingDirectory(self,'Select TEST COPY of project folder',str(Path.home()))
        if not folder:return None
        self._project_root=Path(folder).resolve()
        return self._project_root

    def apply_ai_project_changes(self):
        from .project_agent import preview_edits,apply_edits_approved
        root=self._active_project()
        if not root:return
        files=extract_project_files(self.last_answer or '')
        if not files:
            QMessageBox.information(self,'AI Coding Agent','Ask AI for complete named files using ```python filename=orion/module.py ... ``` then use this action.')
            return
        try:
            preview=preview_edits(root,files)
            if not preview['changes']:
                QMessageBox.information(self,'No changes','Proposed code is identical to existing files.');return
            viewer=QDialog(self);viewer.setWindowTitle('Code Diff Preview — NO CHANGES APPLIED');viewer.resize(900,620)
            layout=QVBoxLayout(viewer)
            label=QLabel('Review proposed code carefully. Apply modifies only the chosen project COPY; live bots should remain separate.')
            label.setWordWrap(True);layout.addWidget(label)
            diff=QPlainTextEdit();diff.setReadOnly(True);diff.setPlainText(preview['diff']);layout.addWidget(diff)
            buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
            buttons.button(QDialogButtonBox.Ok).setText('Approve, Back Up & Apply')
            buttons.accepted.connect(viewer.accept);buttons.rejected.connect(viewer.reject)
            layout.addWidget(buttons)
            if viewer.exec()!=QDialog.Accepted:return
            result=apply_edits_approved(preview)
            report='Updated: '+', '.join(result['changed'])+'\nBackup saved: '+result['backup']
            QMessageBox.information(self,'Changes applied — backup saved',report)
        except Exception as exc:QMessageBox.warning(self,'Agent refused changes',str(exc))

    def check_project_syntax(self):
        from .project_agent import inspect_project_tests
        root=self._active_project()
        if not root:return
        try:
            result=inspect_project_tests(root)
            problems='\n'.join(x+': '+s for x,s in result['failures'])[:6000]
            QMessageBox.information(self,'Static Python Syntax Check',
                f"Checked {result['checked']} Python files. Failures: {len(result['failures'])}\n"+problems)
        except Exception as exc:QMessageBox.warning(self,'Syntax check',str(exc))

    def run_project_tests(self):
        root=self._active_project()
        if not root:return
        if self.test_worker and self.test_worker.isRunning():
            QMessageBox.information(self,'Unit tests','A test run is already in progress.');return
        if QMessageBox.warning(self,'Permission: EXECUTE PROJECT CODE',
            'This will execute Python unittest tests from the selected project. Tests may run arbitrary code, read files or access the internet. NOT SANDBOXED.\n\nRun ONLY trusted test code and NEVER directly against live ORION?',
            QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        self.statusBar().showMessage('Running approved unit tests (separate worker thread)...')
        self.test_worker=ProjectTestWorker(root)
        self.test_worker.result.connect(self._show_project_test_report)
        self.test_worker.failure.connect(lambda error:QMessageBox.warning(self,'Test error',error))
        self.test_worker.start()

    def _show_project_test_report(self,result):
        self.statusBar().showMessage('Project tests completed',5000)
        viewer=QDialog(self);viewer.setWindowTitle('Offline unit-test report');viewer.resize(850,600)
        lay=QVBoxLayout(viewer)
        lay.addWidget(QLabel('PASS' if result['ok'] else 'FAIL (exit '+str(result['exit_code'])+')'))
        output=QPlainTextEdit();output.setReadOnly(True);output.setPlainText(result['log']);lay.addWidget(output)
        close=QPushButton('Close');close.clicked.connect(viewer.accept);lay.addWidget(close);viewer.exec()

    def open_dashboard(self):
        DashboardDialog(self,self.db).exec()

    def open_settings(self):
        dialog=SettingsDialog(self,self.settings)
        if dialog.exec():
            self.settings=load_settings()
            self.statusBar().showMessage('Settings saved.',4000)

    def open_memories(self):MemoryDialog(self,self.db).exec()

    def open_export_menu(self):
        if not self.last_answer:
            QMessageBox.information(self,'No answer','Ask a question before exporting.');return
        filename,_=QFileDialog.getSaveFileName(self,'Save most recent AI answer',
             str(Path.home()/'Documents'/'Multi-Assistant-Answer.md'),
             'Markdown (*.md);;Text (*.txt);;PDF (*.pdf);;Word (*.docx);;Excel (*.xlsx);;Python (*.py);;Arduino (*.ino);;HTML (*.html);;CSV (*.csv)')
        if not filename:return
        try:
            write_output(Path(filename),self.last_answer)
            QMessageBox.information(self,'File saved','Saved: '+filename+'\n\nFor XLSX, use CSV/TSV-style text. For PDF, Unicode/Urdu font rendering may be limited.')
        except Exception as ex:QMessageBox.warning(self,'Export failed',str(ex))

    def export_code_project(self):
        if not self.last_answer:return
        files=extract_named_files(self.last_answer)
        if not files:
            QMessageBox.information(self,'Named files needed','Ask AI to return code with filename markers, e.g.\n```python filename=main.py\nprint("hello")\n```')
            return
        summary='\n'.join(sorted(files.keys()))
        if QMessageBox.question(self,'Save project ZIP','Create ZIP with these files?\n\n'+summary[:1600])!=QMessageBox.Yes:return
        path,_=QFileDialog.getSaveFileName(self,'Save generated project',str(Path.home()/'Documents'/'Multi-Assistant-Project.zip'),'ZIP (*.zip)')
        if not path:return
        try:save_named_zip(Path(path),files);QMessageBox.information(self,'Saved','Project ZIP saved to '+path)
        except Exception as ex:QMessageBox.warning(self,'ZIP error',str(ex))

    def start_drive_sync(self):
        # When already unlocked, a click just synchronizes -- no extra prompt.
        if self.sync_worker and self.sync_worker.isRunning():return
        if self.sync_password:
            self.do_sync('manual');return
        password,ok=QInputDialog.getText(self,'Google Drive encrypted sync',
            'Shared passphrase (12+ characters). Saved to Windows Credential Manager after successful sync:',
            QLineEdit.Password)
        if not ok:return
        if len(password)<12:
            QMessageBox.warning(self,'Passphrase','Use 12 characters or more.');return
        self.sync_password=password
        self._save_sync_after_success=True
        self.do_sync('manual')

    def forget_saved_drive_password(self):
        if self.sync_worker and self.sync_worker.isRunning():
            QMessageBox.information(self,'Drive busy','Wait for the current sync to finish.');return
        if QMessageBox.question(self,'Forget Drive password',
            'Remove Drive sync passphrase from this PC? Local chats and Google Drive data will remain unchanged.')!=QMessageBox.Yes:
            return
        try:
            forget_sync_passphrase()
        except Exception as ex:
            QMessageBox.warning(self,'Credential store error',str(ex));return
        self.sync_password=None
        self._save_sync_after_success=False
        self._sync_timer.stop()
        self.sync_status.setText('Drive: password removed')
        self.statusBar().showMessage('Drive auto-sync paused; local chat remains available.',7000)

    def do_sync(self,reason='auto'):
        if not self.sync_password or self.sync_worker and self.sync_worker.isRunning():return
        self._sync_reason=reason
        self._sync_last_ok=False
        self.sync_status.setText('Google Drive: syncing ...')
        self.sync_worker=SyncWorker(self.db,self.sync_password)
        self.sync_worker.done.connect(self.sync_success)
        self.sync_worker.error.connect(self.sync_failure)
        self.sync_worker.finished.connect(self._finish_exit_if_synced)
        self.sync_worker.start()

    def sync_success(self,text):
        self._sync_last_ok=True
        if self._save_sync_after_success:
            try:
                save_sync_passphrase(self.sync_password)
                self._save_sync_after_success=False
            except Exception as ex:
                # Never fall back to saving an unencrypted passphrase on disk.
                self.statusBar().showMessage('Drive connected; Windows credential save failed: '+str(ex),14000)
                QMessageBox.warning(self,'Drive password not saved',
                    'Drive sync worked but Windows Credential Manager could not save the password. '
                    'You may be asked again after restart.\n'+str(ex))
        self.sync_status.setText('Drive: synced • every 10 min')
        self.statusBar().showMessage(text,10000)
        current=self.chat_id;self.refresh_chats(current)
        if self.db.get_chat(current):self.open_chat(current)
        self._sync_timer.start()
        if self._exit_after_sync:
            self._sync_succeeded_for_exit=True

    def _finish_exit_if_synced(self):
        # Always wait for QThread.finished; never destroy a running sync worker.
        if self._exit_after_sync and self._sync_succeeded_for_exit:
            self._exit_after_sync=False
            self._sync_succeeded_for_exit=False
            self._allow_exit=True
            QTimer.singleShot(0,self.close)

    def sync_failure(self,error):
        self._sync_last_ok=False
        if self._exit_after_sync:
            self._exit_after_sync=False
            self._sync_succeeded_for_exit=False
        self.sync_status.setText('Drive: sync failed')
        # Keep periodic attempts enabled even if an intermittent network/API issue occurs.
        if self.sync_password:
            self._sync_timer.start()
        if self._save_sync_after_success:
            self.sync_password=None
            self._save_sync_after_success=False
        self.statusBar().showMessage('Drive sync failed: '+error[:250],15000)
        if self._sync_reason in ('manual','exit'):
            QMessageBox.warning(self,'Drive sync failed',error[:1500] +
                '\n\nYour local chats are still saved; no messages were deleted.')

    def sync_and_exit(self):
        """Explicit save-and-exit command: no prompt if passphrase is already stored."""
        if self.import_worker and self.import_worker.isRunning():
            QMessageBox.information(self,'Import running','Finish ChatGPT history import before exiting.')
            return
        if not self.sync_password:
            QMessageBox.information(self,'Drive not unlocked',
                'Drive passphrase is not saved on this PC. Use Settings > Google Drive sync now '
                'and complete one successful sync to remember it securely. Your chats are still saved locally.')
            return
        if self.sync_worker and self.sync_worker.isRunning():
            self._exit_after_sync=True
            self._sync_succeeded_for_exit=self._sync_last_ok
            self.statusBar().showMessage('Existing Drive sync completing before exit...')
            return
        self._exit_after_sync=True
        self._sync_succeeded_for_exit=False
        self.statusBar().showMessage('Syncing to Drive before exit...')
        self.do_sync('exit')

    def closeEvent(self,event):
        if self.import_worker and self.import_worker.isRunning():
            QMessageBox.information(self,'Import running','Finish ChatGPT history import before exiting.')
            event.ignore();return
        if self.worker and self.worker.isRunning():
            if QMessageBox.question(self,'Active request','AI response is still running. Close anyway?')!=QMessageBox.Yes:
                event.ignore();return
            self.worker.stop()
        if self._allow_exit:
            self.sync_password=None
            event.accept();return
        if self.sync_worker and self.sync_worker.isRunning():
            # Safest default: allow current sync to finish; no thread teardown.
            if not self._exit_after_sync:
                self._exit_after_sync=True
                self._sync_succeeded_for_exit=self._sync_last_ok
            self.statusBar().showMessage('Google Drive sync is running; closing after successful sync.')
            event.ignore();return
        if self.sync_password:
            box=QMessageBox(self)
            box.setWindowTitle('Exit Multi-Assistant')
            box.setText('Google Drive par latest chats sync karni hain?')
            box.setInformativeText('Local SQLite mein chats pehle hi saved hain. Sync & Exit Drive ko update karega.')
            sync_btn=box.addButton('Sync && Exit',QMessageBox.AcceptRole)
            exit_btn=box.addButton('Exit Without Sync',QMessageBox.DestructiveRole)
            cancel_btn=box.addButton('Cancel',QMessageBox.RejectRole)
            box.setDefaultButton(sync_btn)
            box.exec()
            clicked=box.clickedButton()
            if clicked is sync_btn:
                event.ignore()
                self.sync_and_exit()
                return
            if clicked is not exit_btn:
                event.ignore();return
        self.sync_password=None  # Only erase in-memory copy, secure keyring entry stays.
        event.accept()



def run():
    app=QApplication(sys.argv)
    app.setApplicationName('Multi-Assistant')
    app.setStyle('Fusion');app.setStyleSheet(STYLE)
    font=QFont('Segoe UI',10);app.setFont(font)
    if portable_vault.is_portable():
        exists=portable_vault.has_vault()
        if not exists:
            QMessageBox.warning(None,'New portable workspace',
                'Portable chats on USB (SQLite) are NOT encrypted. Store this app on an encrypted USB drive if chats are private.\n'
                'API keys and Google login tokens WILL be encrypted with your master password.')
        unlocked=False
        for attempt in range(3):
            password,ok=QInputDialog.getText(None,'Multi-Assistant USB Portable',
                'Master password (12+ characters):',QLineEdit.Password)
            if not ok:return
            if not exists:
                confirm,yes=QInputDialog.getText(None,'Confirm portable password',
                    'Re-enter master password:',QLineEdit.Password)
                if not yes:return
                if password!=confirm:
                    QMessageBox.warning(None,'Password','Passwords do not match.')
                    continue
            try:
                portable_vault.unlock(password,create=not exists)
                unlocked=True
                break
            except Exception as exc:
                QMessageBox.warning(None,'Portable vault',str(exc)[:250])
        if not unlocked:return
    window=MainWindow();window.show()
    sys.exit(app.exec())
