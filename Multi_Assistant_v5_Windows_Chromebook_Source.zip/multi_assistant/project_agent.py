"""Safe read-only project indexing: does not execute code, follow symlinks or send secrets."""
from pathlib import Path
import re

SUPPORTED={'.py','.ino','.md','.txt','.json','.java','.js','.css','.html','.yml','.yaml','.xml','.gradle','.toml'}
SECRETS={'secrets','credentials','.env','token','private','apikey','api_key','key.pem'}
# Best effort credential redaction in read-only project excerpts; users should
# inspect which snippets are sent to a third-party model.
_CREDENTIAL_LINE=re.compile(r"(?i)(\b(?:api[_-]?key|access[_-]?token|secret[_-]?key|password)\b\s*[:=]\s*)[\"']?[^\s,;}\"']{5,}[\"']?")

def _redact_excerpts(value:str)->str:
    return _CREDENTIAL_LINE.sub(lambda m:m.group(1)+'[REDACTED]',value)



def project_snapshot(root: Path, max_files=120, max_chars=14500) -> dict:
    root=Path(root).expanduser().resolve(strict=True)
    if not root.is_dir():raise ValueError('Choose a project directory.')
    files=[];chunks=[];size=0
    for item in sorted(root.rglob('*')):
        if len(files)>=max_files or size>=max_chars:break
        if item.is_symlink() or not item.is_file() or item.suffix.lower() not in SUPPORTED:continue
        rel=item.relative_to(root)
        if len(rel.parts)>7 or any(x.startswith('.') or x.lower() in ('venv','node_modules','build','dist','__pycache__') for x in rel.parts):continue
        if any(x in item.name.lower() for x in SECRETS):continue
        if item.stat().st_size>500_000:continue
        files.append(str(rel))
        try:
            content=item.read_text('utf-8',errors='replace')
        except OSError:continue
        budget=min(1600,max_chars-size)
        chunk=f'\nFILE {rel}\n'+_redact_excerpts(content[:budget])
        chunks.append(chunk);size+=len(chunk)
    if not files:raise ValueError('No supported source code files found.')
    return {'files':len(files),'context':
        f'Project: {root.name}\nFile inventory (up to {max_files}):\n'+\
        '\n'.join(files)[:4000]+'\nSelected excerpts (partial, read-only):'+''.join(chunks)[:max_chars]}


# SAFE WORKSPACE PATCHES — explicit user approval required by the UI.
import difflib
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time
import uuid

ALLOWED_EDIT_EXTENSIONS=SUPPORTED|{'.csv','.cpp','.h','.hpp','.sh','.bat'}
SKIP_PARTS={'venv','.venv','node_modules','build','dist','__pycache__','.git'}


def _safe_target(root:Path, relative:str)->Path:
    """Only named, source-like paths rooted in a user-selected project."""
    from pathlib import PurePosixPath
    if not isinstance(relative,str) or not relative or len(relative)>230 or '\\' in relative or ':' in relative:
        raise ValueError('Unsafe file path')
    rel=PurePosixPath(relative)
    if rel.is_absolute() or len(rel.parts)>8 or any(
       x in ('','.','..') or x.startswith('.') or x.lower() in SKIP_PARTS for x in rel.parts):
        raise ValueError('Unsafe file path')
    if rel.suffix.lower() not in ALLOWED_EDIT_EXTENSIONS or any(
        term in rel.name.lower() for term in SECRETS):
        raise ValueError('Secret or unsupported file refused')
    cur=root
    for segment in rel.parts:
        cur=cur/segment
        if cur.is_symlink():raise ValueError('Symlink path refused')
    resolved=cur.resolve(strict=False)
    if root not in resolved.parents:raise ValueError('Path escaped project')
    return resolved


def preview_edits(root:Path, edits:dict[str,str], max_files=20)->dict:
    """Preview changes and record original hashes. Does not write to project."""
    root=Path(root).expanduser().resolve(strict=True)
    if not root.is_dir():raise ValueError('Choose existing project directory')
    if not edits or len(edits)>max_files:raise ValueError('Expected 1–20 named code files')
    changes=[];diffs=[]
    for name,content in edits.items():
        target=_safe_target(root,name)
        if not isinstance(content,str) or len(content)>400000:raise ValueError('File too large')
        if target.exists() and (not target.is_file() or target.stat().st_size>1_000_000):
            raise ValueError('Large/non-file target refused')
        old=target.read_bytes() if target.exists() else None
        before=old.decode('utf-8',errors='replace') if old is not None else ''
        if before==content:continue
        diff=''.join(difflib.unified_diff(before.splitlines(True),content.splitlines(True),
             fromfile='before/'+name,tofile='after/'+name))
        diffs.append(diff[:20000]);changes.append({'path':name,
           'old_sha256':hashlib.sha256(old).hexdigest() if old is not None else None,
           'content':content})
    return {'root':str(root),'changes':changes,'diff':'\n'.join(diffs)[:65000]}


def apply_edits_approved(preview:dict, backup_base:Path|None=None)->dict:
    """Transactional-ish checked writes with backups. Call ONLY after UI approval."""
    root=Path(preview['root']).resolve(strict=True)
    changes=preview['changes']
    if not changes:raise ValueError('No changes')
    prepared=[]
    for entry in changes:
        target=_safe_target(root,entry['path'])
        old=target.read_bytes() if target.exists() else None
        if (hashlib.sha256(old).hexdigest() if old is not None else None)!=entry['old_sha256']:
            raise ValueError('Project file changed since preview: '+entry['path'])
        prepared.append((target,old,entry['content'].encode('utf-8'),entry['path']))
    base=Path(backup_base) if backup_base else root.parent/'Multi-Assistant-Backups'
    base.mkdir(parents=True,exist_ok=True)
    out=base/(root.name+'-'+time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8])
    out.mkdir(mode=0o700)
    manifest=[]
    for target,old,content,name in prepared:
        manifest.append({'path':name,'existed':old is not None})
        if old is not None:
            saved=out/name;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(old)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),'utf-8')
    written=[]
    try:
        for target,old,content,name in prepared:
            target.parent.mkdir(parents=True,exist_ok=True)
            fd,tempfile_name=tempfile.mkstemp(prefix='.ma_tmp_',dir=target.parent)
            try:
                with os.fdopen(fd,'wb') as handle:handle.write(content);handle.flush();os.fsync(handle.fileno())
                os.replace(tempfile_name,target)
            finally:
                if os.path.exists(tempfile_name):os.unlink(tempfile_name)
            written.append((target,old))
    except Exception:
        for target,old in reversed(written):
            if old is None:target.unlink(missing_ok=True)
            else:target.write_bytes(old)
        raise
    return {'changed':[name for _,_,_,name in prepared],'backup':str(out)}


def inspect_project_tests(root:Path)->dict:
    """Non-executing syntax check: safe for source generated by an AI."""
    import ast
    snapshot=project_snapshot(root,max_files=200,max_chars=1200)
    root=Path(root).resolve(strict=True)
    results=[]
    for path in root.rglob('*.py'):
        if path.is_symlink() or any(x.startswith('.') or x.lower() in SKIP_PARTS for x in path.relative_to(root).parts):continue
        if path.stat().st_size>500_000:continue
        try:ast.parse(path.read_text('utf-8'),filename=str(path));results.append((str(path.relative_to(root)),'PASS'))
        except Exception as e:results.append((str(path.relative_to(root)),str(e)))
        if len(results)>=200:break
    return {'checked':len(results),'failures':[(x,s) for x,s in results if s!='PASS'],'results':results}


def run_trusted_offline_tests(root:Path, command='unittest', timeout=90)->dict:
    """Runs arbitrary project code: UI MUST warn + ask for explicit permission."""
    import sys
    root=Path(root).resolve(strict=True)
    if command!='unittest':raise ValueError('Only standard unittest is enabled')
    if not (root/'tests').is_dir():raise ValueError('No tests/ folder in project')
    # Remove common credential-bearing environment variables; execution is NOT
    # sandboxed, and network access is NOT blocked. User approval required.
    env={'PATH':os.environ.get('PATH',''),'SYSTEMROOT':os.environ.get('SYSTEMROOT',''),
         'TMP':os.environ.get('TMP',''),'TEMP':os.environ.get('TEMP',''),
         'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(root)}
    result=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],
            cwd=root,env=env,capture_output=True,text=True,timeout=timeout,shell=False)
    return {'ok':result.returncode==0,'exit_code':result.returncode,
            'log':(result.stdout+'\n'+result.stderr)[-25000:]}
