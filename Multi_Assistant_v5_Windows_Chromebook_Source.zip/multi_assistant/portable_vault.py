"""Password-protected secrets storage in USB portable mode only.

SQLite chat history is NOT encrypted. Use full-disk USB encryption for sensitive chats.
"""
from __future__ import annotations
import base64
import json
import os
import threading
from pathlib import Path

_LOCK=threading.RLock()
_SECRETS=None
_PASSWORD=None
_ENVELOPE_NAME='portable_secrets.mas2'


def is_portable():
    return bool(os.environ.get('MULTI_ASSISTANT_PORTABLE_HOME','').strip())


def home():
    raw=os.environ.get('MULTI_ASSISTANT_PORTABLE_HOME','').strip()
    if not raw:
        raise RuntimeError('Portable mode not enabled')
    return Path(raw).expanduser().resolve()


def secrets_file():
    d=home()/'Data'
    d.mkdir(parents=True, exist_ok=True)
    return d/_ENVELOPE_NAME


def has_vault():
    return secrets_file().exists()


def _derive(password, salt):
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    return Scrypt(salt=salt,length=32,n=2**14,r=8,p=1).derive(password.encode('utf-8'))


def unlock(password: str, create: bool=False):
    global _SECRETS,_PASSWORD
    if len(password)<12:
        raise ValueError('Portable master password must have at least 12 characters.')
    with _LOCK:
        path=secrets_file()
        if not path.exists():
            if not create:raise FileNotFoundError('Portable credential vault not created')
            _SECRETS={}
            _PASSWORD=password
            _save()
        else:
            if create:raise FileExistsError('Portable vault already exists')
            obj=json.loads(path.read_text(encoding='utf-8'))
            if obj.get('format')!='MAS-PORTABLE-VAULT-1':
                raise ValueError('Unknown portable credential vault')
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            salt=base64.b64decode(obj['salt']);nonce=base64.b64decode(obj['nonce'])
            blob=base64.b64decode(obj['data'])
            decoded=AESGCM(_derive(password,salt)).decrypt(nonce,blob,b'MAS-PORTABLE-VAULT-1')
            val=json.loads(decoded.decode('utf-8'))
            if not isinstance(val,dict) or not all(isinstance(k,str) and isinstance(v,str) for k,v in val.items()):
                raise ValueError('Invalid portable credential vault content')
            _SECRETS=val
            _PASSWORD=password


def _save():
    if _SECRETS is None or _PASSWORD is None:raise RuntimeError('Portable credential vault locked')
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    salt=os.urandom(16);nonce=os.urandom(12)
    blob=AESGCM(_derive(_PASSWORD,salt)).encrypt(nonce,json.dumps(_SECRETS,ensure_ascii=False).encode('utf-8'),b'MAS-PORTABLE-VAULT-1')
    obj={'format':'MAS-PORTABLE-VAULT-1',
         'salt':base64.b64encode(salt).decode(),
         'nonce':base64.b64encode(nonce).decode(),
         'data':base64.b64encode(blob).decode()}
    file=secrets_file();tmp=file.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj),encoding='utf-8')
    try:os.chmod(tmp,0o600)
    except OSError:pass
    tmp.replace(file)


def get_secret(key: str):
    with _LOCK:
        if _SECRETS is None:raise RuntimeError('Portable credential vault locked')
        return _SECRETS.get(key,'')


def set_secret(key: str, value: str):
    with _LOCK:
        if _SECRETS is None:raise RuntimeError('Portable credential vault locked')
        if value:_SECRETS[key]=str(value)
        else:_SECRETS.pop(key,None)
        _save()
