"""User-confirmed import / export. No arbitrary code execution."""
from __future__ import annotations
import csv
import io
import re
import zipfile
from pathlib import Path

TEXT_EXT={'.txt','.md','.py','.ino','.json','.csv','.html','.js','.css','.log','.yaml','.yml','.cpp','.h','.hpp'}
MAX_READ=8_000_000
MAX_CONTEXT=18000


def read_context(path:Path)->str:
    path=Path(path)
    if path.stat().st_size>MAX_READ:
        raise ValueError('File > 8 MB. Split the file into parts before attaching.')
    ext=path.suffix.lower()
    if ext in TEXT_EXT:
        with path.open('r',encoding='utf-8',errors='replace') as src:
            excerpt=src.read(MAX_CONTEXT+1)
        if len(excerpt)>MAX_CONTEXT:
            return excerpt[:MAX_CONTEXT]+'\n[PARTIAL FILE: first 18,000 characters only; rest not supplied to model]'
        return excerpt
    if ext=='.pdf':
        from pypdf import PdfReader
        reader=PdfReader(str(path))
        return '\n'.join((p.extract_text() or '') for p in reader.pages[:15])[:MAX_CONTEXT]
    if ext=='.docx':
        from docx import Document
        return '\n'.join(p.text for p in Document(path).paragraphs)[:MAX_CONTEXT]
    if ext=='.xlsx':
        from openpyxl import load_workbook
        wb=load_workbook(path,read_only=True,data_only=True)
        lines=[]
        for sheet in wb.worksheets[:3]:
            lines.append('Sheet: '+sheet.title)
            for row in sheet.iter_rows(max_row=150,max_col=15,values_only=True):
                lines.append('\t'.join('' if x is None else str(x) for x in row))
                if sum(map(len,lines))>MAX_CONTEXT:break
        wb.close()
        return '\n'.join(lines)[:MAX_CONTEXT]
    raise ValueError('Supported: text, code, PDF, DOCX or XLSX files.')


def _safe_pdf(text:str,path:Path):
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Preformatted
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    from xml.sax.saxutils import escape
    # Use built-in font for English. Non-Latin Unicode may not render in PDF.
    style=getSampleStyleSheet()
    story=[]
    for line in text.splitlines()[:10000]:
        story.append(Paragraph(escape(line or ' '),style['BodyText']))
        story.append(Spacer(1,4))
    SimpleDocTemplate(str(path),pagesize=(595,842),rightMargin=40,leftMargin=40).build(story)


def write_output(path: Path, text: str)->None:
    path=Path(path)
    ext=path.suffix.lower()
    if ext in TEXT_EXT:
        path.write_text(text,encoding='utf-8')
    elif ext=='.docx':
        from docx import Document
        d=Document()
        for line in text.splitlines():
            d.add_paragraph(line)
        d.save(str(path))
    elif ext=='.pdf':
        _safe_pdf(text,path)
    elif ext=='.xlsx':
        from openpyxl import Workbook
        wb=Workbook()
        sheet=wb.active
        try:
            delimiter='\t' if '\t' in text.splitlines()[0] else ','
            records=list(csv.reader(io.StringIO(text),delimiter=delimiter))
        except (csv.Error,IndexError):
            records=[[line] for line in text.splitlines()]
        for row in records[:10000]:
            sheet.append([str(c)[:32767] for c in row[:100]])
        wb.save(path)
    else:
        raise ValueError('Unsupported export extension.')

# For a named-code-project, require explicit filename markers and a confirmation dialog.
CODE_BLOCK=re.compile(r'```(?:[\w+.#-]+)?\s+filename\s*[:=]\s*([^\n`]+)\n(.*?)```',re.S|re.I)
CODE_BLOCK_COMMENT=re.compile(r'```(?:[\w+.#-]+)?\n\s*(?:#|//)\s*(?:file|filename)\s*:\s*([^\n]+)\n(.*?)```',re.S|re.I)


def extract_named_files(answer:str)->dict[str,str]:
    matches=list(CODE_BLOCK.finditer(answer))+list(CODE_BLOCK_COMMENT.finditer(answer))
    files={}
    for match in matches:
        name=match.group(1).strip().strip('`"\'')
        pure=Path(name)
        if len(name)>120 or not name or pure.is_absolute() or len(pure.parts)!=1 or name.startswith('.') or '..' in name or '\\' in name or ':' in name:
            continue
        files[name]=match.group(2).strip('\n')+'\n'
    return files


def save_named_zip(path:Path, files:dict[str,str]):
    if not files:raise ValueError('No named code blocks. Ask AI to include: ```python filename=main.py')
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for name,content in files.items():
            z.writestr(name,content)


def extract_project_files(answer:str)->dict[str,str]:
    """Supports safe nested filenames for existing projects; preview_edits revalidates."""
    items={}
    for match in list(CODE_BLOCK.finditer(answer))+list(CODE_BLOCK_COMMENT.finditer(answer)):
        name=match.group(1).strip().strip('`"\'')
        if len(name)>225 or not name or name.startswith(('/', '.', '~')) or '\\' in name or ':' in name:
            continue
        parts=name.split('/')
        if any(p in ('', '.', '..') or p.startswith('.') for p in parts):continue
        items[name]=match.group(2).strip('\n')+'\n'
    return items
