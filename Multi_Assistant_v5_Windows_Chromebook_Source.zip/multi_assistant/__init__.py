"""Multi-Assistant portable desktop app."""
__version__ = "5.0.0-mandatory-features-preview"
