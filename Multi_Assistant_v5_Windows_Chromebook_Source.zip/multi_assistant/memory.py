"""Conservative local-only memory suggestion detector. Never auto approves."""
from __future__ import annotations
import re

CUES = (
  'mere paas', 'main use karta', 'main chahta', 'mera project', 'meri preference',
  'mujhe pasand', 'mera naam', 'main rehta', 'i own ', 'i have ', 'i prefer ',
  'i am working on', 'remember that', 'yaad rakh', 'note kar', 'always respond',
  'from now on', 'future mein', 'going forward', 'my project',
)
SECRETS = re.compile(r'(api[ _-]?key|password|passcode|secret|bearer\s+|token\s*[:=]|gsk_[a-zA-Z0-9]|sk-[A-Za-z0-9]{10}|private.key|otp\b|pin\s*(?:code|number|:))',re.I)


def suggest(text:str)->str|None:
    """Suggest an exact excerpt, never invent a fact; user approves in UI."""
    if not isinstance(text,str) or SECRETS.search(text):
        return None
    clean=' '.join(text.strip().split())
    if len(clean)<12 or len(clean)>550:
        return None
    if not any(cue in clean.lower() for cue in CUES):
        return None
    # Questions and one-time requests are poor long-term memories.
    if '?' in clean and not any(cue in clean.lower() for cue in ('remember that','yaad rakh','note kar')):
        return None
    return clean
