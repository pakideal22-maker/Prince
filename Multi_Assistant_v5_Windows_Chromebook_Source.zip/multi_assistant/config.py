from __future__ import annotations
import json
import os
from pathlib import Path
from . import portable_vault

APP_NAME = 'Multi-Assistant'
# Free-tier providers only. This list intentionally excludes paid-only providers.
# Some providers also offer paid plans: use their free account/tier for $0 usage.
PROVIDERS = {
    'Groq': {'key': 'GROQ_API_KEY', 'model': 'openai/gpt-oss-20b'},
    'OpenAI (Paid API)': {'key': 'OPENAI_API_KEY', 'model': 'gpt-4.1-mini'},
    'Gemini': {'key': 'GEMINI_API_KEY', 'model': 'gemini-3.5-flash-lite'},
    'OpenRouter Free': {'key': 'OPENROUTER_API_KEY', 'model': 'openrouter/free'},
    'Cerebras Free': {'key': 'CEREBRAS_API_KEY', 'model': 'llama3.1-8b'},
    'Cloudflare Free': {'key': 'CLOUDFLARE_API_TOKEN', 'model': '@cf/meta/llama-3.1-8b-instruct-fp8'},
}

# Guardrails to prevent OpenRouter accidentally calling paid models.
# Cloudflare is restricted to known ordinary Workers AI models, excluding
# models marked "paid billing required". User must stay in the free plan.
_FREE_MODELS = {
    'Groq': {'openai/gpt-oss-20b', 'openai/gpt-oss-120b'},
    'OpenAI (Paid API)': set(),
    'Gemini': {'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite',
               'gemini-2.5-flash', 'gemini-2.5-flash-lite'},
    'Cerebras Free': {'llama3.1-8b'},
    'Cloudflare Free': {'@cf/meta/llama-3.1-8b-instruct-fp8',
                        '@cf/meta/llama-3.1-8b-instruct-fp8-fast'},
}

def validate_free_model(provider: str, model: str) -> None:
    if provider not in PROVIDERS:
        raise ValueError('Paid or unsupported AI provider is disabled in Free Edition.')
    if provider == 'OpenAI (Paid API)':
        if not model or not model.startswith(('gpt-', 'o1','o3','o4')) or any(x in model for x in ('/', ' ', '..')) or len(model)>100:
            raise ValueError('OpenAI: enter a valid OpenAI chat model ID (paid API).')
        return
    if provider == 'OpenRouter Free':
        if model != 'openrouter/free' and not model.endswith(':free'):
            raise ValueError('OpenRouter Free: model must be openrouter/free or end in :free.')
    elif model not in _FREE_MODELS[provider]:
        raise ValueError(f'{provider}: this model is not on the allowed free-tier list. Select a supported free model.')

# Account ID is not a secret, but storing it in the Windows credential vault
# keeps account-specific settings in the same place as the token.
def get_cloudflare_account_id() -> str:
    if portable_vault.is_portable():
        return portable_vault.get_secret('CLOUDFLARE_ACCOUNT_ID')
    account = os.environ.get('CLOUDFLARE_ACCOUNT_ID', '').strip()
    if account:
        return account
    try:
        import keyring
        return (keyring.get_password(APP_NAME, 'CLOUDFLARE_ACCOUNT_ID') or '').strip()
    except Exception:
        return ''

def save_cloudflare_account_id(value: str) -> None:
    if portable_vault.is_portable():
        portable_vault.set_secret('CLOUDFLARE_ACCOUNT_ID',value.strip())
        return
    import keyring
    if value.strip():
        keyring.set_password(APP_NAME, 'CLOUDFLARE_ACCOUNT_ID', value.strip())
    else:
        try:
            keyring.delete_password(APP_NAME, 'CLOUDFLARE_ACCOUNT_ID')
        except keyring.errors.PasswordDeleteError:
            pass


# Legacy Groq model IDs are unavailable to free/developer accounts since 2026-08-16.
# Update only known retired defaults, without overwriting a user-selected valid model.
_GROQ_MODEL_REPLACEMENTS = {
    'llama-3.1-8b-instant': 'openai/gpt-oss-20b',
    'llama-3.3-70b-versatile': 'openai/gpt-oss-120b',
}

def _migrate_models(models: dict) -> dict:
    result = dict(models)
    current = result.get('Groq')
    if isinstance(current, str) and current.strip() in _GROQ_MODEL_REPLACEMENTS:
        result['Groq'] = _GROQ_MODEL_REPLACEMENTS[current.strip()]
    return result


def data_dir() -> Path:
    if portable_vault.is_portable():
        d = portable_vault.home() / 'Data'
        d.mkdir(parents=True, exist_ok=True)
        return d
    if os.name == 'nt':
        base = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData' / 'Local')))
    else:
        base = Path(os.environ.get('XDG_DATA_HOME', str(Path.home() / '.local' / 'share')))
    d = base / 'Multi-Assistant'
    d.mkdir(parents=True, exist_ok=True)
    return d


def config_path() -> Path:
    return data_dir() / 'settings.json'


def load_settings() -> dict:
    base = {'models': {k: v['model'] for k, v in PROVIDERS.items()},
            'instructions': 'Reply naturally in Roman Urdu unless I ask otherwise. Be accurate and clear.',
            'max_context_messages': 14, 'auto_memory': True, 'use_archive_context': True, 'auto_voice': False}
    try:
        raw = json.loads(config_path().read_text('utf-8'))
        if isinstance(raw, dict):
            for k in ('instructions', 'max_context_messages', 'auto_memory', 'use_archive_context', 'auto_voice'):
                if k in raw:
                    base[k] = raw[k]
            base['models'].update({k: str(v) for k, v in raw.get('models', {}).items() if k in PROVIDERS})
            base['models'] = _migrate_models(base['models'])
    except (OSError, ValueError, TypeError):
        pass
    return base


def save_settings(data: dict) -> None:
    p = config_path()
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), 'utf-8')
    tmp.replace(p)


def get_key(provider: str) -> str:
    env_key = PROVIDERS[provider]['key']
    if portable_vault.is_portable():
        return portable_vault.get_secret(env_key)
    if os.environ.get(env_key):
        return os.environ[env_key].strip()
    try:
        import keyring
        return (keyring.get_password('Multi-Assistant', env_key) or '').strip()
    except Exception:
        return ''


def put_key(provider: str, value: str) -> None:
    if portable_vault.is_portable():
        portable_vault.set_secret(PROVIDERS[provider]['key'],value.strip())
        return
    import keyring
    env_key = PROVIDERS[provider]['key']
    if value.strip():
        keyring.set_password('Multi-Assistant', env_key, value.strip())
    else:
        try:
            keyring.delete_password('Multi-Assistant', env_key)
        except keyring.errors.PasswordDeleteError:
            pass


# The Drive encryption passphrase lives only in the local OS credential vault;
# never in settings.json, the SQLite database or the Google Drive payload.
_SYNC_CREDENTIAL_SERVICE = 'Multi-Assistant Drive Sync'
_SYNC_CREDENTIAL_USER = 'encryption_passphrase'


def get_sync_passphrase() -> str:
    if portable_vault.is_portable():
        return portable_vault.get_secret(_SYNC_CREDENTIAL_USER)
    try:
        import keyring
        return keyring.get_password(_SYNC_CREDENTIAL_SERVICE, _SYNC_CREDENTIAL_USER) or ''
    except Exception:
        return ''


def save_sync_passphrase(passphrase: str) -> None:
    if len(passphrase) < 12:
        raise ValueError('Sync password must contain at least 12 characters.')
    if portable_vault.is_portable():
        portable_vault.set_secret(_SYNC_CREDENTIAL_USER,passphrase)
        return
    import keyring
    keyring.set_password(_SYNC_CREDENTIAL_SERVICE, _SYNC_CREDENTIAL_USER, passphrase)


def forget_sync_passphrase() -> None:
    if portable_vault.is_portable():
        portable_vault.set_secret(_SYNC_CREDENTIAL_USER,'')
        return
    import keyring
    try:
        keyring.delete_password(_SYNC_CREDENTIAL_SERVICE, _SYNC_CREDENTIAL_USER)
    except keyring.errors.PasswordDeleteError:
        pass


# Search API is OPTIONAL. Never send queries or incur provider charges silently.
def get_brave_search_key()->str:
    if portable_vault.is_portable():return portable_vault.get_secret('BRAVE_SEARCH_API_KEY')
    if os.environ.get('BRAVE_SEARCH_API_KEY'):return os.environ['BRAVE_SEARCH_API_KEY'].strip()
    try:
        import keyring
        return (keyring.get_password(APP_NAME,'BRAVE_SEARCH_API_KEY') or '').strip()
    except Exception:return ''

def save_brave_search_key(value:str)->None:
    if portable_vault.is_portable():
        portable_vault.set_secret('BRAVE_SEARCH_API_KEY',value.strip());return
    import keyring
    if value.strip():keyring.set_password(APP_NAME,'BRAVE_SEARCH_API_KEY',value.strip())
    else:
        try:keyring.delete_password(APP_NAME,'BRAVE_SEARCH_API_KEY')
        except keyring.errors.PasswordDeleteError:pass
