"""Provider API streaming. Uses remote inference, never local model execution."""
from __future__ import annotations
import json
from collections.abc import Iterator
from urllib.parse import quote
import requests
from .config import PROVIDERS, get_key, get_cloudflare_account_id, validate_free_model


class ProviderError(Exception):
    pass


def _error_response(resp):
    if resp.status_code >= 400:
        try:
            detail=resp.json()
            if isinstance(detail,dict):
                detail=detail.get('error',detail)
            if isinstance(detail,dict):
                detail=detail.get('message', str(detail))
        except Exception:
            detail=resp.text[:500]
        raise ProviderError(f'HTTP {resp.status_code}: {str(detail)[:500]}')


def _sse(resp: requests.Response) -> Iterator[tuple[str,str]]:
    """Convert SSE frames into (event name, data). Accumulates multiline data."""
    event='message'
    data=[]
    for line in resp.iter_lines(decode_unicode=True):
        if line is None:
            continue
        if isinstance(line,bytes):
            line=line.decode('utf-8',errors='replace')
        if not line:
            if data:
                yield event, '\n'.join(data)
            event, data='message', []
        elif line.startswith('event:'):
            event=line[6:].strip()
        elif line.startswith('data:'):
            data.append(line[5:].strip())
    if data:
        yield event, '\n'.join(data)


def _openai_stream(provider: str, msgs: list[dict], model: str):
    bases={'OpenAI (Paid API)':'https://api.openai.com/v1/chat/completions',
           'Groq':'https://api.groq.com/openai/v1/chat/completions',
           'OpenRouter Free':'https://openrouter.ai/api/v1/chat/completions',
           'Cerebras Free':'https://api.cerebras.ai/v1/chat/completions'}
    validate_free_model(provider,model)
    key=get_key(provider)
    if not key:
        raise ProviderError(f'{provider} API key missing. Settings > AI Keys mein save karo.')
    with requests.post(bases[provider], headers={'Authorization':f'Bearer {key}',
                  'Content-Type':'application/json'},
                  json={'model':model,'messages':msgs,'stream':True},
                  timeout=(12,120),stream=True) as resp:
        _error_response(resp)
        for _,data in _sse(resp):
            if data=='[DONE]':break
            try:
                chunk=json.loads(data)
            except json.JSONDecodeError:
                continue
            if chunk.get('error'):
                raise ProviderError(str(chunk['error'])[:500])
            for choice in chunk.get('choices',[]):
                content=choice.get('delta',{}).get('content','')
                if isinstance(content,str) and content:
                    yield content


def _gemini_stream(msgs: list[dict], model: str):
    validate_free_model('Gemini',model)
    key=get_key('Gemini')
    if not key:
        raise ProviderError('Gemini API key missing. Settings > AI Keys mein save karo.')
    system='\n'.join(m['content'] for m in msgs if m['role']=='system')
    contents=[]
    for m in msgs:
        if m['role']=='system':continue
        role='model' if m['role']=='assistant' else 'user'
        if contents and contents[-1]['role']==role:
            contents[-1]['parts'].append({'text':m['content']})
        else:
            contents.append({'role':role,'parts':[{'text':m['content']}]})
    url=('https://generativelanguage.googleapis.com/v1beta/models/' + quote(model,safe='') +
         ':streamGenerateContent?alt=sse')
    payload={'contents':contents,'generationConfig':{'maxOutputTokens':4096}}
    if system:
        payload['systemInstruction']={'parts':[{'text':system}]}
    with requests.post(url, headers={'x-goog-api-key':key,'Content-Type':'application/json'},
                       json=payload, timeout=(12,120), stream=True) as resp:
        _error_response(resp)
        for _,data in _sse(resp):
            try: obj=json.loads(data)
            except json.JSONDecodeError:continue
            if 'error' in obj:
                raise ProviderError(str(obj['error'])[:500])
            for candidate in obj.get('candidates',[]):
                for p in candidate.get('content',{}).get('parts',[]):
                    text=p.get('text')
                    if text and not p.get('thought'):
                        yield text


def _cloudflare_stream(msgs:list[dict],model:str):
    """Small, reliable REST request; token streamed providers remain incremental."""
    validate_free_model('Cloudflare Free', model)
    key=get_key('Cloudflare Free')
    account=get_cloudflare_account_id()
    if not key or not account:
        raise ProviderError('Cloudflare API token and Account ID both required in AI Settings.')
    # Strictly a known provider endpoint, never a user-supplied URL.
    if not all(c.isalnum() or c in '-_' for c in account):
        raise ProviderError('Invalid Cloudflare Account ID.')
    url=f'https://api.cloudflare.com/client/v4/accounts/{account}/ai/run/{model}'
    with requests.post(url,headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'},
                       json={'messages':msgs},timeout=(12,120)) as resp:
        _error_response(resp)
        data=resp.json()
        if not data.get('success',False):
            raise ProviderError('Cloudflare error: '+str(data.get('errors',data))[:350])
        result=data.get('result') or {}
        answer=result.get('response','') if isinstance(result,dict) else ''
        if not isinstance(answer,str) or not answer:
            raise ProviderError('Cloudflare returned no text. Check model support and quota.')
        yield answer


def stream(provider:str, messages:list[dict], model:str):
    if provider not in PROVIDERS:
        raise ProviderError('Unknown AI provider')
    validate_free_model(provider,model)
    if provider=='Gemini':
        yield from _gemini_stream(messages,model)
    elif provider=='Cloudflare Free':
        yield from _cloudflare_stream(messages,model)
    else:
        yield from _openai_stream(provider,messages,model)


def available_providers():
    return [p for p in PROVIDERS if get_key(p) and (p!='Cloudflare Free' or get_cloudflare_account_id())]
