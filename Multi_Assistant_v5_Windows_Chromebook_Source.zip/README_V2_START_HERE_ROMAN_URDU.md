# Multi-Assistant v2.0 — Windows PC Update

**Update:** 26 October 2026 | **System:** Windows PC, Python 3.12, 8 GB RAM

Ye previous Multi-Assistant v1.1 ke upar improvement hai, existing Gemini chat history aur saved key preserve karta hai. Software PySide6 native Windows desktop app hai, Chrome/browser interface nahi. Ye **source ZIP** hai; direct `.exe` installer nahi. Standalone `.exe` optional Windows build script se banti hai.

## Sabse asaan update (agar Multi-Assistant pehle se installed hai)

1. Purana Multi-Assistant **completely close** karo.
2. Apne current Multi-Assistant project folder ka ek backup copy bana lo. Example: `D:\Multi-Assistant-backup`.
3. Nayi `Multi_Assistant_Windows_PC_v2.zip` ko download aur **Extract All** karo.
4. Naye extracted folder ke `multi_assistant`, `tests`, `main.py`, `README` aur `.bat` files ko **apne purane Multi-Assistant project folder** mein copy karo. Windows `Replace files in destination` pooche to allow karo.
5. Purane folder se `START_WINDOWS.bat` double-click karo. Purani `.venv` environment available hai to dobara pip install ki zaroorat nahi.
6. Agar program dependency error de, `INSTALL_WINDOWS.bat` ek baar chalao, phir `START_WINDOWS.bat`.

**Alternative:** New extracted folder ko alag rakho, us mein `INSTALL_WINDOWS.bat` run karke `START_WINDOWS.bat` chalao. Dono tareeqon mein original local chat database ki default location same hai.

**Existing chats:** `%LOCALAPPDATA%\Multi-Assistant\chats.sqlite3` mein rehti hain. Package mein koi live SQLite database, passwords, API key, ya Google OAuth file included nahi. Gemini key Windows Credential Manager mein rehti hai. Existing database ko overwrite na karo.

## Kya naya hai

- Fresh polished dark interface: improved spacing/colors, sidebar sections, modern welcome screen, clear composer and quick prompt starters.
- **Import ChatGPT history**: direct OpenAI export `.zip` ya extracted `conversations.json` select karo. Export milne se pehle import ka koi step zaroori nahi.
- Import se pehle automatic SQLite backup: `%LOCALAPPDATA%\Multi-Assistant\backups\before_chatgpt_import_....sqlite3`.
- Stable source IDs: same archive dobara import karne par same chats/messages duplicate nahi bante.
- All text conversations from export (visible active branch), preserving titles and timestamps where available. Tool messages, attachments, audio, images, and internal hidden messages import nahi hotay. Kuch excessively long messages 150,000 characters par truncate ho sakte hain (summary mein count aayega).
- **Browse full archive**: sidebar ke last 350 se purani chats bhi title se dhoondho. Global text search puri database mein available hai.
- Bari conversations mein `Load older messages` button (90 at a time), taake 8GB RAM PC smooth rahe.
- Optional Settings checkbox: **Use relevant older chats as context**. **Default OFF** for privacy. Jab ON hoga to matching archive extracts chosen online AI ko ja sakte hain. Bina ON kiye archive locally browse/search ho sakta hai.
- Memory approval rule unchanged; ChatGPT import se long-term memories automatically approve nahi hoti.
- Existing AI providers, Gemini API, file output, coding ZIP, dashboard unchanged.
- Google Drive sync abhi optional/pending hai; is update ke liye connect karna required nahi.

## ChatGPT export aane par

1. ChatGPT data-export email se ZIP download karo. ZIP mein private chat history ho sakti hai, secure rakhna.
2. Multi-Assistant khol kar sidebar mein **Import ChatGPT history** dabao.
3. ZIP ya `conversations.json` file select karo.
4. Confirmation padh kar Yes karo. App import ke dauran open rakho.
5. Completion dialog mein counts aur automatic backup ka path milega.
6. Sidebar mein **Browse full archive** ya **Search conversations** se history kholo.

**Limits:** Direct `conversations.json` uncompressed size 200 MB tak supported hai; us se bara export alag importer upgrade maang sakta hai. ZIP mein attachments/images ka hona theek hai; importer sirf conversations.json read karega. Original ChatGPT conversations ka *visible text* import hota hai, internal model memory, hidden reasoning ya attached documents ke actual bytes nahi.

## Apni data safety

- App apni local DB and settings `%LOCALAPPDATA%\Multi-Assistant` mein rakhta hai. **Existing database ko automatically delete/replace nahi kiya jata.**
- Imported chats SQLite mein plaintext hain by default; Windows device encryption / BitLocker se PC protect karna behtar hai.
- API keys Windows Credential Manager mein stored hain, export ZIP mein nahi.
- Current selected chat ka recent context AI provider ko bheja jata hai. **Other imported history is not automatically forwarded** unless archive-context option turn ON kiya ho.
- Google Drive sync optional, default disconnected. Agar baad mein chalaoge to event log mein imported chats bhi sync ho sakti hain.

## Development testing

All Python source compiled, 40 offline unit tests passed (local DB, import dedup/backup, provider response parsing, file export and encrypted sync logic). **Windows GUI ka visual runtime test is environment mein nahi hua**, aur real ChatGPT export ke saath live import abhi nahi hua — user ke export ZIP par final verification baqi hai. Gemini reply aur old v1 local chat saving user ke PC par pehle confirm hue thay; updated v2 ka live test alag se zaroori hai.

Technical notes: tests run via `python -m unittest discover -s tests -v`. Project is independent of the ORION trading bot.
