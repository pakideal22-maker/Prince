@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Please run INSTALL_WINDOWS.bat first.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m pip install pyinstaller
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name Multi-Assistant --collect-all keyring main.py
if errorlevel 1 (
 echo EXE build failed. You can still run START_WINDOWS.bat
) else (
 echo EXE created in dist\Multi-Assistant.exe
)
pause
