@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %ERRORLEVEL%==0 (
  set "PY=py -3.12"
) else (
  set "PY=python"
)
%PY% --version || goto failed
if not exist .build_venv\Scripts\python.exe (
  %PY% -m venv .build_venv || goto failed
)
.build_venv\Scripts\python.exe -m pip install --upgrade pip || goto failed
.build_venv\Scripts\python.exe -m pip install -r requirements.txt -r requirements_drive.txt pyinstaller || goto failed
.build_venv\Scripts\python.exe -m unittest discover -s tests -p "test_*.py" -q || goto failed
.build_venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onefile --windowed --name Multi-Assistant-Portable-Windows --collect-all keyring --collect-all googleapiclient --collect-all google_auth_oauthlib --hidden-import google.auth.transport.requests --hidden-import google.oauth2.credentials main.py || goto failed
 echo.
 echo SUCCESS: dist\Multi-Assistant-Portable-Windows.exe
 echo Copy the EXE to an empty USB folder. It creates a Data folder next to itself.
 pause
 exit /b 0
:failed
 echo FAILED: check build errors above.
 pause
 exit /b 1
