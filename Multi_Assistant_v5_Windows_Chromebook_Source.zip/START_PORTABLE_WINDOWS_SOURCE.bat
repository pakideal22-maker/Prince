@echo off
cd /d "%~dp0"
set "MULTI_ASSISTANT_PORTABLE_HOME=%CD%"
if not exist .venv\Scripts\python.exe (
 echo Python dependencies not installed. Run INSTALL_WINDOWS.bat and INSTALL_DRIVE_SYNC.bat first.
 pause
 exit /b 1
)
.venv\Scripts\python.exe main.py
if errorlevel 1 pause
