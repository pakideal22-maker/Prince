@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3.12") else (set "PY=python")
echo [Multi-Assistant] Checking Python...
%PY% --version
if errorlevel 1 goto failed
%PY% -m venv .venv
if errorlevel 1 goto failed
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo INSTALL SUCCESS. Double click START_WINDOWS.bat
pause
exit /b 0
:failed
echo.
echo INSTALL FAILED. Install Python 3.12 (64-bit) with Add Python to PATH, then retry.
pause
exit /b 1
