# Changelog v3.3 — Free AI only

- Removed paid-only OpenAI, Claude and DeepSeek from AI chooser and active provider configuration.
- Added OpenRouter Free with free-router default and paid-model rejection guard.
- Added Cerebras Free API connector (no external SDK required) and model allowlist.
- Added Cloudflare Workers AI Free REST connector, token + account ID settings and model allowlist.
- Updated Auto fallback list to free-tier providers only.
- Preserved Gemini, Groq, local SQLite, Google Drive sync, memories and ChatGPT import.
- Free model configuration tests and mocked API endpoint tests included.
- No upgrade-time chat or credential deletion; old paid credentials are unused.
