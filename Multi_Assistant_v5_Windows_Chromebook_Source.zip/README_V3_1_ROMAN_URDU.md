# Multi-Assistant v3.1 — Windows PC Update

**Ye update PC ke liye hai, Chromebook/Android ke liye nahi.**

## Is update mein kya fix hua?

1. Window ke top-left mein Windows-style **File, Chat, Workspace, Settings** menus aa gaye hain. Workspace controls left sidebar se nikaal kar upar rakhe gaye hain.
2. Left sidebar sirf conversations dikhati hai. Center chat panel ko minimum width di hai. App start par pehli saved conversation **explicitly** load hoti hai. Chat title ke neeche `N saved messages` nazar aayega. Zarurat par **Chat > Reload current conversation** use karo.
3. Google Drive ka encryption passphrase ek successful sync ke baad **Windows Credential Manager** mein save hota hai. Manual Drive Sync click par saved password ho to dobara nahi poochta.
4. Google Drive connected hone par **har 10 minute automatic sync** rahegi. Windows restart ke baad app auto-reconnect try karegi.
5. App band karte waqt **Sync & Exit / Exit Without Sync / Cancel** options aayenge (jab Drive password already saved ho). `Sync & Exit` sync finish hone ke baad hi app band karega, aur password nahi maangega.
6. Har update mein purana Google Drive data aur local chat safe rakhna priority hai. Is ZIP mein tumhari personal SQLite file ya API keys nahi hain.

## Upgrade — pehle wala project folder

1. Multi-Assistant app **completely band** karo.
2. **Backup zaroor lo:** apne old program folder ki copy alag rakho. Agar mumkin ho to Windows Explorer mein address bar par `%LOCALAPPDATA%\Multi-Assistant` likh kar poore data folder ki bhi ek private backup copy bana lo. Is mein tumhari personal chats, credentials config aur sync files ho sakti hain: backup private rakhna.
3. ZIP **Extract All** karo. Extracted v3.1 ke andar se `multi_assistant` folder aur project ki updated files ko apne existing software folder mein copy karo aur **Replace the files in destination** select karo.
4. **`.venv` aur `%LOCALAPPDATA%\Multi-Assistant` replace/delete mat karna.** ZIP ko in folders ke upar as a whole extract mat karna. Old `.venv` ko rakho.
5. `START_WINDOWS.bat` chalao. Agar dependencies missing error aaye to `INSTALL_WINDOWS.bat` ek baar chalao.
6. App start hone par saved chat select karo. **Chat > Reload current conversation** bhi use kar sakte ho.
7. Workspace/Drive access: **Settings > Google Drive sync now**. Pehli v3.1 successful sync par agar purana password Windows Credential Manager mein pehle saved nahi tha, tab **ek baar** password dena padega. Aage successful save ke baad manually nahi maangega.
8. App X se band karoge to sync/exit ka option milega. Google ke expired authorization, password storage errors ya network outage mein reauthorization/repair phir bhi zaroori ho sakta hai.

**Har 10 minute sync tab chalta hai jab Multi-Assistant program open aur computer ON ho.** PC OFF mein background sync nahi hoga. Local SQLite mein saved data par asar nahi hota.

## Chat not visible?

- Multi-Assistant ko maximize karo.
- Left sidebar se saved conversation select karo; header mein `N saved messages` check karo.
- **Chat > Reload current conversation** dabao.
- Agar phir bhi empty chat pane aaye, error ka screenshot aur Windows terminal (`START_WINDOWS.bat`) ka error text bhejo. Chat database ko delete mat karna.

## Privacy

API keys aur sync passphrase Google Drive ke hidden app-data folder mein nahi jaate. API keys aur sync passphrase locally Windows Credential Manager mein store hote hain. Encrypted chat-event backups Google Drive `appDataFolder` mein rehte hain. Puri saved SQLite history normal local file hai, isliye Windows disk encryption helpful hai.

## Testing report

Python modules compile hue aur existing offline regression tests pass hue. **Qt/PySide6 GUI ko is Linux environment mein launch karke test nahi kar paaye** (GUI library install unavailable). Windows par real interface, restart aur close-time sync tests baqi hain. Isay v3.1 *testing update* samjho.
