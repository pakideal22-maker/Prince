# Multi-Assistant Portable — Windows / Chromebook

## Kya hai?
Yeh **existing Windows Multi-Assistant v3.4** ki USB portable-mode compatible source package hai.
Free-tier Gemini, Groq, OpenRouter, Cerebras, Cloudflare, existing chat UI, ChatGPT chat import,
SQLite, approved-memory controls aur encrypted Google Drive event sync ka code retain hai.
Naye planned Change #1-#10 ke advanced features is build mein implement nahi hue.

**Important:** Is ZIP mein precompiled Windows EXE ya Chromebook binary nahi; yeh build-ready source hai.
`BUILD_GITHUB_ACTIONS_PORTABLE.yml` GitHub Actions mein use kar ke alag Windows EXE aur x86_64 Chromebook Linux binary banao.
Windows EXE Chromebook par directly nahi chalti. ChromeOS ARM Chromebook par Linux binary bhi nahi chalegi.
Agar Chromebook Google Play/Android apps support karta ho, existing Multi-Assistant Android APK alternative hai (yeh Windows build us APK ka replacement nahi).

## Portable Windows (once compiled)
1. Built `Multi-Assistant-Portable-Windows.exe` ko USB ke `Multi-Assistant` folder mein copy karo.
2. USB se EXE double-click karo, install ki zaroorat nahi (Microsoft VC/OS dependencies ho sakti hain).
3. Pehli baar **12+ characters ka portable master password** banao.
4. App USB ke EXE ke paas `Data/` folder banayegi. Data mein chats SQLite aur settings hain.
5. API keys pehli baar portable vault mein save karo; old PC Credential Manager se automatically migrate nahi hoti.
6. Drive ke liye wohi **Google account**, original **sync password**, aur Desktop OAuth JSON file use karo.
7. Purani PC chats chahiye to sabse pehle original Windows app mein **Sync Now** karo; phir portable app se **Sync Now**.
8. App CLOSE hone ke baad USB safely eject karo. Original PC `%LOCALAPPDATA%\\Multi-Assistant` ko hum touch nahi karte.

## Chromebook
- Option A: Chromebook **Linux development environment (x86_64)** enabled ho aur GUI dependencies installed hon.
  Linux artifact ko extract kar ke `Multi-Assistant-Portable-Linux` executable chalao.
  Linux container se USB folder access and executables may require Linux Files mein copying/mount permissions.
- Option B: Chromebook Play Store Android apps support kare to already built Android APK install karke same Google Drive sync use karo.
- ARM Chromebook aur Linux-disabled ChromeOS par packaged Linux executable unsupported.

## Credential/data safety
- `Data/portable_secrets.mas2`: API keys, Drive passphrase aur Google OAuth refresh tokens **AES-GCM/Scrypt encrypted**.
- `Data/chats.sqlite3` and imported chat history are **NOT encrypted**. Use an encrypted USB drive
  (e.g. VeraCrypt/BitLocker where supported). Avoid leaving USB unattended.
- All files stored on USB next to compiled EXE; never upload `Data/` to public GitHub.
- Do not simultaneously run the SAME USB database from multiple computers; always close the app first.
- Password lost = portable saved credentials unrecoverable; Drive synced chats can be restored with original Google account + sync passphrase on a new workspace.
- No automatic migration of Windows OS keyring secrets. Avoid using a public/untrusted computer.

## How to build from GitHub Actions (no Python on your own PC)
1. GitHub repo `pakideal22-maker/Prince` mein **`Multi_Assistant_Portable_Source.zip`** (this source) upload karo.
2. `BUILD_GITHUB_ACTIONS_PORTABLE.yml` ka content repo mein `.github/workflows/build-portable.yml` naam se add karo.
3. GitHub > Actions > **Build Multi-Assistant portable Windows and Chromebook** > **Run workflow**.
4. Successful Actions run ke end par 2 artifacts milenge: Windows EXE aur Chromebook Linux x86_64 tar.gz.
5. Windows EXE ko USB mein seedha copy karna hai; Linux tar extract karke run karna hai.

## Local source (alternative)
Windows installed Python 3.12: `INSTALL_WINDOWS.bat`, `INSTALL_DRIVE_SYNC.bat`, then `START_PORTABLE_WINDOWS_SOURCE.bat`.
Chromebook Linux x86_64, Python3: `START_PORTABLE_CHROMEBOOK_SOURCE.sh`.
Windows build with Python: `BUILD_PORTABLE_WINDOWS.bat`.
Chromebook Linux build: `BUILD_PORTABLE_CHROMEBOOK_LINUX.sh`.

## Verification
- Source compiles on Python 3.13 Linux.
- Automated core tests pass on Linux.
- Actual Windows EXE, ChromeOS Linux binary and end-to-end OAuth GUI are **not verified** in this environment.
