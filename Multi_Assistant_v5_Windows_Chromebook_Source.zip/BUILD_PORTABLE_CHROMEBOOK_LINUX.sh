#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "$(uname -m)" != "x86_64" ]]; then
  echo 'This Linux portable binary build targets x86_64 only; ARM Chromebook is not supported.'
  exit 1
fi
python3 -m venv .build_venv
.build_venv/bin/python -m pip install --upgrade pip
.build_venv/bin/python -m pip install -r requirements.txt -r requirements_drive.txt pyinstaller
.build_venv/bin/python -m unittest discover -s tests -p 'test_*.py' -q
.build_venv/bin/python -m PyInstaller --noconfirm --clean --onefile --windowed --name Multi-Assistant-Portable-Linux --collect-all keyring --collect-all googleapiclient --collect-all google_auth_oauthlib --hidden-import google.auth.transport.requests --hidden-import google.oauth2.credentials main.py
chmod +x dist/Multi-Assistant-Portable-Linux
echo 'Built: dist/Multi-Assistant-Portable-Linux'
