@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Please run INSTALL_WINDOWS.bat first.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m pip install -r requirements_drive.txt
pause
