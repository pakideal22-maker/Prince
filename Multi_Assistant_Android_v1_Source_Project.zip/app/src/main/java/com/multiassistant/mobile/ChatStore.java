package com.multiassistant.mobile;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.UUID;

/** On-device only SQLite history. No secrets are stored in this database. */
public final class ChatStore extends SQLiteOpenHelper {
    public ChatStore(Context c) { super(c, "multi_assistant_android.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE chats(id TEXT PRIMARY KEY,title TEXT NOT NULL,created INTEGER NOT NULL,updated INTEGER NOT NULL,pinned INTEGER DEFAULT 0,archived INTEGER DEFAULT 0,deleted INTEGER DEFAULT 0)");
        d.execSQL("CREATE TABLE messages(id TEXT PRIMARY KEY,chat_id TEXT NOT NULL,role TEXT NOT NULL,content TEXT NOT NULL,provider TEXT,created INTEGER NOT NULL)");
        d.execSQL("CREATE INDEX idx_messages_chat ON messages(chat_id,created)");
        d.execSQL("CREATE TABLE memories(id TEXT PRIMARY KEY,text TEXT NOT NULL,state TEXT NOT NULL,created INTEGER NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV) { /* Future migrations; do not drop data. */ }
    private static long now() { return System.currentTimeMillis(); }
    private static JSONObject obj(Cursor c) throws Exception {
        JSONObject j=new JSONObject();
        for(int i=0;i<c.getColumnCount();i++){
            String n=c.getColumnName(i);
            if(c.getType(i)==Cursor.FIELD_TYPE_INTEGER)j.put(n,c.getLong(i));
            else j.put(n,c.isNull(i)?JSONObject.NULL:c.getString(i));
        }
        return j;
    }
    private JSONArray select(String sql, String... args) {
        JSONArray out=new JSONArray();
        try(Cursor c=getReadableDatabase().rawQuery(sql,args)) {
            while(c.moveToNext())out.put(obj(c));
        } catch(Exception e){ throw new IllegalStateException(e); }
        return out;
    }
    public synchronized String newChat() {
        String id=UUID.randomUUID().toString(); long t=now();
        ContentValues v=new ContentValues();v.put("id",id);v.put("title","New Chat");v.put("created",t);v.put("updated",t);
        getWritableDatabase().insertOrThrow("chats",null,v);return id;
    }
    public synchronized JSONArray chats(boolean archived) {
        return select("SELECT * FROM chats WHERE deleted=0 AND archived="+(archived?1:0)+" ORDER BY pinned DESC,updated DESC LIMIT 500");
    }
    public synchronized JSONArray messages(String id) {
        return select("SELECT id,chat_id,role,content,provider,created FROM messages WHERE chat_id=? ORDER BY created,id LIMIT 5000",id);
    }
    public synchronized JSONObject chat(String id) {
        JSONArray a=select("SELECT * FROM chats WHERE id=? AND deleted=0",id);
        return a.length()>0?a.optJSONObject(0):new JSONObject();
    }
    public synchronized void addMessage(String id,String role,String content,String provider) {
        if(chat(id).length()==0)throw new IllegalArgumentException("Chat unavailable");
        ContentValues v=new ContentValues();v.put("id",UUID.randomUUID().toString());v.put("chat_id",id);v.put("role",role);
        v.put("content",content);v.put("provider",provider);v.put("created",now());
        getWritableDatabase().insertOrThrow("messages",null,v);
        ContentValues update=new ContentValues();update.put("updated",now());
        try(Cursor c=getReadableDatabase().rawQuery("SELECT title FROM chats WHERE id=?",new String[]{id})){
            if(c.moveToFirst() && "New Chat".equals(c.getString(0)) && "user".equals(role)){
                String title=content.replaceAll("\\s+"," ").trim();
                update.put("title",title.length()>48?title.substring(0,48)+"…":title);
            }
        }
        getWritableDatabase().update("chats",update,"id=?",new String[]{id});
    }
    public synchronized void changeChat(String id,String action,String value){
        if(chat(id).length()==0)return;
        ContentValues v=new ContentValues();
        switch(action){
            case "rename": v.put("title",value.trim().substring(0,Math.min(100,value.trim().length())));break;
            case "pin":v.put("pinned","true".equals(value)?1:0);break;
            case "archive":v.put("archived","true".equals(value)?1:0);break;
            case "delete":v.put("deleted",1);break;
            default:throw new IllegalArgumentException("Unknown action");
        }
        v.put("updated",now());getWritableDatabase().update("chats",v,"id=?",new String[]{id});
    }
    public synchronized JSONArray memories(String state) {
        if("all".equals(state))return select("SELECT * FROM memories ORDER BY created DESC");
        return select("SELECT * FROM memories WHERE state=? ORDER BY created DESC",state);
    }
    public synchronized String suggest(String text){
        text=text.trim();if(text.isEmpty()||text.length()>700)return "";
        try(Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM memories WHERE lower(text)=lower(?) AND state != 'rejected'",new String[]{text})){
            if(c.moveToNext())return "";
        }
        String id=UUID.randomUUID().toString();ContentValues v=new ContentValues();v.put("id",id);v.put("text",text);v.put("state","pending");v.put("created",now());
        getWritableDatabase().insertOrThrow("memories",null,v);return id;
    }
    public synchronized void decide(String id,String action){
        if(!"approved".equals(action)&&!"rejected".equals(action)&&!"deleted".equals(action))return;
        ContentValues v=new ContentValues();v.put("state",action);
        getWritableDatabase().update("memories",v,"id=?",new String[]{id});
    }
    public synchronized JSONArray providerContext(String chatId,int count){
        JSONArray source=select("SELECT role,content FROM (SELECT role,content,created,id FROM messages WHERE chat_id=? ORDER BY created DESC,id DESC LIMIT ?) ORDER BY created ASC,id ASC",chatId,String.valueOf(count));
        return source;
    }
    public synchronized String approvedContext(){
        JSONArray a=memories("approved");StringBuilder b=new StringBuilder();
        for(int i=0;i<a.length()&&i<30;i++){String s=a.optJSONObject(i).optString("text");if(b.length()+s.length()>4500)break;b.append("- ").append(s).append('\n');}
        return b.toString();
    }
}
