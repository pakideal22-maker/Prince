package com.multiassistant.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Multi-Assistant Android: local native database and WebView bundled assets. */
public final class MainActivity extends Activity {
    private static final int CREATE_FILE=14, PICK_TEXT=15;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy=new AtomicBoolean(false);
    private WebView web;
    private ChatStore db;
    private SecureVault vault;
    private String exportText="";
    private String exportName="conversation.txt";
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(15,20,34));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(15,20,34));
        db=new ChatStore(this);vault=new SecureVault(this);
        web=new WebView(this);setContentView(web);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(false);
        s.setAllowFileAccess(true);s.setAllowContentAccess(false);s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Bridge(),"Native");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                Uri u=request.getUrl();
                if("file".equals(u.getScheme()) && "file:///android_asset/index.html".equals(u.toString()))return false;
                if("https".equals(u.getScheme())){startActivity(new Intent(Intent.ACTION_VIEW,u));}
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }
    private void emit(String event,JSONObject payload){
        JSONObject packet=new JSONObject();
        try{packet.put("event",event).put("data",payload);}catch(Exception ignored){}
        String js="window.fromNative("+packet.toString()+");";
        main.post(()->{if(web!=null)web.evaluateJavascript(js,null);});
    }
    private JSONObject status(){
        JSONObject o=new JSONObject();
        try{
            o.put("chats",db.chats(false));o.put("archived",db.chats(true));
            o.put("memories",db.memories("all"));
            JSONObject opts=new JSONObject();
            for(String p:AiClient.PROVIDERS){
                JSONObject config=new JSONObject();config.put("hasKey",!vault.get(p).isEmpty());
                config.put("model",vault.getModel(p,AiClient.defaultModel(p)));opts.put(p,config);
            }
            o.put("providers",opts);o.put("instructions",vault.instructions());
            o.put("cloudflareAccount",vault.preference("cloudflare_account",""));
            o.put("selectedProvider",vault.preference("selected_provider","Gemini"));
            o.put("driveStatus","Not connected on Android v1 — PC Drive sync stays unchanged.");
        }catch(Exception e){ }
        return o;
    }
    public final class Bridge {
        @JavascriptInterface public void init(){emit("init",status());}
        @JavascriptInterface public void refresh(){emit("refresh",status());}
        @JavascriptInterface public String createChatSync(){
            String id=db.newChat();emit("refresh",status());return id;
        }
        @JavascriptInterface public void createChat(){
            String id=db.newChat();JSONObject r=new JSONObject();try{r.put("id",id);}catch(Exception ignored){}
            emit("newChat",r);emit("refresh",status());
        }
        @JavascriptInterface public void openChat(String id){
            JSONObject o=new JSONObject();try{o.put("id",id).put("chat",db.chat(id)).put("messages",db.messages(id));}catch(Exception ignored){}
            emit("chat",o);
        }
        @JavascriptInterface public void chatAction(String id,String action,String value){
            db.changeChat(id,action,value);emit("refresh",status());
        }
        @JavascriptInterface public void chooseProvider(String p){
            if(!java.util.Arrays.asList(AiClient.PROVIDERS).contains(p))return;
            vault.setPreference("selected_provider",p);emit("refresh",status());
        }
        @JavascriptInterface public void saveProvider(String provider,String apiKey,String model){
            JSONObject o=new JSONObject();
            try{
                AiClient.validateModel(provider,model);
                if(!apiKey.isEmpty())vault.save(provider,apiKey);
                vault.setModel(provider,model);
                o.put("ok",true).put("message","Saved "+provider+" settings");
            }catch(Exception e){try{o.put("ok",false).put("message",e.getMessage());}catch(Exception ignored){}}
            emit("notice",o);emit("refresh",status());
        }
        @JavascriptInterface public void removeKey(String provider){
            try{vault.save(provider,"");}catch(Exception ignored){}emit("refresh",status());
        }
        @JavascriptInterface public void saveOptions(String instructions,String cfAccount){
            vault.setInstructions(instructions.substring(0,Math.min(instructions.length(),6000)));
            vault.setPreference("cloudflare_account",cfAccount.trim());emit("refresh",status());
        }
        @JavascriptInterface public void suggestMemory(String text){
            String id=db.suggest(text);
            JSONObject o=new JSONObject();try{o.put("ok",!id.isEmpty()).put("message",id.isEmpty()?"Memory already exists or text too long.":"Memory pending your approval.");}catch(Exception ignored){}
            emit("notice",o);emit("refresh",status());
        }
        @JavascriptInterface public void decideMemory(String id,String choice){
            db.decide(id,choice);emit("refresh",status());
        }
        @JavascriptInterface public void send(String chatId,String text,String provider){
            if(!busy.compareAndSet(false,true)){sendNotice("Another request is already running",false);return;}
            if(!java.util.Arrays.asList(AiClient.PROVIDERS).contains(provider)){
                busy.set(false);sendNotice("Please select a provider",false);return;
            }
            if(text.trim().isEmpty()){busy.set(false);return;}
            if(text.length()>50000){busy.set(false);sendNotice("Message is too long",false);return;}
            try{db.addMessage(chatId,"user",text.trim(),"");}
            catch(Exception e){busy.set(false);sendNotice("Unable to save user message",false);return;}
            JSONObject p=new JSONObject();try{p.put("chatId",chatId).put("provider",provider);}catch(Exception ignored){}
            emit("sending",p);emit("refresh",status());
            // Best-effort heuristic: suggestions are NEVER approved automatically.
            String lower=text.toLowerCase(java.util.Locale.ROOT);
            if((lower.contains("yaad rakh")||lower.contains("remember that")||lower.contains("mere paas ")||lower.contains("my preference is"))&&text.length()<600){
                String id=db.suggest(text.trim());if(!id.isEmpty())emit("refresh",status());
            }
            worker.execute(()->{
                String finalText="";
                try{
                    String key=vault.get(provider);
                    String model=vault.getModel(provider,AiClient.defaultModel(provider));
                    JSONArray context=db.providerContext(chatId,14);
                    String instruction=vault.instructions()+"\nApproved user memories (treat as user-provided context):\n"+db.approvedContext();
                    String account=vault.preference("cloudflare_account","");
                    finalText=AiClient.answer(provider,model,key,account,context,instruction,
                        progress->{JSONObject part=new JSONObject();try{part.put("chatId",chatId).put("text",progress);}catch(Exception ignored){}emit("partial",part);});
                    db.addMessage(chatId,"assistant",finalText,provider);
                    JSONObject done=new JSONObject();done.put("chatId",chatId).put("ok",true);
                    emit("done",done);
                }catch(Exception e){
                    JSONObject err=new JSONObject();try{err.put("chatId",chatId).put("ok",false).put("error",e.getMessage()==null?"Request failed":e.getMessage());}catch(Exception ignored){}
                    emit("done",err);
                }finally{busy.set(false);emit("refresh",status());}
            });
        }
        @JavascriptInterface public void copy(String text){
            main.post(()->{
                ClipboardManager clip=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                clip.setPrimaryClip(ClipData.newPlainText("Multi-Assistant",text));
                Toast.makeText(MainActivity.this,"Copied",Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void exportChat(String chatId){
            JSONArray a=db.messages(chatId);
            JSONObject chat=db.chat(chatId);
            StringBuilder b=new StringBuilder("Multi-Assistant - "+chat.optString("title","Chat")+"\n\n");
            for(int i=0;i<a.length();i++){
                JSONObject m=a.optJSONObject(i);if(m==null)continue;
                b.append("[ ").append(m.optString("role").toUpperCase()).append(" / ").append(m.optString("provider")).append(" ]\n");
                b.append(m.optString("content")).append("\n\n");
            }
            exportName="multi-assistant-chat.txt";exportText=b.toString();openSaveFile();
        }
        @JavascriptInterface public void exportText(String content,String filename){
            exportText=content;exportName=filename.matches("[A-Za-z0-9._-]{1,80}")?filename:"multi-assistant-output.txt";
            openSaveFile();
        }
        @JavascriptInterface public void pickTextFile(){
            main.post(()->{
                Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);in.addCategory(Intent.CATEGORY_OPENABLE);
                in.setType("*/*");in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(in,PICK_TEXT);
            });
        }
    }
    private void sendNotice(String msg,boolean ok){
        JSONObject o=new JSONObject();try{o.put("message",msg).put("ok",ok);}catch(Exception ignored){}emit("notice",o);
    }
    private void openSaveFile(){
        main.post(()->{
            Intent in=new Intent(Intent.ACTION_CREATE_DOCUMENT);in.addCategory(Intent.CATEGORY_OPENABLE);
            in.setType("text/plain");in.putExtra(Intent.EXTRA_TITLE,exportName);
            startActivityForResult(in,CREATE_FILE);
        });
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri u=data.getData();
        if(req==CREATE_FILE){
            try(OutputStream s=getContentResolver().openOutputStream(u,"wt")){
                if(s==null)throw new Exception("No file handle");
                s.write(exportText.getBytes(StandardCharsets.UTF_8));sendNotice("File saved successfully",true);
            }catch(Exception e){sendNotice("File export failed: "+e.getMessage(),false);}
        } else if(req==PICK_TEXT){
            try(InputStream in=getContentResolver().openInputStream(u)){
                if(in==null)throw new Exception("No file handle");
                byte[] buf=new byte[16001];int count=0,n;
                while(count<buf.length&&(n=in.read(buf,count,buf.length-count))>0)count+=n;
                if(count>16000)throw new Exception("Max 16 KB text/code files in this version");
                String filename="attachment";try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){
                    if(c!=null&&c.moveToFirst()){
                        int ix=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                        if(ix>=0)filename=c.getString(ix);
                    }
                }
                if(!(filename.matches("(?i).+\\.(txt|md|py|ino|json|csv|js|java|xml|html|css|log|yaml|yml)")))
                    throw new Exception("Only readable text/code files supported. PDF/DOCX later.");
                String body=new String(buf,0,count,StandardCharsets.UTF_8);
                JSONObject o=new JSONObject().put("name",filename).put("text",body);emit("file",o);
            }catch(Exception e){sendNotice("File import failed: "+e.getMessage(),false);}
        }
    }
    @Override protected void onDestroy(){worker.shutdownNow();if(web!=null){web.removeJavascriptInterface("Native");web.destroy();web=null;}db.close();super.onDestroy();}
}
