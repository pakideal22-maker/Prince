'use strict';
const $ = id => document.getElementById(id);
const PROVIDERS=['Gemini','Groq','OpenRouter Free','Cerebras Free','Cloudflare Free'];
const ui={data:{chats:[],archived:[],memories:[],providers:{}},chatId:null,provider:'Gemini',archived:false,busy:false,lastAnswer:'',messages:[],streamBox:null,openedMenu:null};
const escapeHtml=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
function toast(message){$('toast').textContent=message;$('toast').classList.remove('hidden');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>$('toast').classList.add('hidden'),3300);}
function nativeCall(method,...args){if(window.Native&&typeof Native[method]==='function')return Native[method](...args);toast('Android APK mein ye feature available hoga.');return null;}
function closeDrawer(){$('drawer').classList.add('hidden');$('scrim').classList.add('hidden');ui.openedMenu=null;}
function openDrawer(){renderChatList();$('drawer').classList.remove('hidden');$('scrim').classList.remove('hidden');}
function openPanel(name){
  closeDrawer();$('modelMenu').classList.add('hidden');
  document.querySelectorAll('.bottomNav button').forEach(b=>b.classList.toggle('selected',b.dataset.panel===name));
  if(name==='chat'){$('overlay').classList.add('hidden');return;}
  $('sheetTitle').textContent=({memory:'Smart Memory',settings:'AI Settings',files:'File Tools'})[name];
  $('overlay').classList.remove('hidden');
  if(name==='memory')renderMemories(); else if(name==='settings')renderSettings(); else renderFiles();
}
function chooseModel(p){if(!PROVIDERS.includes(p))return;ui.provider=p;$('modelLabel').textContent=p;$('modelMenu').classList.add('hidden');nativeCall('chooseProvider',p);}
function renderModels(){
  const target=$('models');target.replaceChildren();
  PROVIDERS.forEach(p=>{
    const b=document.createElement('button');b.className=p===ui.provider?'active':'';
    const data=ui.data.providers?.[p];b.textContent=p+(data?.hasKey?'  ✓':'');
    b.addEventListener('click',()=>chooseModel(p));target.append(b);
  });
}
function getChatTitle(id){return (ui.data.chats||[]).concat(ui.data.archived||[]).find(x=>x.id===id)?.title||'New Chat';}
function renderChatList(){
  const list=$('chatList');list.replaceChildren();
  const search=$('searchChats').value.toLowerCase();
  const all=ui.archived?(ui.data.archived||[]):(ui.data.chats||[]);
  const chats=all.filter(c=>String(c.title).toLowerCase().includes(search));
  if(!chats.length){const empty=document.createElement('div');empty.className='empty';empty.textContent=ui.archived?'No archived chats':'No conversations yet';list.append(empty);return;}
  chats.forEach(c=>{
    const container=document.createElement('div');
    const row=document.createElement('div');row.className='chatItem'+(ui.chatId===c.id?' active':'');
    const open=document.createElement('button');open.className='name';open.textContent=(c.pinned?'📌 ':'')+c.title;
    open.addEventListener('click',()=>openChat(c.id));
    const menu=document.createElement('button');menu.className='dots';menu.textContent='⋯';menu.setAttribute('aria-label','Chat options');
    menu.addEventListener('click',()=>{ui.openedMenu=ui.openedMenu===c.id?null:c.id;renderChatList();});
    row.append(open,menu);container.append(row);
    if(ui.openedMenu===c.id){
      const actions=[['Rename','rename'],[c.pinned?'Unpin':'Pin to top','pin'],[c.archived?'Unarchive':'Archive','archive'],['Export chat','export'],['Delete chat','delete']];
      const opts=document.createElement('div');opts.className='contextMenu';
      actions.forEach(([label,action])=>{const b=document.createElement('button');b.textContent=label;
        if(action==='delete')b.className='danger';b.addEventListener('click',()=>{
          if(action==='rename'){
            const title=window.prompt('New chat title',c.title);if(title&&title.trim())nativeCall('chatAction',c.id,'rename',title.trim());
          } else if(action==='delete'){
            if(window.confirm('Delete this chat from this Android device? This cannot be undone.')){
              nativeCall('chatAction',c.id,'delete','');if(ui.chatId===c.id){ui.chatId=null;showWelcome();}
            }
          } else if(action==='export'){nativeCall('exportChat',c.id);}
          else if(action==='pin'){nativeCall('chatAction',c.id,'pin',String(!Boolean(c.pinned)));}
          else if(action==='archive'){
            nativeCall('chatAction',c.id,'archive',String(!Boolean(c.archived)));
            if(ui.chatId===c.id&& !c.archived){ui.chatId=null;showWelcome();}
          }
          ui.openedMenu=null;
        });opts.append(b);});container.append(opts);
    }
    list.append(container);
  });
}
function showWelcome(){
  ui.chatId=null;ui.messages=[];ui.lastAnswer='';ui.streamBox=null;
  $('chatHead').classList.add('hidden');$('messages').replaceChildren();
  const welcome=document.createElement('section');welcome.className='welcome';
  const logo=document.createElement('div');logo.className='welcomeIcon';logo.textContent='✦';
  const h=document.createElement('h1');h.textContent='How can I help?';
  const p=document.createElement('p');p.textContent='One assistant. Multiple AI brains.';
  const quick=document.createElement('div');quick.className='quickPrompts';
  [['⚡ Arduino circuits','Arduino ATtiny45 ka motor control example banao'],['⌘ Coding help','Mere Python code ko review karne mein help karo'],['✎ Write a document','Mujhe professional letter ka draft likh do'],['◎ Project planning','Mujhe electronics project ka step-by-step plan banao']].forEach(([label,question])=>{
    const b=document.createElement('button');b.textContent=label;b.addEventListener('click',()=>{$('input').value=question;$('input').focus();});quick.append(b);
  });welcome.append(logo,h,p,quick);$('messages').append(welcome);
}
function openChat(id){ui.chatId=id;ui.streamBox=null;closeDrawer();$('overlay').classList.add('hidden');nativeCall('openChat',id);}
function addMessage(role,content,provider,partial=false){
  const el=document.createElement('article');el.className='message '+(role==='user'?'user':'assistant');
  const bubble=document.createElement('div');bubble.className='bubble'+(partial?' partial':'');bubble.textContent=content;
  const meta=document.createElement('div');meta.className='meta';
  const who=document.createElement('span');who.textContent=role==='user'?'You':('Multi-Assistant'+(provider?' • '+provider:''));meta.append(who);
  if(role==='assistant'){
    const cp=document.createElement('button');cp.textContent='Copy';cp.addEventListener('click',()=>nativeCall('copy',bubble.textContent));meta.append(cp);
    const save=document.createElement('button');save.textContent='Save file';save.addEventListener('click',()=>exportAnswer(bubble.textContent));meta.append(save);
  }
  el.append(bubble,meta);$('messages').append(el);scrollEnd();return bubble;
}
function scrollEnd(){const box=$('messages');box.scrollTop=box.scrollHeight;}
function renderMessages(rows){
  ui.messages=rows||[];ui.streamBox=null;$('messages').replaceChildren();$('chatHead').classList.remove('hidden');
  $('chatTitle').textContent=getChatTitle(ui.chatId);
  if(!rows||!rows.length){addMessage('assistant','Start the conversation. Your messages are stored privately on this phone.','');return;}
  for(const row of rows){addMessage(row.role,row.content,row.provider||'',false);if(row.role==='assistant')ui.lastAnswer=row.content;}
}
function sendMessage(){
  const text=$('input').value.trim();if(!text||ui.busy)return;
  if(!ui.chatId){const id=nativeCall('createChatSync');if(!id){nativeCall('createChat');toast('Creating chat; tap Send again.');return;}ui.chatId=id;}
  $('input').value='';resizeInput();ui.busy=true;$('send').disabled=true;
  if($('chatHead').classList.contains('hidden')){$('chatHead').classList.remove('hidden');$('messages').replaceChildren();}
  addMessage('user',text,'');ui.streamBox=addMessage('assistant','Connecting to '+ui.provider+'... ',ui.provider,true);
  nativeCall('send',ui.chatId,text,ui.provider);
}
function renderMemories(){
  const parent=$('sheetBody');parent.replaceChildren();
  const help=document.createElement('div');help.className='noticeBox';help.textContent='Long-term memory saves only after you approve. Normal conversations save automatically.';parent.append(help);
  const input=document.createElement('textarea');input.className='field';input.placeholder='Suggest something useful to remember...';input.rows=3;
  const save=document.createElement('button');save.className='btn';save.textContent='Suggest memory';save.addEventListener('click',()=>{nativeCall('suggestMemory',input.value);input.value='';});
  const wrapper=document.createElement('div');wrapper.className='settingCard';wrapper.innerHTML='<h3>Add a memory suggestion</h3>';wrapper.append(input,save);parent.append(wrapper);
  const all=ui.data.memories||[];
  const pending=all.filter(m=>m.state==='pending'),approved=all.filter(m=>m.state==='approved');
  for(const [title,arr] of [['Awaiting your approval',pending],['Approved memories',approved]]){
    const h=document.createElement('h3');h.textContent=title+' ('+arr.length+')';parent.append(h);
    if(!arr.length){const el=document.createElement('p');el.className='soft';el.textContent='No memories here yet.';parent.append(el);continue;}
    arr.forEach(m=>{
      const card=document.createElement('div');card.className='memoryCard';
      const text=document.createElement('p');text.textContent=m.text;card.append(text);
      if(m.state==='pending'){
        const yes=document.createElement('button');yes.className='btn';yes.textContent='Approve';yes.addEventListener('click',()=>nativeCall('decideMemory',m.id,'approved'));
        const no=document.createElement('button');no.className='btn secondary';no.textContent='Reject';no.addEventListener('click',()=>nativeCall('decideMemory',m.id,'rejected'));card.append(yes,no);
      }else{
        const del=document.createElement('button');del.className='btn warn';del.textContent='Forget';del.addEventListener('click',()=>{if(window.confirm('Remove this memory?'))nativeCall('decideMemory',m.id,'deleted');});card.append(del);
      }parent.append(card);
    });
  }
}
function renderSettings(){
  const parent=$('sheetBody');parent.replaceChildren();
  const intro=document.createElement('div');intro.className='noticeBox';intro.textContent='Free-tier providers only. Keys stay encrypted on this Android device and are NOT copied automatically from Windows.';parent.append(intro);
  PROVIDERS.forEach(p=>{
    const opt=ui.data.providers?.[p]||{};
    const card=document.createElement('section');card.className='settingCard';
    const h=document.createElement('h3');h.textContent=p+' ';const chip=document.createElement('span');chip.className='badge '+(!opt.hasKey?'pending':'');chip.textContent=opt.hasKey?'Key saved':'No key';h.append(chip);card.append(h);
    const lbl=document.createElement('label');lbl.className='fieldLabel';lbl.textContent='API Key';card.append(lbl);
    const key=document.createElement('input');key.className='field';key.type='password';key.placeholder=opt.hasKey?'Saved securely — enter new key to replace':'Paste API key here';key.autocomplete='off';card.append(key);
    const modelLabel=document.createElement('label');modelLabel.className='fieldLabel';modelLabel.textContent='Model ID';card.append(modelLabel);
    const model=document.createElement('input');model.className='field';model.value=opt.model||'';card.append(model);
    const save=document.createElement('button');save.className='btn';save.textContent='Save settings';save.addEventListener('click',()=>{nativeCall('saveProvider',p,key.value.trim(),model.value.trim());key.value='';});card.append(save);
    const clear=document.createElement('button');clear.className='btn secondary';clear.textContent='Remove key';clear.addEventListener('click',()=>{if(window.confirm('Remove saved '+p+' API key?'))nativeCall('removeKey',p);});card.append(clear);
    parent.append(card);
  });
  const prefs=document.createElement('section');prefs.className='settingCard';prefs.innerHTML='<h3>Assistant behavior</h3><p>Approved memories are used as context for all connected models.</p>';
  const lab=document.createElement('label');lab.className='fieldLabel';lab.textContent='Personal instructions';prefs.append(lab);
  const instructions=document.createElement('textarea');instructions.className='field';instructions.value=ui.data.instructions||'';prefs.append(instructions);
  const cf=document.createElement('label');cf.className='fieldLabel';cf.textContent='Cloudflare Account ID (only for Cloudflare)';prefs.append(cf);
  const account=document.createElement('input');account.className='field';account.value=ui.data.cloudflareAccount||'';prefs.append(account);
  const btn=document.createElement('button');btn.className='btn';btn.textContent='Save preferences';btn.addEventListener('click',()=>{nativeCall('saveOptions',instructions.value,account.value);toast('Preferences saved');});prefs.append(btn);parent.append(prefs);
  const drive=document.createElement('section');drive.className='settingCard';drive.innerHTML='<h3>Google Drive Sync</h3><p>Android v1: Not connected. Your Windows PC Google Drive sync is unaffected. Android OAuth + encrypted shared event sync needs a separate implementation and test. This app does not claim to have synced chats across devices.</p>';parent.append(drive);
}
function renderFiles(){
  const parent=$('sheetBody');parent.replaceChildren();
  const card=document.createElement('div');card.className='settingCard';card.innerHTML='<h3>Files & Code</h3><p>Attach a small text/code file (TXT, MD, PY, INO, JSON, CSV, JS, HTML, CSS). The selected text is pasted into your message. Up to 16 KB. PDF, DOCX, images and ZIP are not yet supported by Android v1.</p>';
  const attach=document.createElement('button');attach.className='btn';attach.textContent='Attach text/code file';attach.addEventListener('click',()=>{openPanel('chat');nativeCall('pickTextFile');});card.append(attach);parent.append(card);
  const out=document.createElement('section');out.className='settingCard';out.innerHTML='<h3>Save AI answer</h3><p>Save the most recent assistant response to a file on your Android device. Use .ino, .py or .txt for Arduino and Python code.</p>';
  const save=document.createElement('button');save.className='btn';save.textContent='Export latest answer';save.addEventListener('click',()=>exportAnswer(ui.lastAnswer));out.append(save);parent.append(out);
  const note=document.createElement('div');note.className='noticeBox';note.textContent='Chats are saved in an app-private SQLite database on the phone. Export a chat from the sidebar or current conversation header. Windows SQLite is a different local database.';parent.append(note);
}
function exportAnswer(value){if(!value){toast('No answer to export yet');return;}
  const filename=window.prompt('Save as file name (example: motor_control.ino)','assistant_answer.txt');
  if(filename)nativeCall('exportText',value,filename.trim());
}
window.fromNative=function(packet){
  const event=packet.event,d=packet.data||{};
  if(event==='init'||event==='refresh'){
    const firstLoad=(!ui.data.chats||ui.data.chats.length===0)&&(!ui.chatId);
    ui.data=d;
    if(event==='init'){
      ui.provider=PROVIDERS.includes(d.selectedProvider)?d.selectedProvider:'Gemini';
      $('modelLabel').textContent=ui.provider;
      if(d.chats&&d.chats.length){ui.chatId=d.chats[0].id;nativeCall('openChat',ui.chatId);}else showWelcome();
    }
    renderModels();renderChatList();if(!$('overlay').classList.contains('hidden')){
      const t=$('sheetTitle').textContent;
      if(t==='Smart Memory')renderMemories();else if(t==='AI Settings')renderSettings();
    }
  } else if(event==='newChat'){ui.chatId=d.id;showWelcome();ui.chatId=d.id;closeDrawer();}
  else if(event==='chat'){
    if(d.id!==ui.chatId)return;
    renderMessages(d.messages||[]);
  } else if(event==='sending'){/* optimistic message already rendered */}
  else if(event==='partial'){
    if(d.chatId===ui.chatId&&ui.streamBox){ui.streamBox.textContent=d.text;scrollEnd();}
  } else if(event==='done'){
    ui.busy=false;$('send').disabled=false;const stream=ui.streamBox;ui.streamBox=null;
    if(d.ok){if(d.chatId===ui.chatId)nativeCall('openChat',ui.chatId);}
    else{toast('AI error: '+(d.error||'Unknown error'));if(d.chatId===ui.chatId){
      if(stream){stream.textContent='⚠ '+(d.error||'Request failed. Your user message is saved.');stream.classList.remove('partial');}else addMessage('assistant','⚠ '+(d.error||'Request failed. Your user message is saved.'),'System');
    }}
  } else if(event==='notice'){toast(d.message||'Done');}
  else if(event==='file'){
    const text='File: '+d.name+'\n```\n'+d.text+'\n```\n\nMy request: ';
    $('input').value=($('input').value?$('input').value+'\n\n':'')+text;
    resizeInput();$('input').focus();toast('Text/code attached to message');
  }
};
function resizeInput(){const el=$('input');el.style.height='30px';el.style.height=Math.min(126,el.scrollHeight)+'px';}
$('drawerButton').addEventListener('click',openDrawer);$('drawerClose').addEventListener('click',closeDrawer);$('scrim').addEventListener('click',closeDrawer);
$('modelButton').addEventListener('click',()=>{$('modelMenu').classList.toggle('hidden');});
$('newChat').addEventListener('click',()=>nativeCall('createChat'));
$('searchChats').addEventListener('input',renderChatList);
$('archiveSwitch').addEventListener('click',()=>{ui.archived=!ui.archived;$('archiveSwitch').textContent=ui.archived?'Recent':'Archived';renderChatList();});
$('send').addEventListener('click',sendMessage);$('input').addEventListener('input',resizeInput);
$('input').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.ctrlKey){e.preventDefault();sendMessage();}});
$('attach').addEventListener('click',()=>nativeCall('pickTextFile'));
$('copyLast').addEventListener('click',()=>{if(ui.lastAnswer)nativeCall('copy',ui.lastAnswer);else toast('No assistant answer yet');});
$('exportChat').addEventListener('click',()=>{if(ui.chatId)nativeCall('exportChat',ui.chatId);});
document.querySelectorAll('.bottomNav button').forEach(b=>b.addEventListener('click',()=>openPanel(b.dataset.panel)));
$('sheetClose').addEventListener('click',()=>openPanel('chat'));
$('overlay').addEventListener('click',e=>{if(e.target===$('overlay'))openPanel('chat');});
showWelcome();
if(window.Native)nativeCall('init');else toast('Browser preview only. Install the Android APK to connect AI and save data.');
