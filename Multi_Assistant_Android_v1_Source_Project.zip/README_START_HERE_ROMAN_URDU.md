# Multi-Assistant — Android v1 (Starter)

**IMPORTANT:** Ye Android Studio ka complete SOURCE PROJECT hai, ready-to-install `.apk` nahi. Is environment mein Android SDK/Gradle install nahi, is liye APK compile ya real phone par test nahi ho saka. Project mein GitHub Actions automated APK build bhi hai.

## Kya ready hai

- Mobile-first, dark theme chat interface; recent chats drawer aur har chat par ... menu (Rename / Pin / Archive / Export / Delete)
- 5 free-tier providers: Gemini, Groq, OpenRouter Free, Cerebras Free, Cloudflare Free (API key zaroori; free limits vary)
- Streaming text responses (where API supports streaming)
- Android SQLite mein automatic local chat history; user-approved long-term memories
- Settings: system instructions, model IDs, keys encrypted through Android Keystore
- TXT/chat/code (.ino/.py/.txt) export via Android's file picker
- Text/code attachments up to 16 KB: .txt, .md, .py, .ino, .json, .csv, .js, .java, .xml, .html, .css, .log, .yaml, .yml

**Abhi supported NAHI:** Google Drive PC↔Android chat sync, ChatGPT bulk-history import, PDF/DOCX/XLSX creation/reading, offline AI, voice chat, background PC control. Inko future versions mein add karna hoga. Android local database ko Windows SQLite file samajh kar overwrite mat karna.

## Option A: APK banane ka asaan PC tareeqa — Android Studio

1. Android Studio Windows par install karo: https://developer.android.com/studio
2. Is ZIP ko **Extract All** karo; extracted folder ko Android Studio → **Open** se kholo.
3. JDK 17 aur Android SDK API 35 available hone do. Gradle project load/sync karne ke liye internet chahiye; Android Studio Gradle 8.7 select kar sakta hai. Agar IDE missing Gradle wrapper ki warning de, Gradle 8.7 install/select karo.
4. Android Studio mein **Build → Build Bundle(s) / APK(s) → Build APK(s)** chalao.
5. Output: `app/build/outputs/apk/debug/app-debug.apk`.
6. APK ko USB se Android mobile par copy karke install karna. Android ka “Install unknown apps” option temporary allow karna pad sakta hai.
7. App kholo → **Settings** → Gemini API key paste → Save. Pehle Gemini select karke `hi` test karo.

**Ye debug APK personal testing ke liye hai.** Public distribution ke liye signed release APK, QA aur policy review chahiye.

## Option B: Android Studio ke baghair APK (GitHub Actions)

GitHub account aur internet chahiye. Project folder ki sari files (including hidden `.github` folder) apne private GitHub repository mein upload karo. GitHub → **Actions** → **Build Android APK** → **Run workflow**. Successful build ke baad Actions run ke **Artifacts** section se `Multi-Assistant-Android-Debug-APK` download karo; ZIP ke andar `app-debug.apk` milegi. GitHub-hosted runner ke free quota aur build success platform ke mutabiq vary karte hain.

## API providers ke links

- Gemini: https://aistudio.google.com/api-keys
- Groq: https://console.groq.com/keys
- OpenRouter: https://openrouter.ai/settings/keys
- Cerebras: https://cloud.cerebras.ai/
- Cloudflare: https://dash.cloudflare.com/ (token + Account ID)

Default models: `gemini-3.5-flash-lite`, `openai/gpt-oss-20b`, `openrouter/free`, `gpt-oss-120b`, `@cf/meta/llama-3.1-8b-instruct-fp8`. Providers may update availability and limits. API calls are remote, not on-device. **A paid/billing-enabled provider account might still incur charges**, so check account billing/free quotas.

## Data, Privacy aur Sync

- Android chats app-private `multi_assistant_android.db` SQLite mein save hoti hain.
- API keys Android Keystore ki non-exportable encryption key se encrypted local preferences mein rakhi jati hain. Android settings mein key paste karo; PC se directly copy nahi hoti.
- On-device chat database SQLite automatically encrypted nahi hai; Android app sandbox aur screen/device lock protect karte hain. App uninstall ya Clear Storage se local chats ja sakti hain; important chats Export karo.
- Gemini/Groq/other provider ko chat content internet par send hota hai unke respective privacy policies ke mutabiq.
- **Google Drive Sync Android par abhi DISABLED hai**. PC ka existing Drive data bilkul touch nahi hota. PC/Android shared history ke liye future mein Android OAuth + Windows compatible encrypted per-device event synchronization implement aur test karna zaroori hai.
- JavaScript WebView page sirf app ke bundled local assets se load hota hai. User/API replies text ke taur par render hote hain, executable HTML nahi.

## Windows se difference

Windows PC v3.4 Python + PySide6 par hai. Ye Android app alag native Android (Java + WebView assets) project hai. Dono ka *assistant concept/provider names* same hain, **par local database abhi shared nahi**.

## Files

- `app/src/main/java/.../MainActivity.java`: Android UI bridge, chat work, file import/export
- `.../ChatStore.java`: SQLite
- `.../SecureVault.java`: API key storage
- `.../AiClient.java`: Free-tier provider API requests
- `app/src/main/assets/index.html`, `app.css`, `app.js`: Mobile UI
- `.github/workflows/build-android-apk.yml`: GitHub APK build

## Verification status

- Source Java parser: syntax parse passed (Android dependencies not type-checked here)
- Browser JavaScript parser: syntax check passed
- XML manifest: validated
- APK build: **NOT run**, Android SDK and Gradle unavailable here
- Live Android API/SQLite/Google Drive testing: **NOT run**

**Khud APK build kiye baghair ye project direct phone par install nahi ho sakta.**
